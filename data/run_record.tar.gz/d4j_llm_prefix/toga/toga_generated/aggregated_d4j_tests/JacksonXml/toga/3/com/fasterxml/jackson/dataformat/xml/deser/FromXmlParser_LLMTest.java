package com.fasterxml.jackson.dataformat.xml.deser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigDecimal;
import javax.xml.stream.XMLStreamReader;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.dataformat.xml.PackageVersion;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import java.math.BigInteger;
import javax.xml.stream.XMLStreamWriter;
import java.util.Set;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.base.ParserMinimalBase;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FromXmlParser_LLMTest extends FromXmlParser_LLMTest_scaffolding {
    
@Test
public void test_175_01()  throws Exception {



    }

@Test
public void test_175_11()  throws Exception {



    }

@Test
public void test_175_21()  throws Exception {



    }

@Test
public void test_175_31()  throws Exception {



    }

@Test
public void test_175_41()  throws Exception {



    }

@Test
public void test_175_51()  throws Exception {



    }

@Test
public void test_175_61()  throws Exception {



    }

}
package com.fasterxml.jackson.dataformat.xml.ser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.dataformat.xml.util.XmlRootNameLookup;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.SerializationConfig;
import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;
import com.fasterxml.jackson.core.*;
import javax.xml.stream.XMLStreamException;
import com.fasterxml.jackson.databind.ser.SerializerFactory;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.PropertyName;
import javax.xml.namespace.QName;
import com.fasterxml.jackson.dataformat.xml.util.StaxUtil;
import com.fasterxml.jackson.dataformat.xml.util.TypeUtil;
import com.fasterxml.jackson.databind.util.TokenBuffer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class XmlSerializerProvider_LLMTest extends XmlSerializerProvider_LLMTest_scaffolding {
    
@Test
public void test_177_01() throws Exception {
    XmlSerializerProvider srcProvider = new XmlSerializerProvider(new XmlRootNameLookup());
    XmlSerializerProvider copyProvider = new XmlSerializerProvider(srcProvider);



    }

@Test
public void test_177_21() throws Exception {
    XmlSerializerProvider srcProvider = new XmlSerializerProvider(new XmlRootNameLookup());
    XmlSerializerProvider copyProvider = new XmlSerializerProvider(srcProvider);
      assertEquals(copyProvider, copyProvider.getConfig());
}

}
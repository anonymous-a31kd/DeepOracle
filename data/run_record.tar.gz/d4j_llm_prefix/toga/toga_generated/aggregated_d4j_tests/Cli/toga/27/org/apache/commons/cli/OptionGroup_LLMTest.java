package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.cli.OptionGroup;
import org.apache.commons.cli.AlreadySelectedException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.util.Iterator;
import org.apache.commons.cli.Option;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class OptionGroup_LLMTest extends OptionGroup_LLMTest_scaffolding {
    
@Test
public void test_21_01()  throws Exception {
	try {
    OptionGroup group = new OptionGroup();
    group.setSelected(null);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_21_11()  throws Exception {
	try {
    OptionGroup group = new OptionGroup();
    Option option = new Option("k", "key", false, "description");
    group.setSelected(option);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_21_21()  throws Exception {
	try {
    OptionGroup group = new OptionGroup();
    Option option = new Option("k", "key", false, "description");
    group.setSelected(option);
    group.setSelected(option);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_21_41()  throws Exception {
	try {
    OptionGroup group = new OptionGroup();
    Option option1 = new Option("k1", "key1", false, "description");
    Option option2 = new Option("k2", "key2", false, "description");
    group.setSelected(option1);
    group.setSelected(null);
    group.setSelected(option2);



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
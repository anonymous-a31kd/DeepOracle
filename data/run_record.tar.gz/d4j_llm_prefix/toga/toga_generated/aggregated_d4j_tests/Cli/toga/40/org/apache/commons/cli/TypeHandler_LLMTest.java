package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.Date;
import java.net.MalformedURLException;
import org.apache.commons.cli.ParseException;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypeHandler_LLMTest extends TypeHandler_LLMTest_scaffolding {
    
@Test
public void test_18_01()  throws Exception {
    TypeHandler.createValue("test", Integer.class);


    }

@Test
public void test_18_11()  throws Exception {
    TypeHandler.createValue("test", PatternOptionBuilder.STRING_VALUE);


    }

@Test
public void test_18_21()  throws Exception {
    TypeHandler.createValue("java.lang.String", PatternOptionBuilder.OBJECT_VALUE);


    }

@Test
public void test_18_31()  throws Exception {
    TypeHandler.createValue("123", PatternOptionBuilder.NUMBER_VALUE);


    }

@Test
public void test_18_51()  throws Exception {
    TypeHandler.createValue("java.lang.String", PatternOptionBuilder.CLASS_VALUE);


    }

@Test
public void test_18_61()  throws Exception {
    TypeHandler.createValue("test.txt", PatternOptionBuilder.FILE_VALUE);


    }

@Test
public void test_18_91()  throws Exception {
    TypeHandler.createValue("http://example.com", PatternOptionBuilder.URL_VALUE);


    }

}
package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Option;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class OptionBuilder_LLMTest extends OptionBuilder_LLMTest_scaffolding {
    
@Test
public void test_20_01() throws Exception {
	try {
    OptionBuilder.withDescription("test description");
    OptionBuilder.withLongOpt("longopt");
    Option option = OptionBuilder.create("t");



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_20_11() throws Exception {
	try {

    OptionBuilder.withDescription("test description");
    Option option = OptionBuilder.create(null);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_20_21() throws Exception {
	try {

    OptionBuilder.withDescription("test description");
    Option option = OptionBuilder.create("");



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_20_31() throws Exception {
	try {
    OptionBuilder.withDescription("desc");
    OptionBuilder.withLongOpt("long");
    OptionBuilder.hasArg();
    OptionBuilder.isRequired();
    OptionBuilder.withValueSeparator('=');
    Option option = OptionBuilder.create("t");



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_20_41() throws Exception {
	try {
    OptionBuilder.withDescription("first");
    OptionBuilder.create("a");

    Option option = OptionBuilder.create("b");



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
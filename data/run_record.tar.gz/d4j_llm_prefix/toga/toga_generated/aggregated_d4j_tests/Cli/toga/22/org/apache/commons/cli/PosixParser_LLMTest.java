package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Arrays;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PosixParser_LLMTest extends PosixParser_LLMTest_scaffolding {
    
@Test
public void test_8_01() throws Exception {
    Options options = new Options();
    PosixParser parser = new PosixParser();
    String[] args = {"nonOption"};
    parser.flatten(options, args, false);


    }

@Test
public void test_8_11() throws Exception {
    Options options = new Options();
    PosixParser parser = new PosixParser();
    String[] args = {"nonOption"};
    parser.flatten(options, args, true);


    }

@Test
public void test_8_41() throws Exception {
    Options options = new Options();
    options.addOption("a", false, "description");
    options.addOption("b", false, "description");
    PosixParser parser = new PosixParser();
    String[] args = {"-ab", "nonOption"};
    parser.flatten(options, args, true);


    }

@Test
public void test_8_51() throws Exception {
    Options options = new Options();
    PosixParser parser = new PosixParser();
    String[] args = {"-", "nonOption"};
    parser.flatten(options, args, true);


    }

}
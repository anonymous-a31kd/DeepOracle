package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Date;
import java.io.File;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.cli.TypeHandler;
import java.net.URL;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypeHandler_LLMTest extends TypeHandler_LLMTest_scaffolding {
    
@Test
public void test_7_01() throws Exception {
    String input = "12345";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_11() throws Exception {
    String input = "123.45";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_21() throws Exception {
    String input = null;
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_31() throws Exception {
    String input = "";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_41() throws Exception {
    String input = "abc123";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_51() throws Exception {
    String input = "9223372036854775807";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_61() throws Exception {
    String input = "1.7976931348623157E308";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_71() throws Exception {
    String input = "-12345";
    Number result = TypeHandler.createNumber(input);


    }

@Test
public void test_7_81() throws Exception {
    String input = "-123.45";
    Number result = TypeHandler.createNumber(input);


    }

}
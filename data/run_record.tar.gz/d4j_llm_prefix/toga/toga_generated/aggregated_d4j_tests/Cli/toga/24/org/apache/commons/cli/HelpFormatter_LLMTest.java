package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Collection;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class HelpFormatter_LLMTest extends HelpFormatter_LLMTest_scaffolding {
    
@Test
public void test_11_01() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "This is a test text";
    int width = 10;
    int nextLineTabStop = 10;

    formatter.renderWrappedText(sb, width, nextLineTabStop, text);



    }

@Test
public void test_11_11() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "This is a test text";
    int width = 10;
    int nextLineTabStop = 15;

    formatter.renderWrappedText(sb, width, nextLineTabStop, text);



    }

@Test
public void test_11_21() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "This is a test text";
    int width = 20;
    int nextLineTabStop = 10;

    formatter.renderWrappedText(sb, width, nextLineTabStop, text);



    }

@Test
public void test_11_31() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "";
    int width = 10;
    int nextLineTabStop = 5;

    formatter.renderWrappedText(sb, width, nextLineTabStop, text);



    }

@Test
public void test_11_41() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "short";
    int width = 10;
    int nextLineTabStop = 5;

    formatter.renderWrappedText(sb, width, nextLineTabStop, text);



    }

}
package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class HelpFormatter_LLMTest extends HelpFormatter_LLMTest_scaffolding {
    
@Test
public void test_16_01() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    String text = "abcdefghijk";
    int width = 5;
    int startPos = 0;

    formatter.findWrapPos(text, width, startPos);


    }

@Test
public void test_16_11() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    String text = "abcde fghijk";
    int width = 5;
    int startPos = 0;

    formatter.findWrapPos(text, width, startPos);


    }

@Test
public void test_16_21() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    String text = "abc\ndefghijk";
    int width = 5;
    int startPos = 0;

    formatter.findWrapPos(text, width, startPos);


    }

@Test
public void test_16_31() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    String text = "abc\tdefghijk";
    int width = 5;
    int startPos = 0;

    formatter.findWrapPos(text, width, startPos);


    }

@Test
public void test_16_41() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    String text = "abc";
    int width = 5;
    int startPos = 0;

    formatter.findWrapPos(text, width, startPos);


    }

@Test
public void test_16_51() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    String text = "a b c d e f";
    int width = 10;
    int startPos = 2;

    formatter.findWrapPos(text, width, startPos);


    }

}
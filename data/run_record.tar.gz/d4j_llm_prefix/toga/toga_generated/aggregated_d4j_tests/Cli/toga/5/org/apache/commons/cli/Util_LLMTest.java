package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Util_LLMTest extends Util_LLMTest_scaffolding {
    
@Test
public void test_0_01() throws Exception {
	try {
    String result = Util.stripLeadingHyphens(null);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_0_11() throws Exception {
    String result = Util.stripLeadingHyphens("--option");



    }

@Test
public void test_0_21() throws Exception {
	try {
    String result = Util.stripLeadingHyphens("-option");



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_0_31() throws Exception {
    String result = Util.stripLeadingHyphens("option");



    }

@Test
public void test_0_41() throws Exception {
	try {
    String result = Util.stripLeadingHyphens("");



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_0_51() throws Exception {
	try {
    String result = Util.stripLeadingHyphens("---");



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
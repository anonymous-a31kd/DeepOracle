package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import org.apache.commons.cli.DefaultParser;
import java.util.Properties;
import org.apache.commons.cli.Options;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DefaultParser_LLMTest extends DefaultParser_LLMTest_scaffolding {
    
@Test
public void test_27_01() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();
    parser.options.addOption("S", false, "");



    }

@Test
public void test_27_11() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();
    parser.options.addOption("S", false, "");



    }

@Test
public void test_27_21() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();
    parser.options.addOption("SV", false, "");



    }

@Test
public void test_27_31() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();
    parser.options.addOption("SV", false, "");



    }

@Test
public void test_27_41() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();



    }

@Test
public void test_27_51() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();



    }

@Test
public void test_27_61() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();



    }

@Test
public void test_27_71() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();
    parser.options.addOption("S", false, "");



    }

@Test
public void test_27_81() throws Exception {
    DefaultParser parser = new DefaultParser();
    parser.options = new Options();
    parser.options.addOption("S", false, "");
    parser.options.addOption("V", false, "");



    }

}
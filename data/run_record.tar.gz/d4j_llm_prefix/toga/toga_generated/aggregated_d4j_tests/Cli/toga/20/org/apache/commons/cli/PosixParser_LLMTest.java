package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.cli.PosixParser;
import org.apache.commons.cli.Options;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PosixParser_LLMTest extends PosixParser_LLMTest_scaffolding {
    
@Test
public void test_17_01() throws Exception {
    PosixParser parser = new PosixParser();
    Options options = new Options();
    options.addOption("foo", false, "");
    String[] args = {"--foo"};
    parser.flatten(options, args, false);


    }

@Test
public void test_17_11() throws Exception {
    PosixParser parser = new PosixParser();
    Options options = new Options();
    options.addOption("foo", false, "");
    String[] args = {"--foo=bar"};
    parser.flatten(options, args, false);


    }

@Test
public void test_17_21() throws Exception {
    PosixParser parser = new PosixParser();
    Options options = new Options();
    String[] args = {"--unknown"};
    parser.flatten(options, args, true);


    }

@Test
public void test_17_31() throws Exception {
    PosixParser parser = new PosixParser();
    Options options = new Options();
    String[] args = {"--unknown=value"};
    parser.flatten(options, args, true);


    }

@Test
public void test_17_41() throws Exception {
    PosixParser parser = new PosixParser();
    Options options = new Options();
    options.addOption("foo", false, "");
    String[] args = {"--foo="};
    parser.flatten(options, args, false);


    }

@Test
public void test_17_51() throws Exception {
    PosixParser parser = new PosixParser();
    Options options = new Options();
    options.addOption("foo", false, "");
    options.addOption("bar", false, "");
    String[] args = {"--foo", "--bar=value", "--unknown", "--known=test"};
    parser.flatten(options, args, true);


    }

}
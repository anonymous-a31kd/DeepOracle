package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.io.BufferedReader;
import java.util.List;
import java.io.StringReader;
import java.util.Collections;
import java.util.Collection;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Comparator;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class HelpFormatter_LLMTest extends HelpFormatter_LLMTest_scaffolding {
    
@Test
public void test_25_01() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 2, "");
    pw.flush();


    }

@Test
public void test_25_11() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 20, 2, "Short text");
    pw.flush();


    }

@Test
public void test_25_21() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 2, "This is a long text that needs wrapping");
    pw.flush();


    }

@Test
public void test_25_31() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 2, "Line1\nLine2\nLine3");
    pw.flush();


    }

@Test
public void test_25_41() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 15, "Text with large tab stop");
    pw.flush();


    }

}
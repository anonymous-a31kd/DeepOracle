package com.google.gson.internal.bind;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.List;
import java.util.BitSet;
import java.util.UUID;
import java.io.StringReader;
import com.google.gson.internal.LazilyParsedNumber;
import java.util.HashMap;
import com.google.gson.stream.JsonWriter;
import java.util.ArrayList;
import com.google.gson.JsonPrimitive;
import java.util.concurrent.atomic.AtomicIntegerArray;
import com.google.gson.JsonSyntaxException;
import com.google.gson.annotations.SerializedName;
import java.math.BigInteger;
import java.util.Calendar;
import com.google.gson.JsonNull;
import com.google.gson.JsonIOException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.net.URI;
import java.net.InetAddress;
import java.math.BigDecimal;
import com.google.gson.stream.JsonToken;
import com.google.gson.JsonArray;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.Date;
import java.util.Currency;
import java.util.Map;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import java.sql.Timestamp;
import java.util.StringTokenizer;
import java.net.URL;
import com.google.gson.JsonElement;
import com.google.gson.TypeAdapterFactory;
import java.util.concurrent.atomic.AtomicInteger;
import com.google.gson.TypeAdapter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypeAdapters_LLMTest extends TypeAdapters_LLMTest_scaffolding {
    
@Test
public void test_165_01()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("123"));
    reader.peek();
    TypeAdapters.NUMBER.read(reader);


    }

@Test
public void test_165_11()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("\"456\""));
    reader.peek();
    TypeAdapters.NUMBER.read(reader);


    }

@Test
public void test_165_21()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("null"));
    reader.peek();
    TypeAdapters.NUMBER.read(reader);


    }

}
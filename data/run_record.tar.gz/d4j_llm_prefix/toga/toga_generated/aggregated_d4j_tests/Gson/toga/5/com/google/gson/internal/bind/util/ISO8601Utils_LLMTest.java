package com.google.gson.internal.bind.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.text.ParsePosition;
import java.text.ParseException;
import java.util.TimeZone;
import java.util.Date;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ISO8601Utils_LLMTest extends ISO8601Utils_LLMTest_scaffolding {
    
@Test
public void test_161_01()  throws Exception {
	try {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2023-01-01T12:00:00+00", pos);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_11()  throws Exception {
	try {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2023-01-01T12:00:00-05", pos);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_21()  throws Exception {
	try {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2023-01-01T12:00:00+0000", pos);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_31()  throws Exception {
	try {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2023-01-01T12:00:00+00:00", pos);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_41()  throws Exception {
	try {
    ParsePosition pos = new ParsePosition(0);
    ISO8601Utils.parse("2023-01-01T12:00:00Z00", pos);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_51()  throws Exception {
	try {
    ParsePosition pos = new ParsePosition(0);
    Date date = ISO8601Utils.parse("2023-01-01T12:00:00Z", pos);



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package com.google.gson.internal;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static com.google.gson.internal.$Gson$Preconditions.checkArgument;
import java.lang.reflect.Array;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.WildcardType;
import java.lang.reflect.GenericArrayType;
import java.util.ArrayList;
import static com.google.gson.internal.$Gson$Preconditions.checkNotNull;
import java.lang.reflect.Type;
import static com.google.gson.internal.$Gson$Types.*;
import java.io.Serializable;
import java.lang.reflect.Modifier;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class $Gson$Types_LLMTest extends $Gson$Types_LLMTest_scaffolding {
    
@Test
public void test_171_21() throws Exception {
    Type result = getSupertype(List.class, List.class, Iterable.class);


    }

}
package com.google.gson.internal.bind;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Writer;
import com.google.gson.JsonNull;
import com.google.gson.JsonArray;
import com.google.gson.stream.JsonWriter;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.internal.bind.JsonTreeWriter;
import java.util.ArrayList;
import com.google.gson.JsonPrimitive;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonTreeWriter_LLMTest extends JsonTreeWriter_LLMTest_scaffolding {
    
@Test
public void test_71_01()  throws Exception {
	try {
    JsonTreeWriter writer = new JsonTreeWriter();
    writer.value(123.456);
    

		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_71_11()  throws Exception {
	try {
    JsonTreeWriter writer = new JsonTreeWriter();
    writer.value(0.0);
    

		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_71_21()  throws Exception {
	try {
    JsonTreeWriter writer = new JsonTreeWriter();
    writer.value(-987.654);
    

		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_71_61()  throws Exception {
	try {
    JsonTreeWriter writer = new JsonTreeWriter();
    writer.setLenient(true);
    writer.value(Double.NaN);
    

		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_71_71()  throws Exception {
	try {
    JsonTreeWriter writer = new JsonTreeWriter();
    writer.setLenient(true);
    writer.value(Double.POSITIVE_INFINITY);
    

		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_71_81()  throws Exception {
	try {
    JsonTreeWriter writer = new JsonTreeWriter();
    writer.value(true);
    writer.value(3.14);
    writer.value(false);
    writer.value(2.718);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
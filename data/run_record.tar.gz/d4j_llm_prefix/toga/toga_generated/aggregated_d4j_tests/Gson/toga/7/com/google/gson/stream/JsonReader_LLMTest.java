package com.google.gson.stream;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Reader;
import java.io.Closeable;
import com.google.gson.internal.bind.JsonTreeReader;
import java.io.EOFException;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.stream.JsonReader;
import java.io.StringReader;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonReader_LLMTest extends JsonReader_LLMTest_scaffolding {
    
@Test
public void test_69_01()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("123"));
    reader.nextInt();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_69_21()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("\"123\""));
    reader.nextInt();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_69_31()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("123"));
    reader.nextInt();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_70_01()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("12345"));
    reader.nextLong();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_70_21()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("\"12345\""));
    reader.nextLong();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_70_31()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("-12345"));
    reader.nextLong();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_70_41()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("0"));
    reader.nextLong();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_70_51()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("9223372036854775807"));
    reader.nextLong();


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package com.google.gson.internal;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Field;
import java.io.Serializable;
import com.google.gson.internal.UnsafeAllocator;
import java.io.ObjectInputStream;
import java.lang.reflect.Method;
import java.io.ObjectStreamClass;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UnsafeAllocator_LLMTest extends UnsafeAllocator_LLMTest_scaffolding {
    
@Test
public void test_163_01()  throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    allocator.newInstance(Object.class);


    }

@Test
public void test_163_31()  throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    allocator.newInstance(Integer.class);


    }

@Test
public void test_163_41()  throws Exception {
    UnsafeAllocator allocator = UnsafeAllocator.create();
    class PrivateConstructor {
        private PrivateConstructor() {}
    }
    allocator.newInstance(PrivateConstructor.class);


    }

}
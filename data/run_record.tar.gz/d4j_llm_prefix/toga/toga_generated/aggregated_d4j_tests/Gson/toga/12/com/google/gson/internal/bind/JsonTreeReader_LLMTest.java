package com.google.gson.internal.bind;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.gson.stream.JsonToken;
import java.io.Reader;
import java.util.Map;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonArray;
import java.util.Iterator;
import com.google.gson.stream.JsonReader;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonTreeReader_LLMTest extends JsonTreeReader_LLMTest_scaffolding {
    
@Test
public void test_166_01()  throws Exception {
	try {
    JsonObject obj = new JsonObject();
    obj.add("name", new JsonPrimitive("value"));
    JsonTreeReader reader = new JsonTreeReader(obj);
    reader.peek();
    reader.skipValue();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_166_11()  throws Exception {
	try {
    JsonArray array = new JsonArray();
    array.add(new JsonPrimitive(1));
    JsonTreeReader reader = new JsonTreeReader(array);
    reader.peek();
    reader.skipValue();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_166_21()  throws Exception {
	try {
    JsonTreeReader reader = new JsonTreeReader(JsonNull.INSTANCE);
    reader.peek();
    reader.skipValue();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_166_41()  throws Exception {
	try {
    JsonObject outer = new JsonObject();
    JsonObject inner = new JsonObject();
    inner.add("innerKey", new JsonPrimitive("innerValue"));
    outer.add("outerKey", inner);
    JsonTreeReader reader = new JsonTreeReader(outer);
    reader.peek();
    reader.skipValue();


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
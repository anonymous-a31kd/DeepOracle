package com.google.gson.stream;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static com.google.gson.stream.JsonScope.DANGLING_NAME;
import static com.google.gson.stream.JsonScope.NONEMPTY_ARRAY;
import java.io.StringWriter;
import static com.google.gson.stream.JsonScope.EMPTY_DOCUMENT;
import java.io.Flushable;
import static com.google.gson.stream.JsonScope.EMPTY_OBJECT;
import static com.google.gson.stream.JsonScope.NONEMPTY_OBJECT;
import java.io.Closeable;
import static com.google.gson.stream.JsonScope.NONEMPTY_DOCUMENT;
import static com.google.gson.stream.JsonScope.EMPTY_ARRAY;
import java.io.Writer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonWriter_LLMTest extends JsonWriter_LLMTest_scaffolding {
    
@Test
public void test_169_01()  throws Exception {
	try {
    StringWriter writer = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(writer);
    jsonWriter.beginArray();
    jsonWriter.value(123.45);
    jsonWriter.endArray();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_169_31()  throws Exception {
	try {
    StringWriter writer = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(writer);
    jsonWriter.setLenient(true);
    jsonWriter.beginArray();
    jsonWriter.value(Double.NaN);
    jsonWriter.endArray();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_169_41()  throws Exception {
	try {
    StringWriter writer = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(writer);
    jsonWriter.setLenient(true);
    jsonWriter.beginArray();
    jsonWriter.value(Double.NEGATIVE_INFINITY);
    jsonWriter.endArray();


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
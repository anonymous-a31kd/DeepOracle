package com.google.gson.internal;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Collection;
import static com.google.gson.internal.$Gson$Preconditions.checkNotNull;
import java.lang.reflect.Modifier;
import java.lang.reflect.Array;
import java.lang.reflect.ParameterizedType;
import java.io.Serializable;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.WildcardType;
import java.lang.reflect.TypeVariable;
import java.util.Properties;
import java.util.Map;
import static com.google.gson.internal.$Gson$Preconditions.checkArgument;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class $Gson$Types_LLMTest extends $Gson$Types_LLMTest_scaffolding {
    
@Test
public void test_168_01() throws Exception {

    Type stringType = String.class;
    WildcardType result = $Gson$Types.subtypeOf(stringType);
    Type[] upperBounds = result.getUpperBounds();



    }

@Test
public void test_168_11() throws Exception {

    WildcardType originalWildcard = $Gson$Types.subtypeOf(List.class);

    WildcardType result = $Gson$Types.subtypeOf(originalWildcard);
    Type[] upperBounds = result.getUpperBounds();



    }

@Test
public void test_168_21() throws Exception {

    ParameterizedType listOfString = $Gson$Types.newParameterizedTypeWithOwner(null, List.class, String.class);
    WildcardType result = $Gson$Types.subtypeOf(listOfString);
    Type[] upperBounds = result.getUpperBounds();



    }

@Test
public void test_168_31() throws Exception {

    Type stringArrayType = String[].class;
    WildcardType result = $Gson$Types.subtypeOf(stringArrayType);
    Type[] upperBounds = result.getUpperBounds();



    }

}
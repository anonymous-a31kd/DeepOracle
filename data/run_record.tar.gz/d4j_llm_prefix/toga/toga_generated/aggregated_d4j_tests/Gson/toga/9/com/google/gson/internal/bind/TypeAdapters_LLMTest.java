package com.google.gson.internal.bind;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashMap;
import com.google.gson.stream.JsonReader;
import java.util.Calendar;
import com.google.gson.JsonArray;
import com.google.gson.stream.JsonToken;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.net.URI;
import java.util.GregorianCalendar;
import java.math.BigDecimal;
import java.util.UUID;
import com.google.gson.JsonObject;
import java.util.Date;
import com.google.gson.JsonPrimitive;
import com.google.gson.reflect.TypeToken;
import java.util.Currency;
import java.util.concurrent.atomic.AtomicBoolean;
import com.google.gson.internal.LazilyParsedNumber;
import com.google.gson.JsonSyntaxException;
import com.google.gson.JsonNull;
import java.util.ArrayList;
import com.google.gson.Gson;
import java.util.StringTokenizer;
import com.google.gson.JsonIOException;
import com.google.gson.TypeAdapterFactory;
import java.sql.Timestamp;
import java.math.BigInteger;
import java.util.Map;
import java.net.InetAddress;
import java.net.URL;
import com.google.gson.annotations.SerializedName;
import java.net.URISyntaxException;
import java.util.Locale;
import com.google.gson.JsonElement;
import java.io.StringWriter;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import com.google.gson.stream.JsonWriter;
import java.util.BitSet;
import com.google.gson.TypeAdapter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypeAdapters_LLMTest extends TypeAdapters_LLMTest_scaffolding {
    
@Test
public void test_72_01()  throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    TypeAdapters.BOOLEAN.write(jsonWriter, Boolean.TRUE);


    }

@Test
public void test_72_11()  throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    TypeAdapters.BOOLEAN.write(jsonWriter, null);


    }

@Test
public void test_72_21()  throws Exception {
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    TypeAdapters.BOOLEAN.write(jsonWriter, Boolean.FALSE);


    }

}
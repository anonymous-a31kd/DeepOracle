package com.google.gson.stream;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.gson.internal.bind.JsonTreeReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.EOFException;
import java.io.Closeable;
import com.google.gson.internal.JsonReaderInternalAccess;
import com.google.gson.stream.JsonReader;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonReader_LLMTest extends JsonReader_LLMTest_scaffolding {
    
@Test
public void test_167_01()  throws Exception {
	try {
    JsonReader reader = new JsonReader(new StringReader("0"));
    reader.peek();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_167_11()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("-0"));
    reader.peek();


    }

@Test
public void test_167_21()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("12345"));
    reader.peek();


    }

@Test
public void test_167_31()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("-12345"));
    reader.peek();


    }

@Test
public void test_167_41()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("-9223372036854775808"));
    reader.peek();


    }

@Test
public void test_167_51()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("9223372036854775807"));
    reader.peek();


    }

@Test
public void test_167_61()  throws Exception {
    JsonReader reader = new JsonReader(new StringReader("12345678901234567890"));
    reader.peek();


    }

}
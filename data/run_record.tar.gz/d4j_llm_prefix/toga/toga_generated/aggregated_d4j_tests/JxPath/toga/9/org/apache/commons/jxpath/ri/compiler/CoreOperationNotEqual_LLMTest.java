package org.apache.commons.jxpath.ri.compiler;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.ri.compiler.Constant;
import org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual;
import org.apache.commons.jxpath.ri.EvalContext;
import org.apache.commons.jxpath.ri.compiler.CoreOperationEqual;
import org.apache.commons.jxpath.ri.compiler.Expression;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CoreOperationNotEqual_LLMTest extends CoreOperationNotEqual_LLMTest_scaffolding {
    
@Test
public void test_93_01() throws Exception {
    new CoreOperationNotEqual(null, null);


    }

@Test
public void test_93_11() throws Exception {
    Expression const1 = new Constant(1);
    Expression const2 = new Constant(2);
    new CoreOperationNotEqual(const1, const2);


    }

@Test
public void test_93_21() throws Exception {
    Expression const1 = new Constant(1);
    new CoreOperationNotEqual(const1, const1);


    }

@Test
public void test_93_31() throws Exception {
    Expression const1 = new Constant("text");
    Expression const2 = new Constant(123);
    new CoreOperationNotEqual(const1, const2);


    }

@Test
public void test_93_41() throws Exception {
    Expression const1 = new Constant(1);
    Expression const2 = new Constant(2);
    Expression opEqual = new CoreOperationEqual(const1, const2);
    new CoreOperationNotEqual(opEqual, const1);


    }

}
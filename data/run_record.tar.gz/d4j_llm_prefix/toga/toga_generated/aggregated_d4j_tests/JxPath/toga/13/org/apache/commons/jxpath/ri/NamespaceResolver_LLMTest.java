package org.apache.commons.jxpath.ri;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.ri.model.NodePointer;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NamespaceResolver_LLMTest extends NamespaceResolver_LLMTest_scaffolding {
    
@Test
public void test_97_01() throws Exception {
    NamespaceResolver resolver = new NamespaceResolver();
    resolver.registerNamespace("test", "http://test.com");
    resolver.getPrefix("http://test.com");


    }

@Test
public void test_97_21() throws Exception {
    NamespaceResolver parent = new NamespaceResolver();
    parent.registerNamespace("parent", "http://parent.com");
    NamespaceResolver resolver =	new NamespaceResolver(parent);
    resolver.getPrefix("http://parent.com");


    }

@Test
public void test_97_31() throws Exception {
    NamespaceResolver resolver = new NamespaceResolver();
    resolver.getPrefix(null);


    }

@Test
public void test_97_41() throws Exception {
    NamespaceResolver resolver = new NamespaceResolver();
    resolver.registerNamespace("test", "http://test.com");
    resolver.getPrefix("http://nonexistent.com");


    }

}
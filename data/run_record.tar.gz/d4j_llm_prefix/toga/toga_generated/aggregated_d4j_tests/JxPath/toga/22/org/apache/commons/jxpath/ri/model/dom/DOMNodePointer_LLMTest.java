package org.apache.commons.jxpath.ri.model.dom;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.w3c.dom.NodeList;
import java.util.HashMap;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Document;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.w3c.dom.Element;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.JXPathException;
import java.util.Map;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.w3c.dom.Comment;
import java.util.Locale;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Attr;
import org.apache.commons.jxpath.util.TypeUtils;
import org.apache.commons.jxpath.ri.Compiler;
import org.w3c.dom.Node;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DOMNodePointer_LLMTest extends DOMNodePointer_LLMTest_scaffolding {
    
@Test
public void test_136_01()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    Attr attr = doc.createAttribute("xmlns:test");
    attr.setValue("");
    root.setAttributeNode(attr);

    DOMNodePointer.getNamespaceURI(root);


    }

@Test
public void test_136_11()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);

    DOMNodePointer.getNamespaceURI(root);


    }

@Test
public void test_136_21()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("test:root");
    doc.appendChild(root);

    DOMNodePointer.getNamespaceURI(root);


    }

@Test
public void test_136_31()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElementNS("http://example.com", "test:root");
    doc.appendChild(root);

    DOMNodePointer.getNamespaceURI(root);


    }

@Test
public void test_136_41()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element parent = doc.createElementNS("http://example.com", "test:parent");
    doc.appendChild(parent);
    Element child = doc.createElement("child");
    parent.appendChild(child);

    DOMNodePointer.getNamespaceURI(child);


    }

@Test
public void test_136_51()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);

    DOMNodePointer.getNamespaceURI(doc);


    }

}
package org.apache.commons.jxpath.ri.model.dom;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.w3c.dom.NamedNodeMap;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import java.util.HashMap;
import org.w3c.dom.Comment;
import org.w3c.dom.Attr;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.util.TypeUtils;
import org.apache.commons.jxpath.Pointer;
import java.util.Locale;
import org.w3c.dom.Element;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.NodeList;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.w3c.dom.Node;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import java.util.Map;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.w3c.dom.Document;
import org.apache.commons.jxpath.ri.Compiler;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.commons.jxpath.JXPathException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DOMNodePointer_LLMTest extends DOMNodePointer_LLMTest_scaffolding {
    
@Test
public void test_98_21()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element element = doc.createElement("test");
    doc.appendChild(element);

    DOMNodePointer pointer = new DOMNodePointer(element, null);
    JXPathContext context = JXPathContext.newContext(null);
    QName name = new QName(null, "attr");

    pointer.createAttribute(context, name);


    }

@Test
public void test_98_31()  throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element element = doc.createElement("test");
    element.setAttribute("attr", "value");
    doc.appendChild(element);

    DOMNodePointer pointer = new DOMNodePointer(element, null);
    JXPathContext context = JXPathContext.newContext(null);
    QName name = new QName(null, "attr");

    pointer.createAttribute(context, name);


    }

@Test
public void test_99_11() throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    DOMNodePointer pointer = new DOMNodePointer(root, null);
    pointer.getNamespaceURI("");


    }

@Test
public void test_99_21() throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    DOMNodePointer pointer = new DOMNodePointer(root, null);
    pointer.getNamespaceURI("xml");


    }

@Test
public void test_99_31() throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    DOMNodePointer pointer = new DOMNodePointer(root, null);
    pointer.getNamespaceURI("xmlns");


    }

@Test
public void test_99_51() throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    DOMNodePointer pointer = new DOMNodePointer(root, null);
    pointer.getNamespaceURI("unknown");


    }

@Test
public void test_99_61() throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    DOMNodePointer pointer = new DOMNodePointer(root, null);
    pointer.getNamespaceResolver();


    }

@Test
public void test_99_71() throws Exception {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = factory.newDocumentBuilder();
    Document doc = builder.newDocument();
    Element root = doc.createElement("root");
    doc.appendChild(root);
    DOMNodePointer pointer = new DOMNodePointer(root, null);
    pointer.getNamespaceResolver();
    pointer.getNamespaceResolver();


    }

}
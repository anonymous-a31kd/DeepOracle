package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.Charset;
import com.google.javascript.rhino.TokenStream;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.Node;
import com.google.common.base.Preconditions;
import com.google.javascript.jscomp.NodeUtil.MatchNotFunction;
import com.google.common.base.Charsets;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CodeGenerator_LLMTest extends CodeGenerator_LLMTest_scaffolding {
    
@Test
public void test_95_01() throws Exception {

    char delChar = 0x7f;
    String input = "a" + delChar + "b";
    CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", null);


    }

@Test
public void test_95_11() throws Exception {

    char upperBoundChar = 0x7e;
    String input = "a" + upperBoundChar + "b";
    CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", null);


    }

@Test
public void test_95_21() throws Exception {

    char lowerBoundChar = 0x20;
    String input = "a" + lowerBoundChar + "b";
    CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", null);


    }

@Test
public void test_95_31() throws Exception {

    char controlChar = 0x1f;
    String input = "a" + controlChar + "b";
    CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", null);


    }

@Test
public void test_95_41() throws Exception {

    char nonAsciiChar = 0x80;
    String input = "a" + nonAsciiChar + "b";
    CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", null);


    }

}
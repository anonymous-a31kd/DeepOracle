package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.NodeTraversal.Callback;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.Node;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CheckGlobalThis_LLMTest extends CheckGlobalThis_LLMTest_scaffolding {
    
@Test
public void test_127_01() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node blockParent = new Node(Token.BLOCK);
    blockParent.addChildToBack(functionNode);



    }

@Test
public void test_127_11() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node scriptParent = new Node(Token.SCRIPT);
    scriptParent.addChildToBack(functionNode);



    }

@Test
public void test_127_21() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node nameParent = new Node(Token.NAME);
    nameParent.addChildToBack(functionNode);



    }

@Test
public void test_127_31() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node assignParent = new Node(Token.ASSIGN);
    assignParent.addChildToBack(functionNode);



    }

@Test
public void test_127_41() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node invalidParent = new Node(Token.RETURN);
    invalidParent.addChildToBack(functionNode);



    }

@Test
public void test_127_51() throws Exception {
    Node nonFunctionNode = new Node(Token.VAR);
    Node parent = new Node(Token.BLOCK);
    parent.addChildToBack(nonFunctionNode);



    }

@Test
public void test_127_61() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);



    }

@Test
public void test_127_71() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node blockParent = new Node(Token.BLOCK);
    blockParent.addChildToBack(functionNode);



    }

}
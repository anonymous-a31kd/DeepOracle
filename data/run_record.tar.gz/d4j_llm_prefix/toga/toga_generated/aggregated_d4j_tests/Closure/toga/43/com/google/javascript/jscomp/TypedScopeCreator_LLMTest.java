package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.CodingConvention.SubclassType;
import static com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
import com.google.javascript.rhino.ErrorReporter;
import static com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
import com.google.common.annotations.VisibleForTesting;
import static com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
import com.google.javascript.jscomp.CodingConvention.DelegateRelationship;
import static com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import static com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
import com.google.javascript.rhino.jstype.ObjectType;
import com.google.javascript.jscomp.NodeTraversal.AbstractShallowStatementCallback;
import static com.google.javascript.jscomp.TypeCheck.MULTIPLE_VAR_DEF;
import com.google.javascript.rhino.jstype.EnumType;
import com.google.javascript.jscomp.Scope.Var;
import static com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE;
import com.google.javascript.jscomp.CodingConvention.SubclassRelationship;
import java.util.List;
import java.util.Iterator;
import static com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
import com.google.javascript.rhino.jstype.FunctionParamBuilder;
import static com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE;
import com.google.javascript.rhino.jstype.JSType;
import static com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
import com.google.common.collect.ImmutableList;
import static com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
import com.google.common.base.Preconditions;
import com.google.javascript.jscomp.NodeTraversal;
import static com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
import com.google.common.collect.Maps;
import static com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
import javax.annotation.Nullable;
import static com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
import com.google.javascript.jscomp.NodeTraversal.AbstractScopedCallback;
import static com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
import com.google.common.collect.Lists;
import static com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
import com.google.javascript.jscomp.FunctionTypeBuilder.AstFunctionContents;
import static com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
import com.google.javascript.rhino.jstype.JSTypeNative;
import java.util.Map;
import static com.google.javascript.jscomp.TypeCheck.ENUM_NOT_CONSTANT;
import com.google.javascript.rhino.InputId;
import com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast;
import com.google.javascript.rhino.jstype.FunctionType;
import static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypedScopeCreator_LLMTest extends TypedScopeCreator_LLMTest_scaffolding {
    
@Test
public void test_56_11() throws Exception {
    Node objectLit = new Node(Token.OBJECTLIT);



    }

@Test
public void test_56_21() throws Exception {
    Node objectLit = new Node(Token.OBJECTLIT);
    objectLit.setJSDocInfo(null);



    }

@Test
public void test_56_31() throws Exception {
    Node objectLit = new Node(Token.OBJECTLIT);
    JSDocInfo info = new JSDocInfo();

    objectLit.setJSDocInfo(info);



    }

}
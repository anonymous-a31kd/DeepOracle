package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Collections;
import com.google.common.base.Predicates;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.base.Predicate;
import com.google.javascript.rhino.jstype.FunctionType;
import java.util.HashSet;
import java.util.Map;
import com.google.javascript.rhino.TokenStream;
import java.util.Collection;
import com.google.common.collect.ImmutableSet;
import com.google.javascript.rhino.Token;
import com.google.common.base.Preconditions;
import java.util.Arrays;
import com.google.common.collect.Maps;
import java.util.Set;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NodeUtil_LLMTest extends NodeUtil_LLMTest_scaffolding {
    
@Test
public void test_104_11() throws Exception {
    Node delPropNode = new Node(Token.DELPROP);
    Predicate<Node> locals = new Predicate<Node>() {
        @Override
        public boolean apply(Node input) {
            return false;
        }
    };
    boolean result = NodeUtil.evaluatesToLocalValue(delPropNode, locals);


    }

@Test
public void test_105_01() throws Exception {
    Node delPropNode = new Node(Token.DELPROP);



    }

@Test
public void test_105_11() throws Exception {
    Node trueNode = new Node(Token.TRUE);



    }

@Test
public void test_105_21() throws Exception {
    Node falseNode = new Node(Token.FALSE);



    }

@Test
public void test_105_31() throws Exception {
    Node stringNode = new Node(Token.STRING);



    }

@Test
public void test_105_41() throws Exception {
    Node eqNode = new Node(Token.EQ);



    }

@Test
public void test_105_51() throws Exception {
    Node notNode = new Node(Token.NOT);



    }

}
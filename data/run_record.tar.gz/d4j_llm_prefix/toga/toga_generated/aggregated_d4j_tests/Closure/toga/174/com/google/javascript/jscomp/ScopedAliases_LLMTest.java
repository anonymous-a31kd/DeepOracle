package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.collect.Maps;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.rhino.SourcePosition;
import java.util.List;
import com.google.common.collect.Multiset;
import com.google.common.collect.Lists;
import com.google.common.base.Preconditions;
import javax.annotation.Nullable;
import java.util.Collection;
import com.google.javascript.rhino.Token;
import com.google.common.collect.Sets;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformation;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.collect.HashMultiset;
import com.google.javascript.rhino.Node;
import java.util.Set;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ScopedAliases_LLMTest extends ScopedAliases_LLMTest_scaffolding {
    
@Test
public void test_154_01() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("name");
    Node qualifiedNameChild = Node.newString("qualified.name");
    nameNode.addChildToFront(qualifiedNameChild);
    varNode.addChildToFront(nameNode);



    }

@Test
public void test_154_11() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("name");
    varNode.addChildToFront(nameNode);



    }

@Test
public void test_154_21() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("name");
    Node nonQualifiedChild = new Node(Token.NUMBER);
    nameNode.addChildToFront(nonQualifiedChild);
    varNode.addChildToFront(nameNode);



    }

@Test
public void test_154_31() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("name");
    Node valueNode = new Node(Token.STRING);
    nameNode.addChildToFront(valueNode);
    varNode.addChildToFront(nameNode);



    }

@Test
public void test_154_41() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("name");
    Node valueNode = new Node(Token.STRING);
    nameNode.addChildToFront(valueNode);
    varNode.addChildToFront(nameNode);



    }

@Test
public void test_154_51() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("name");
    varNode.addChildToFront(nameNode);



    }

}
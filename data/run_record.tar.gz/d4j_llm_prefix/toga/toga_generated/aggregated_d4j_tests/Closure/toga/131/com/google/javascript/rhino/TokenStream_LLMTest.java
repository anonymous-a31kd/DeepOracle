package com.google.javascript.rhino;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.TokenStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TokenStream_LLMTest extends TokenStream_LLMTest_scaffolding {
    
@Test
public void test_32_01() throws Exception {
    String input = "";
    TokenStream.isJSIdentifier(input);


    }

@Test
public void test_32_11() throws Exception {
    String input = "\u200Btest";
    TokenStream.isJSIdentifier(input);


    }

@Test
public void test_32_21() throws Exception {
    String input = "te\u200Bst";
    TokenStream.isJSIdentifier(input);


    }

@Test
public void test_32_31() throws Exception {
    String input = "validIdentifier";
    TokenStream.isJSIdentifier(input);


    }

@Test
public void test_32_41() throws Exception {
    String input = "1invalid";
    TokenStream.isJSIdentifier(input);


    }

@Test
public void test_32_51() throws Exception {
    String input = "invalid@char";
    TokenStream.isJSIdentifier(input);


    }

@Test
public void test_32_61() throws Exception {
    String input = "\u200B@test";
    TokenStream.isJSIdentifier(input);


    }

}
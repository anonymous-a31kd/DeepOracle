package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import com.google.javascript.rhino.JSDocInfo;
import java.util.logging.Level;
import java.util.Set;
import java.util.HashMap;
import java.io.Serializable;
import com.google.javascript.rhino.Node;
import java.io.PrintStream;
import java.util.List;
import java.util.Collections;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.base.Supplier;
import com.google.javascript.jscomp.parsing.Config;
import com.google.javascript.jscomp.parsing.ParserRunner;
import java.util.logging.Logger;
import com.google.javascript.rhino.Token;
import com.google.javascript.jscomp.mozilla.rhino.ErrorReporter;
import com.google.common.annotations.VisibleForTesting;
import com.google.javascript.jscomp.ReferenceCollectingCallback.ReferenceMap;
import java.nio.charset.Charset;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import com.google.javascript.jscomp.CompilerOptions.TracerMode;
import com.google.javascript.jscomp.deps.SortedDependencies.CircularDependencyException;
import com.google.javascript.jscomp.deps.SortedDependencies.MissingProvideException;
import com.google.javascript.jscomp.ReferenceCollectingCallback.ReferenceCollection;
import java.util.concurrent.Callable;
import com.google.common.base.Preconditions;
import com.google.javascript.jscomp.CompilerOptions.LanguageMode;
import com.google.javascript.jscomp.CompilerOptions.DevMode;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Compiler_LLMTest extends Compiler_LLMTest_scaffolding {
    
@Test
public void test_83_01() throws Exception {
    Compiler compiler = new Compiler();
    Node testNode = new Node(Token.SCRIPT);
    compiler.toSource(testNode);


    }

@Test
public void test_84_21() throws Exception {
    Compiler compiler = new Compiler();
    CompilerOptions options = new CompilerOptions();
    options.setLanguageIn(LanguageMode.ECMASCRIPT5_STRICT);
    compiler.initOptions(options);

    Node root = new Node(Token.SCRIPT);
    root.putProp(Node.SOURCENAME_PROP, "test.js");
    Compiler.CodeBuilder cb = new Compiler.CodeBuilder();
    compiler.toSource(cb, 0, root);


    }

@Test
public void test_84_31() throws Exception {
    Compiler compiler = new Compiler();
    CompilerOptions options = new CompilerOptions();
    options.setLanguageIn(LanguageMode.ECMASCRIPT5_STRICT);
    compiler.initOptions(options);

    Node root = new Node(Token.SCRIPT);
    root.putProp(Node.SOURCENAME_PROP, "test.js");
    Compiler.CodeBuilder cb = new Compiler.CodeBuilder();
    compiler.toSource(cb, 1, root);


    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import com.google.javascript.rhino.TokenStream;
import java.util.Map;
import java.util.HashMap;
import com.google.common.base.Predicate;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import com.google.javascript.rhino.Token;
import com.google.javascript.jscomp.GlobalNamespace.Ref;
import com.google.javascript.rhino.Node;
import com.google.common.base.Preconditions;
import java.util.LinkedList;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.GlobalNamespace.Name;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GlobalNamespace_LLMTest extends GlobalNamespace_LLMTest_scaffolding {
    
@Test
public void test_134_01() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 1;
    name.localSets = 0;
    name.declaration = null;
    name.canCollapseUnannotatedChildNames();


    }

@Test
public void test_134_21() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 1;
    name.localSets = 0;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    name.canCollapseUnannotatedChildNames();


    }

@Test
public void test_134_31() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 1;
    name.localSets = 0;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    name.setIsClassOrEnum();
    name.canCollapseUnannotatedChildNames();


    }

@Test
public void test_134_41() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 2;
    name.localSets = 0;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    name.canCollapseUnannotatedChildNames();


    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.io.Files;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import com.google.common.io.CharStreams;
import com.google.javascript.rhino.jstype.StaticSourceFile;
import java.io.InputStreamReader;
import java.io.FileReader;
import com.google.javascript.jscomp.SourceFile;
import com.google.common.annotations.VisibleForTesting;
import java.nio.charset.Charset;
import java.io.File;
import java.io.InputStream;
import com.google.common.base.Charsets;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class SourceFile_LLMTest extends SourceFile_LLMTest_scaffolding {
    
@Test
public void test_75_01() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "line1\nline2");
    String result = sourceFile.getLine(2);



    }

@Test
public void test_75_11() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "single line");
    String result = sourceFile.getLine(2);



    }

@Test
public void test_75_21() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "line1\nline2");
    String result = sourceFile.getLine(2);



    }

@Test
public void test_75_31() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "");
    String result = sourceFile.getLine(1);



    }

@Test
public void test_75_41() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "single line");
    String result = sourceFile.getLine(1);



    }

@Test
public void test_75_51() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "line1\nline2\nline3\n");
    String result = sourceFile.getLine(3);



    }

@Test
public void test_75_61() throws Exception {
    SourceFile sourceFile = SourceFile.fromCode("test.js", "line1\nline2\nline3");

    sourceFile.getLine(2);

    String result = sourceFile.getLine(3);



    }

}
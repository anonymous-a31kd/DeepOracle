package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.Scope;
import java.util.Map;
import com.google.common.collect.Lists;
import javax.annotation.Nullable;
import com.google.common.collect.Multiset;
import com.google.common.collect.Sets;
import java.util.Collection;
import com.google.common.collect.Maps;
import java.util.Set;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.collect.HashMultiset;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformation;
import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.SourcePosition;
import java.util.HashSet;
import com.google.javascript.jscomp.NodeTraversal;
import com.google.common.base.Preconditions;
import java.util.List;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ScopedAliases_LLMTest extends ScopedAliases_LLMTest_scaffolding {
    
@Test
public void test_138_01() throws Exception {
    NodeTraversal t = null;
    Node n = new Node(Token.NAME);
    JSDocInfo info = new JSDocInfo();
    n.setJSDocInfo(info);
    Node parent = new Node(Token.SCRIPT);

    Set<Node> injectedDecls = new HashSet<>();



    }

@Test
public void test_138_11() throws Exception {
    NodeTraversal t = null;
    Node n = new Node(Token.NAME);
    JSDocInfo info = new JSDocInfo();
    n.setJSDocInfo(info);
    Node parent = new Node(Token.SCRIPT);

    Set<Node> injectedDecls = new HashSet<>();
    injectedDecls.add(n);



    }

@Test
public void test_138_21() throws Exception {
    NodeTraversal t = null;
    Node n = new Node(Token.NAME);
    Node parent = new Node(Token.SCRIPT);



    }

@Test
public void test_138_31() throws Exception {
    NodeTraversal t = null;
    Node n = new Node(Token.NAME);
    Node parent = new Node(Token.SCRIPT);



    }

@Test
public void test_138_41() throws Exception {
    NodeTraversal t = null;
    Node n = new Node(Token.NAME);
    Node parent = new Node(Token.SCRIPT);



    }

}
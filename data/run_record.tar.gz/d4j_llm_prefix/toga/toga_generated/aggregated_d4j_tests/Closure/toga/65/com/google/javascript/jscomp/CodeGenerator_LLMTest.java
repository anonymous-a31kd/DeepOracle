package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import java.nio.charset.Charset;
import com.google.javascript.rhino.Node;
import java.nio.charset.CharsetEncoder;
import com.google.javascript.rhino.Token;
import com.google.javascript.jscomp.NodeUtil.MatchNotFunction;
import com.google.javascript.rhino.TokenStream;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import java.nio.charset.StandardCharsets;
import com.google.common.base.Charsets;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CodeGenerator_LLMTest extends CodeGenerator_LLMTest_scaffolding {
    
@Test
public void test_85_01() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String result = CodeGenerator.strEscape("\0", '\'', "", "", "", encoder);



    }

@Test
public void test_85_11() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String result = CodeGenerator.strEscape("\0", '"', "", "", "", encoder);



    }

@Test
public void test_85_21() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String result = CodeGenerator.strEscape("a\0b\nc", '"', "", "", "", encoder);



    }

@Test
public void test_85_31() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String result = CodeGenerator.strEscape("\0\0\0", '\'', "", "", "", encoder);



    }

@Test
public void test_85_41() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String result = CodeGenerator.strEscape("\0\"\n\\", '"', "\\\"", "", "\\\\", encoder);



    }

}
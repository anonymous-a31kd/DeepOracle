package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.NodeTraversal.Callback;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.Node;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CheckGlobalThis_LLMTest extends CheckGlobalThis_LLMTest_scaffolding {
    
@Test
public void test_126_21() throws Exception {
    Node assignNode = new Node(Token.ASSIGN);
    Node getPropNode = new Node(Token.GETPROP);
    Node prototypeNode = Node.newString("prototype");
    getPropNode.addChildToBack(new Node(Token.NAME));
    getPropNode.addChildToBack(prototypeNode);
    assignNode.addChildToBack(getPropNode);
    assignNode.addChildToBack(new Node(Token.THIS));

    Node parentNode = new Node(Token.BLOCK);
    parentNode.addChildToBack(assignNode);



    }

@Test
public void test_126_31() throws Exception {
    Node assignNode = new Node(Token.ASSIGN);
    Node outerGetProp = new Node(Token.GETPROP);
    Node innerGetProp = new Node(Token.GETPROP);
    Node prototypeNode = Node.newString("prototype");

    innerGetProp.addChildToBack(new Node(Token.NAME));
    innerGetProp.addChildToBack(prototypeNode);
    outerGetProp.addChildToBack(innerGetProp);
    outerGetProp.addChildToBack(Node.newString("property"));

    assignNode.addChildToBack(outerGetProp);
    assignNode.addChildToBack(new Node(Token.THIS));

    Node parentNode = new Node(Token.BLOCK);
    parentNode.addChildToBack(assignNode);



    }

@Test
public void test_126_41() throws Exception {
    Node assignNode = new Node(Token.ASSIGN);
    Node nameNode = Node.newString(Token.NAME, "x");
    assignNode.addChildToBack(nameNode);
    assignNode.addChildToBack(new Node(Token.THIS));

    Node parentNode = new Node(Token.BLOCK);
    parentNode.addChildToBack(assignNode);



    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableSet;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.FunctionType;
import java.util.Arrays;
import java.util.Collection;
import com.google.javascript.rhino.jstype.StaticSourceFile;
import com.google.common.base.Predicates;
import com.google.javascript.rhino.TokenStream;
import java.util.Collections;
import java.util.Map;
import com.google.common.collect.Maps;
import java.util.HashSet;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.base.Predicate;
import java.util.Set;
import com.google.javascript.rhino.InputId;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.IR;
import javax.annotation.Nullable;
import com.google.javascript.rhino.jstype.TernaryValue;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NodeUtil_LLMTest extends NodeUtil_LLMTest_scaffolding {
    
@Test
public void test_12_01() throws Exception {
    Node stringNode = Node.newString("test");
    NodeUtil.mayBeString(stringNode, true);


    }

@Test
public void test_12_11() throws Exception {
    Node numberNode = Node.newNumber(123);
    NodeUtil.mayBeString(numberNode, true);


    }

@Test
public void test_12_21() throws Exception {
    Node addNode = new Node(Token.ADD, Node.newString("a"), Node.newNumber(1));
    NodeUtil.mayBeString(addNode, true);


    }

@Test
public void test_12_31() throws Exception {
    Node stringNode = Node.newString("test");
    NodeUtil.mayBeString(stringNode, false);


    }

@Test
public void test_12_41() throws Exception {
    Node numberNode = Node.newNumber(123);
    NodeUtil.mayBeString(numberNode, false);


    }

@Test
public void test_12_51() throws Exception {
    Node addNode = new Node(Token.ADD, Node.newString("a"), Node.newNumber(1));
    NodeUtil.mayBeString(addNode, false);


    }

}
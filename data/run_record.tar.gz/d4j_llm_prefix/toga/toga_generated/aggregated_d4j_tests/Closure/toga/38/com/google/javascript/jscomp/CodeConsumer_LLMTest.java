package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Node;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CodeConsumer_LLMTest extends CodeConsumer_LLMTest_scaffolding {
    
@Test
public void test_49_01() throws Exception {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = '-';
        @Override
        char getLastChar() {
            return lastChar;
        }
        @Override
        void append(String str) {}
    };
    consumer.addNumber(-5.0);


    }

@Test
public void test_49_11() throws Exception {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = '-';
        @Override
        char getLastChar() {
            return lastChar;
        }
        @Override
        void append(String str) {}
    };
    consumer.addNumber(-0.0);


    }

@Test
public void test_49_21() throws Exception {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = '-';
        @Override
        char getLastChar() {
            return lastChar;
        }
        @Override
        void append(String str) {}
    };
    consumer.addNumber(5.0);


    }

@Test
public void test_49_31() throws Exception {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = 'a';
        @Override
        char getLastChar() {
            return lastChar;
        }
        @Override
        void append(String str) {}
    };
    consumer.addNumber(-5.0);


    }

@Test
public void test_49_41() throws Exception {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = 'a';
        @Override
        char getLastChar() {
            return lastChar;
        }
        @Override
        void append(String str) {}
    };
    consumer.addNumber(-0.0);


    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Node;
import java.util.List;
import java.util.Locale;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.common.collect.Lists;
import com.google.common.base.Preconditions;
import com.google.javascript.jscomp.mozilla.rhino.ScriptRuntime;
import com.google.javascript.rhino.Token;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PeepholeFoldConstants_LLMTest extends PeepholeFoldConstants_LLMTest_scaffolding {
    
@Test
public void test_96_01() throws Exception {
    Node voidNode = new Node(Token.VOID);
    voidNode.addChildToBack(Node.newNumber(1));
    Node right = Node.newString("test");
    Node comparison = new Node(Token.EQ, voidNode, right);



    }

@Test
public void test_96_11() throws Exception {
    Node nullNode = new Node(Token.NULL);
    Node right = new Node(Token.NULL);
    Node comparison = new Node(Token.SHEQ, nullNode, right);



    }

@Test
public void test_96_21() throws Exception {
    Node numNode = Node.newNumber(42);
    Node right = Node.newNumber(42);
    Node comparison = new Node(Token.EQ, numNode, right);



    }

@Test
public void test_96_31() throws Exception {
    Node strNode = Node.newString("hello");
    Node right = Node.newString("hello");
    Node comparison = new Node(Token.SHEQ, strNode, right);



    }

@Test
public void test_96_51() throws Exception {
    Node left = Node.newNumber(42);
    Node voidNode = new Node(Token.VOID);
    voidNode.addChildToBack(Node.newNumber(1));
    Node comparison = new Node(Token.EQ, left, voidNode);



    }

@Test
public void test_96_61() throws Exception {
    Node numNode = Node.newNumber(42);
    Node strNode = Node.newString("42");
    Node comparison = new Node(Token.EQ, numNode, strNode);



    }

}
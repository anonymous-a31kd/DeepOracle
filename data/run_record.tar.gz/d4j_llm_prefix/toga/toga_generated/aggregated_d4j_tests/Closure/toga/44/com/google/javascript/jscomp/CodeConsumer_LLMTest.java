package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Node;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CodeConsumer_LLMTest extends CodeConsumer_LLMTest_scaffolding {
    
@Test
public void test_57_01() throws Exception {
	try {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = 0;

        @Override
        char getLastChar() {
            return lastChar;
        }

        @Override
        void append(String str) {
            lastChar = str.charAt(str.length() - 1);
        }
    };

    consumer.add("/");
    consumer.add("/");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_11() throws Exception {
	try {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = 0;

        @Override
        char getLastChar() {
            return lastChar;
        }

        @Override
        void append(String str) {
            lastChar = str.charAt(str.length() - 1);
        }
    };

    consumer.add("a");
    consumer.add("/");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_21() throws Exception {
	try {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = 0;

        @Override
        char getLastChar() {
            return lastChar;
        }

        @Override
        void append(String str) {
            lastChar = str.charAt(str.length() - 1);
        }
    };

    consumer.add("/");
    consumer.add("a");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_31() throws Exception {
	try {
    CodeConsumer consumer = new CodeConsumer() {
        char lastChar = 0;

        @Override
        char getLastChar() {
            return lastChar;
        }

        @Override
        void append(String str) {
            lastChar = str.charAt(str.length() - 1);
        }
    };

    consumer.add("");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
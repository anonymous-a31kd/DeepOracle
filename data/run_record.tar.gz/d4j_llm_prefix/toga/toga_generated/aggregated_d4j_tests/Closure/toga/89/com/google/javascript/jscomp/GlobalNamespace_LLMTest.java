package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashMap;
import com.google.common.base.Predicate;
import com.google.javascript.jscomp.GlobalNamespace.Ref;
import com.google.javascript.jscomp.GlobalNamespace.Name;
import java.util.List;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Node;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.GlobalNamespace.Name.Type;
import java.util.ArrayList;
import com.google.javascript.rhino.TokenStream;
import java.util.Set;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GlobalNamespace_LLMTest extends GlobalNamespace_LLMTest_scaffolding {
    
@Test
public void test_115_01() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.FUNCTION;
    name.aliasingGets = 1;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);



    }

@Test
public void test_115_11() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.OTHER;
    name.aliasingGets = 1;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);



    }

@Test
public void test_115_21() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.FUNCTION;
    name.aliasingGets = 0;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);



    }

@Test
public void test_115_31() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.FUNCTION;
    name.aliasingGets = 1;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    name.setIsClassOrEnum();



    }

}
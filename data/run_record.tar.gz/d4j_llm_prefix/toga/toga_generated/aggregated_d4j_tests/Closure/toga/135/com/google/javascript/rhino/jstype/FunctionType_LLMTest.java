package com.google.javascript.rhino.jstype;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import java.util.Collections;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.javascript.rhino.jstype.JSType;
import static com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
import com.google.javascript.rhino.jstype.FunctionPrototypeType;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.jstype.FunctionType;
import com.google.javascript.rhino.ErrorReporter;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.google.javascript.rhino.Token;
import com.google.common.base.Preconditions;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import com.google.javascript.rhino.jstype.ObjectType;
import com.google.common.collect.ImmutableList;
import java.util.Set;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FunctionType_LLMTest extends FunctionType_LLMTest_scaffolding {
    
@Test
public void test_41_21() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);

    JSType someType = registry.getNativeType(U2U_CONSTRUCTOR_TYPE);
    functionType.defineProperty("someProperty", someType, false, false);


    }

@Test
public void test_41_41() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);

    JSType nonObjectType = registry.getNativeType(U2U_CONSTRUCTOR_TYPE);
    functionType.defineProperty("prototype", nonObjectType, false, false);


    }

@Test
public void test_42_01() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);



    }

@Test
public void test_42_11() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);



    }

@Test
public void test_42_21() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);
    JSType prototypeType = functionType.getPropertyType("prototype");



    }

@Test
public void test_42_31() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);
    JSType callType = functionType.getPropertyType("call");



    }

@Test
public void test_42_61() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    FunctionType functionType = new FunctionType(registry, "testFunc", null, null, null);
    JSType propertyType = functionType.getPropertyType("toString");



    }

}
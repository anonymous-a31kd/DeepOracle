package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.NodeTraversal.Callback;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.Node;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CheckGlobalThis_LLMTest extends CheckGlobalThis_LLMTest_scaffolding {
    
@Test
public void test_65_01() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node objectLitNode = new Node(Token.OBJECTLIT);
    objectLitNode.addChildToBack(functionNode);
    CheckGlobalThis checker = new CheckGlobalThis(null, CheckLevel.WARNING);
    checker.shouldTraverse(null, functionNode, objectLitNode);


    }

@Test
public void test_65_11() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node assignNode = new Node(Token.ASSIGN);
    assignNode.addChildToBack(new Node(Token.NAME));
    assignNode.addChildToBack(functionNode);
    CheckGlobalThis checker = new CheckGlobalThis(null, CheckLevel.WARNING);
    checker.shouldTraverse(null, functionNode, assignNode);


    }

@Test
public void test_65_21() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node blockNode = new Node(Token.BLOCK);
    blockNode.addChildToBack(functionNode);
    CheckGlobalThis checker = new CheckGlobalThis(null, CheckLevel.WARNING);
    checker.shouldTraverse(null, functionNode, blockNode);


    }

@Test
public void test_65_31() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node scriptNode = new Node(Token.SCRIPT);
    scriptNode.addChildToBack(functionNode);
    CheckGlobalThis checker = new CheckGlobalThis(null, CheckLevel.WARNING);
    checker.shouldTraverse(null, functionNode, scriptNode);


    }

@Test
public void test_65_51() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node exprNode = new Node(Token.EXPR_RESULT);
    exprNode.addChildToBack(functionNode);
    CheckGlobalThis checker = new CheckGlobalThis(null, CheckLevel.WARNING);
    checker.shouldTraverse(null, functionNode, exprNode);


    }

@Test
public void test_65_61() throws Exception {
    Node varNode = new Node(Token.VAR);
    Node parentNode = new Node(Token.SCRIPT);
    parentNode.addChildToBack(varNode);
    CheckGlobalThis checker = new CheckGlobalThis(null, CheckLevel.WARNING);
    checker.shouldTraverse(null, varNode, parentNode);


    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import com.google.javascript.rhino.jstype.StaticScope;
import static com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
import com.google.javascript.rhino.jstype.ObjectType;
import com.google.javascript.rhino.JSDocInfo;
import java.util.LinkedHashMap;
import com.google.javascript.rhino.jstype.StaticSlot;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Token;
import java.util.Iterator;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.jstype.FunctionType;
import com.google.javascript.rhino.ErrorReporter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Scope_LLMTest extends Scope_LLMTest_scaffolding {
    
@Test
public void test_89_01() throws Exception {
    Scope scope = new Scope(new Node(Token.BLOCK), (ObjectType) null);
      assertEquals(0, scope.getVarCount());
}

@Test
public void test_89_11() throws Exception {
    Scope scope = new Scope(new Node(Token.BLOCK), (ObjectType) null);
    scope.declare("var1", new Node(Token.NAME), null, null);
    scope.declare("var2", new Node(Token.NAME), null, null);
      assertEquals(0, scope.getVarCount());
}

}
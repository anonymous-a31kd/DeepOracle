package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.CodingConvention.Bind;
import com.google.common.base.Joiner;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.common.collect.ImmutableSet;
import java.util.regex.Pattern;
import com.google.javascript.rhino.IR;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PeepholeSubstituteAlternateSyntax_LLMTest extends PeepholeSubstituteAlternateSyntax_LLMTest_scaffolding {
    
@Test
public void test_151_01() throws Exception {

    Node mulNode = new Node(Token.MUL);
    Node left = Node.newNumber(2);
    Node right = new Node(Token.MUL, Node.newNumber(3), Node.newNumber(4));
    mulNode.addChildToBack(left);
    mulNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(mulNode);


    }

@Test
public void test_151_11() throws Exception {

    Node andNode = new Node(Token.AND);
    Node left = IR.trueNode();
    Node right = new Node(Token.AND, IR.falseNode(), IR.trueNode());
    andNode.addChildToBack(left);
    andNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(andNode);


    }

@Test
public void test_151_21() throws Exception {

    Node orNode = new Node(Token.OR);
    Node left = IR.falseNode();
    Node right = new Node(Token.OR, IR.trueNode(), IR.falseNode());
    orNode.addChildToBack(left);
    orNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(orNode);


    }

@Test
public void test_151_31() throws Exception {

    Node bitOrNode = new Node(Token.BITOR);
    Node left = Node.newNumber(1);
    Node right = new Node(Token.BITOR, Node.newNumber(2), Node.newNumber(3));
    bitOrNode.addChildToBack(left);
    bitOrNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(bitOrNode);


    }

@Test
public void test_151_41() throws Exception {

    Node bitXorNode = new Node(Token.BITXOR);
    Node left = Node.newNumber(5);
    Node right = new Node(Token.BITXOR, Node.newNumber(6), Node.newNumber(7));
    bitXorNode.addChildToBack(left);
    bitXorNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(bitXorNode);


    }

@Test
public void test_151_51() throws Exception {

    Node bitAndNode = new Node(Token.BITAND);
    Node left = Node.newNumber(8);
    Node right = new Node(Token.BITAND, Node.newNumber(9), Node.newNumber(10));
    bitAndNode.addChildToBack(left);
    bitAndNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(bitAndNode);


    }

@Test
public void test_151_61() throws Exception {

    Node subNode = new Node(Token.SUB);
    Node left = Node.newNumber(1);
    Node right = Node.newNumber(2);
    subNode.addChildToBack(left);
    subNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(true);
    peephole.optimizeSubtree(subNode);


    }

@Test
public void test_151_71() throws Exception {

    Node mulNode = new Node(Token.MUL);
    Node left = Node.newNumber(1);
    Node right = new Node(Token.MUL, Node.newNumber(2), Node.newNumber(3));
    mulNode.addChildToBack(left);
    mulNode.addChildToBack(right);

    PeepholeSubstituteAlternateSyntax peephole = new PeepholeSubstituteAlternateSyntax(false);
    peephole.optimizeSubtree(mulNode);


    }

}
package com.google.javascript.rhino.jstype;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.jstype.UnionType;
import java.util.SortedSet;
import java.util.TreeSet;
import com.google.javascript.rhino.ErrorReporter;
import java.util.HashSet;
import java.util.Set;
import static com.google.javascript.rhino.jstype.TernaryValue.UNKNOWN;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.common.collect.ImmutableSet;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UnionType_LLMTest extends UnionType_LLMTest_scaffolding {
    
@Test
public void test_132_01() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    Set<JSType> alternates = new HashSet<>();
    alternates.add(registry.getNativeType(JSTypeNative.NUMBER_TYPE));
    UnionType unionType = new UnionType(registry, alternates);
    JSType result = unionType.meet(registry.getNativeType(JSTypeNative.NUMBER_TYPE));



    }

@Test
public void test_132_11() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    Set<JSType> alternates = new HashSet<>();
    alternates.add(registry.getNativeType(JSTypeNative.STRING_TYPE));
    UnionType unionType = new UnionType(registry, alternates);
    JSType result = unionType.meet(registry.getNativeType(JSTypeNative.NUMBER_TYPE));



    }

@Test
public void test_132_21() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    Set<JSType> alternates = new HashSet<>();
    alternates.add(registry.getNativeType(JSTypeNative.OBJECT_TYPE));
    UnionType unionType = new UnionType(registry, alternates);
    JSType result = unionType.meet(registry.getNativeType(JSTypeNative.OBJECT_TYPE));



    }

@Test
public void test_132_31() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    Set<JSType> alternates = new HashSet<>();
    alternates.add(registry.getNativeType(JSTypeNative.NUMBER_TYPE));
    UnionType unionType = new UnionType(registry, alternates);
    JSType result = unionType.meet(registry.getNativeType(JSTypeNative.STRING_TYPE));



    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import com.google.common.annotations.VisibleForTesting;
import com.google.javascript.rhino.Token;
import java.util.logging.Level;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import com.google.common.collect.Lists;
import com.google.javascript.jscomp.mozilla.rhino.ErrorReporter;
import java.util.List;
import com.google.common.base.Supplier;
import com.google.javascript.jscomp.JSSourceFile;
import java.io.PrintStream;
import java.util.HashMap;
import com.google.javascript.jscomp.SourceMap;
import java.util.Set;
import java.io.Serializable;
import com.google.common.collect.Maps;
import com.google.javascript.jscomp.CompilerOptions.DevMode;
import com.google.javascript.jscomp.JSModule;
import com.google.javascript.jscomp.CompilerOptions;
import com.google.javascript.jscomp.parsing.ParserRunner;
import java.util.logging.Logger;
import com.google.javascript.jscomp.CompilerOptions.TracerMode;
import com.google.javascript.jscomp.parsing.Config;
import java.util.Map;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Node;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Compiler_LLMTest extends Compiler_LLMTest_scaffolding {
    
@Test
public void test_52_01() throws Exception {
    Compiler compiler = new Compiler();



    }

@Test
public void test_52_21() throws Exception {
    Compiler compiler = new Compiler();
    JSSourceFile input = JSSourceFile.fromCode("test.js", "var x = 1;");
    CompilerOptions options = new CompilerOptions();
    compiler.compile(new JSSourceFile[0], new JSSourceFile[]{input}, options);
      assertNotNull(compiler.getSourceMap());
}

@Test
public void test_52_31() throws Exception {
    Compiler compiler = new Compiler();
    CompilerOptions options = new CompilerOptions();

    compiler.compile(new JSSourceFile[0], new JSSourceFile[0], options);
      assertNotNull(compiler.getSourceMap());
}

@Test
public void test_53_01() throws Exception {
    Compiler compiler = new Compiler();
    JSModule[] modules = new JSModule[0];
    JSSourceFile[] externs = new JSSourceFile[0];
    CompilerOptions options = new CompilerOptions();
    compiler.init(externs, modules, options);


    }

@Test
public void test_53_11() throws Exception {
    Compiler compiler = new Compiler();
    JSModule[] modules = new JSModule[]{new JSModule("testModule")};
    JSSourceFile[] externs = new JSSourceFile[0];
    CompilerOptions options = new CompilerOptions();
    compiler.init(externs, modules, options);


    }

@Test
public void test_53_21() throws Exception {
    Compiler compiler = new Compiler();
    JSModule[] modules = new JSModule[]{
        new JSModule("module1"),
        new JSModule("module2"),
        new JSModule("module3")
    };
    JSSourceFile[] externs = new JSSourceFile[0];
    CompilerOptions options = new CompilerOptions();
    compiler.init(externs, modules, options);


    }

@Test
public void test_53_31() throws Exception {
    Compiler compiler = new Compiler();
    JSModule module1 = new JSModule("module1");
    JSModule module2 = new JSModule("module2");
    module2.add(JSSourceFile.fromCode("test.js", "var x = 1;"));
    JSModule[] modules = new JSModule[]{module1, module2};
    JSSourceFile[] externs = new JSSourceFile[0];
    CompilerOptions options = new CompilerOptions();
    compiler.init(externs, modules, options);


    }

}
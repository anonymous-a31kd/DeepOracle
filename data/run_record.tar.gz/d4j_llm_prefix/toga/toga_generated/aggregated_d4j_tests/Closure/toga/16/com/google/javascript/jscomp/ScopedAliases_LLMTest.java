package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformation;
import com.google.javascript.rhino.Node;
import javax.annotation.Nullable;
import com.google.javascript.rhino.SourcePosition;
import com.google.javascript.rhino.Token;
import java.util.Set;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.Map;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler;
import com.google.common.base.Preconditions;
import java.util.Collection;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.collect.Sets;
import com.google.javascript.jscomp.Scope.Var;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ScopedAliases_LLMTest extends ScopedAliases_LLMTest_scaffolding {
    
@Test
public void test_18_21() throws Exception {
    Node typeNode = Node.newString("nonAlias");
    Map<String, Var> aliases = Maps.newHashMap();



    }

}
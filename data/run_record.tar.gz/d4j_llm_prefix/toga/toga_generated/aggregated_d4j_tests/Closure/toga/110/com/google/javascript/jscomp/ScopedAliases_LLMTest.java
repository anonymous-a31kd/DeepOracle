package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import com.google.common.collect.Lists;
import com.google.common.collect.Multiset;
import com.google.common.collect.Maps;
import java.util.Set;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.rhino.Token;
import javax.annotation.Nullable;
import com.google.common.collect.Sets;
import java.util.Collection;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.collect.HashMultiset;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformation;
import com.google.javascript.rhino.IR;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.SourcePosition;
import java.util.List;
import com.google.javascript.rhino.Node;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ScopedAliases_LLMTest extends ScopedAliases_LLMTest_scaffolding {
    
@Test
public void test_141_01() throws Exception {

    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("testVar");
    Node qualifiedName = Node.newString("qualified.name");
    nameNode.addChildToFront(qualifiedName);
    varNode.addChildToFront(nameNode);



    }

@Test
public void test_141_11() throws Exception {

    Node funcNode = new Node(Token.FUNCTION);
    Node nameNode = Node.newString("testFunc");
    funcNode.addChildToFront(nameNode);
    Node blockNode = new Node(Token.BLOCK);
    funcNode.addChildToBack(blockNode);

    Node parent = new Node(Token.SCRIPT);
    parent.addChildToFront(funcNode);



    }

@Test
public void test_141_21() throws Exception {

    Node varNode = new Node(Token.VAR);
    Node nameNode = Node.newString("testVar");
    Node initialValue = Node.newString("initialValue");
    nameNode.addChildToFront(initialValue);
    varNode.addChildToFront(nameNode);

    Node parent = new Node(Token.SCRIPT);
    parent.addChildToFront(varNode);



    }

@Test
public void test_141_31() throws Exception {

    Node funcNode = new Node(Token.FUNCTION);
    Node nameNode = Node.newString("testFunc");
    funcNode.addChildToFront(nameNode);
    Node blockNode = new Node(Token.BLOCK);
    funcNode.addChildToBack(blockNode);

    Node parent = new Node(Token.SCRIPT);
    parent.addChildToFront(funcNode);



    }

@Test
public void test_141_41() throws Exception {

    Node funcNode = new Node(Token.FUNCTION);
    Node nameNode = Node.newString("testFunc");
    funcNode.addChildToFront(nameNode);



    }

}
package com.google.javascript.rhino.jstype;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Comparator;
import com.google.common.base.Predicate;
import com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode;
import java.io.Serializable;
import com.google.javascript.rhino.ErrorReporter;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.JSDocInfo;
import static com.google.javascript.rhino.jstype.TernaryValue.UNKNOWN;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JSType_LLMTest extends JSType_LLMTest_scaffolding {
    
@Test
public void test_107_01() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    JSType type = new JSType(registry) {
        @Override public boolean isNoType() { return true; }
        @Override public boolean isNoObjectType() { return false; }
        @Override public boolean isNoResolvedType() { return false; }

        @Override public boolean isSubtype(JSType that) { return false; }
        @Override public BooleanLiteralSet getPossibleToBooleanOutcomes() { return null; }
        @Override public <T> T visit(Visitor<T> visitor) { return null; }
        @Override public JSType resolveInternal(ErrorReporter t, StaticScope<JSType> scope) { return null; }
    };
      assertTrue(type.isEmptyType());
}

@Test
public void test_107_11() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    JSType type = new JSType(registry) {
        @Override public boolean isNoType() { return false; }
        @Override public boolean isNoObjectType() { return true; }
        @Override public boolean isNoResolvedType() { return false; }

        @Override public boolean isSubtype(JSType that) { return false; }
        @Override public BooleanLiteralSet getPossibleToBooleanOutcomes() { return null; }
        @Override public <T> T visit(Visitor<T> visitor) { return null; }
        @Override public JSType resolveInternal(ErrorReporter t, StaticScope<JSType> scope) { return null; }
    };
      assertTrue(type.isEmptyType());
}

@Test
public void test_107_21() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    JSType type = new JSType(registry) {
        @Override public boolean isNoType() { return false; }
        @Override public boolean isNoObjectType() { return false; }
        @Override public boolean isNoResolvedType() { return true; }

        @Override public boolean isSubtype(JSType that) { return false; }
        @Override public BooleanLiteralSet getPossibleToBooleanOutcomes() { return null; }
        @Override public <T> T visit(Visitor<T> visitor) { return null; }
        @Override public JSType resolveInternal(ErrorReporter t, StaticScope<JSType> scope) { return null; }
    };
      assertTrue(type.isEmptyType());
}

@Test
public void test_107_31() throws Exception {
    JSTypeRegistry registry = new JSTypeRegistry(null);
    JSType leastFunctionType = registry.getNativeType(JSTypeNative.LEAST_FUNCTION_TYPE);
    JSType type = new JSType(registry) {
        @Override public boolean isNoType() { return false; }
        @Override public boolean isNoObjectType() { return false; }
        @Override public boolean isNoResolvedType() { return false; }

        @Override public boolean isSubtype(JSType that) { return false; }
        @Override public BooleanLiteralSet getPossibleToBooleanOutcomes() { return null; }
        @Override public <T> T visit(Visitor<T> visitor) { return null; }
        @Override public JSType resolveInternal(ErrorReporter t, StaticScope<JSType> scope) { return null; }
    };



    }

}
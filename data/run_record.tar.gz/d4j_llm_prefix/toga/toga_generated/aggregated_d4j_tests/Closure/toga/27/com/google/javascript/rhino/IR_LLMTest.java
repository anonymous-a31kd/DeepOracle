package com.google.javascript.rhino;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.IR;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.Node;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class IR_LLMTest extends IR_LLMTest_scaffolding {
    
@Test
public void test_31_01() throws Exception {
    Node scriptNode = IR.script();



    }

@Test
public void test_31_11() throws Exception {
    Node stmt = IR.exprResult(IR.string("test"));
    Node scriptNode = IR.script(stmt);



    }

@Test
public void test_31_21() throws Exception {
    Node stmt1 = IR.exprResult(IR.string("test1"));
    Node stmt2 = IR.exprResult(IR.string("test2"));
    Node stmt3 = IR.exprResult(IR.string("test3"));
    Node scriptNode = IR.script(stmt1, stmt2, stmt3);



    }

@Test
public void test_31_41() throws Exception {
    Node innerBlock = IR.block(IR.exprResult(IR.string("inner")));
    Node scriptNode = IR.script(innerBlock);
      assertEquals(innerBlock, scriptNode.getType());
}

@Test
public void test_32_01() throws Exception {
	try {
    Node tryBody = IR.block();
    Node catchNode = IR.catchNode(IR.name("e"), IR.block());
    Node finallyBody = IR.block();
    Node result = IR.tryCatchFinally(tryBody, catchNode, finallyBody);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_11() throws Exception {
	try {
    Node tryBody = IR.block(IR.exprResult(IR.number(1)), IR.exprResult(IR.number(2)));
    Node catchNode = IR.catchNode(IR.name("e"), IR.block());
    Node finallyBody = IR.block();
    Node result = IR.tryCatchFinally(tryBody, catchNode, finallyBody);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_21() throws Exception {
	try {
    Node tryBody = IR.block();
    Node catchBody = IR.block(IR.exprResult(IR.call(IR.name("console"), IR.string("log"), IR.name("e"))));
    Node catchNode = IR.catchNode(IR.name("e"), catchBody);
    Node finallyBody = IR.block();
    Node result = IR.tryCatchFinally(tryBody, catchNode, finallyBody);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_31() throws Exception {
	try {
    Node tryBody = IR.block();
    Node catchNode = IR.catchNode(IR.name("e"), IR.block());
    Node finallyBody = IR.block(IR.exprResult(IR.call(IR.name("cleanup"))));
    Node result = IR.tryCatchFinally(tryBody, catchNode, finallyBody);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_33_01() throws Exception {
	try {
    Node tryBlock = IR.block();
    Node finallyBlock = IR.block();
    IR.tryFinally(tryBlock, finallyBlock);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_33_31() throws Exception {
	try {
    Node tryBody = IR.labelName("tryLabel");
    Node finallyBody = IR.labelName("finallyLabel");
    IR.tryFinally(tryBody, finallyBody);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_33_41() throws Exception {
	try {
    Node tryBlock = IR.block(IR.exprResult(IR.number(1)));
    Node finallyBlock = IR.block(IR.exprResult(IR.number(2)));
    IR.tryFinally(tryBlock, finallyBlock);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
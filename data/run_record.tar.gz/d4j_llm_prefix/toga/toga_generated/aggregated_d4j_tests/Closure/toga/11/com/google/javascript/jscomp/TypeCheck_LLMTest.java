package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.TernaryValue;
import static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.JSDocInfo;
import java.util.Iterator;
import static com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import static com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import com.google.javascript.rhino.jstype.ObjectType;
import com.google.javascript.rhino.jstype.FunctionType;
import static com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
import java.util.Set;
import static com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.rhino.jstype.EnumType;
import static com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
import java.util.HashMap;
import com.google.javascript.jscomp.CheckLevel;
import static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.javascript.jscomp.type.ReverseAbstractInterpreter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypeCheck_LLMTest extends TypeCheck_LLMTest_scaffolding {
    
@Test
public void test_13_21() throws Exception {

    NodeTraversal t = null;
    Node n = Node.newString("prop");
    Node parent = new Node(Token.EXPR_RESULT);
    Node objNode = Node.newString("obj");
    n.addChildToFront(objNode);

    JSType nullType = null;



    }

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashSet;
import javax.annotation.Nullable;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.jstype.FunctionType;
import com.google.javascript.rhino.jstype.JSType;
import com.google.common.base.Predicate;
import java.util.Collections;
import com.google.common.base.Predicates;
import java.util.Arrays;
import com.google.javascript.rhino.Node;
import java.util.Map;
import com.google.javascript.rhino.Token;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Collection;
import com.google.common.collect.ImmutableSet;
import com.google.javascript.rhino.TokenStream;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.jstype.TernaryValue;
import java.util.Set;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NodeUtil_LLMTest extends NodeUtil_LLMTest_scaffolding {
    
@Test
public void test_81_01() throws Exception {

    Node mathName = Node.newString(Token.NAME, "Math");
    Node randomProp = Node.newString(Token.STRING, "random");
    Node getProp = new Node(Token.GETPROP, mathName, randomProp);
    Node callNode = new Node(Token.CALL, getProp);

    NodeUtil.functionCallHasSideEffects(callNode, null);


    }

@Test
public void test_81_11() throws Exception {

    Node fooName = Node.newString(Token.NAME, "foo");
    Node barProp = Node.newString(Token.STRING, "bar");
    Node getProp = new Node(Token.GETPROP, fooName, barProp);
    Node callNode = new Node(Token.CALL, getProp);

    NodeUtil.functionCallHasSideEffects(callNode, null);


    }

@Test
public void test_81_21() throws Exception {

    Node mathName = Node.newString(Token.NAME, "Math");
    Node absProp = Node.newString(Token.STRING, "abs");
    Node getProp = new Node(Token.GETPROP, mathName, absProp);
    Node callNode = new Node(Token.CALL, getProp);

    AbstractCompiler compiler = null;

    NodeUtil.functionCallHasSideEffects(callNode, compiler);


    }

@Test
public void test_81_31() throws Exception {
	try {

    Node fooName = Node.newString(Token.NAME, "foo");
    Node mathProp = Node.newString(Token.STRING, "Math");
    Node getProp1 = new Node(Token.GETPROP, fooName, mathProp);
    Node randomProp = Node.newString(Token.STRING, "random");
    Node getProp2 = new Node(Token.GETPROP, getProp1, randomProp);
    Node callNode = new Node(Token.CALL, getProp2);

    NodeUtil.functionCallHasSideEffects(callNode, null);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.base.Predicates;
import com.google.common.base.Predicate;
import com.google.common.collect.Maps;
import java.util.Collections;
import java.util.List;
import com.google.common.base.Preconditions;
import javax.annotation.Nullable;
import java.util.Collection;
import com.google.javascript.rhino.Token;
import java.util.HashSet;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.collect.ImmutableSet;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.TokenStream;
import java.util.Set;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NodeUtil_LLMTest extends NodeUtil_LLMTest_scaffolding {
    
@Test
public void test_120_21() throws Exception {
    Set<String> defines = new HashSet<>();
    Node child = Node.newNumber(1);
    Node posNode = new Node(Token.POS, child);

    NodeUtil.isValidDefineValue(posNode, defines);


    }

@Test
public void test_120_31() throws Exception {
    Set<String> defines = new HashSet<>();
    Node invalidChild = new Node(Token.THIS);
    Node posNode = new Node(Token.POS, invalidChild);

    NodeUtil.isValidDefineValue(posNode, defines);


    }

@Test
public void test_120_41() throws Exception {
    Set<String> defines = new HashSet<>();
    Node num1 = Node.newNumber(1);
    Node num2 = Node.newNumber(2);
    Node num3 = Node.newNumber(3);

    Node addNode = new Node(Token.ADD, num1, num2);
    Node subNode = new Node(Token.SUB, addNode, num3);
    Node posNode = new Node(Token.POS, subNode);

    NodeUtil.isValidDefineValue(posNode, defines);


    }

}
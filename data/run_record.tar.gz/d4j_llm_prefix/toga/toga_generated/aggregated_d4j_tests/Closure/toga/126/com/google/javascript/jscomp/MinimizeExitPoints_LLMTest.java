package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import com.google.javascript.rhino.IR;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.jstype.TernaryValue;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MinimizeExitPoints_LLMTest extends MinimizeExitPoints_LLMTest_scaffolding {
    
@Test
public void test_158_01() throws Exception {
    Node ifNode = new Node(Token.IF);
    Node condition = new Node(Token.TRUE);
    Node ifBlock = new Node(Token.BLOCK);
    ifNode.addChildToFront(condition);
    ifNode.addChildToBack(ifBlock);

    MinimizeExitPoints instance = new MinimizeExitPoints(null);
    instance.tryMinimizeExits(ifNode, Token.BREAK, "label");


    }

@Test
public void test_158_21() throws Exception {
    Node tryNode = new Node(Token.TRY);
    Node tryBlock = new Node(Token.BLOCK);
    Node finallyBlock = new Node(Token.BLOCK);

    tryNode.addChildToFront(tryBlock);
    tryNode.addChildToBack(finallyBlock);

    MinimizeExitPoints instance = new MinimizeExitPoints(null);
    instance.tryMinimizeExits(tryNode, Token.BREAK, "label");


    }

@Test
public void test_158_31() throws Exception {
    Node labelNode = new Node(Token.LABEL);
    Node labelNameNode = Node.newString("label");
    Node labelBlock = new Node(Token.BLOCK);

    labelNode.addChildToFront(labelNameNode);
    labelNode.addChildToBack(labelBlock);

    MinimizeExitPoints instance = new MinimizeExitPoints(null);
    instance.tryMinimizeExits(labelNode, Token.BREAK, "label");


    }

@Test
public void test_158_41() throws Exception {
    Node blockNode = new Node(Token.BLOCK);
    Node childNode1 = new Node(Token.EMPTY);
    Node childNode2 = new Node(Token.EMPTY);

    blockNode.addChildToBack(childNode1);
    blockNode.addChildToBack(childNode2);

    MinimizeExitPoints instance = new MinimizeExitPoints(null);
    instance.tryMinimizeExits(blockNode, Token.BREAK, "label");


    }

}
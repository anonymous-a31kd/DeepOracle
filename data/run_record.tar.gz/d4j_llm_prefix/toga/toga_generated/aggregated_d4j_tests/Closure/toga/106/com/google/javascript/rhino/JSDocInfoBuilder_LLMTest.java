package com.google.javascript.rhino;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.JSDocInfo.Visibility;
import java.util.Set;
import com.google.javascript.rhino.JSDocInfoBuilder;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JSDocInfoBuilder_LLMTest extends JSDocInfoBuilder_LLMTest_scaffolding {
    
@Test
public void test_135_01() throws Exception {
    JSDocInfoBuilder builder = new JSDocInfoBuilder(true);
    builder.recordBlockDescription("test description");



    }

@Test
public void test_135_11() throws Exception {
    JSDocInfoBuilder builder = new JSDocInfoBuilder(false);
    builder.recordBlockDescription("test description");



    }

@Test
public void test_135_21() throws Exception {
    JSDocInfoBuilder builder = new JSDocInfoBuilder(true);
    builder.recordBlockDescription("");
      assertTrue(builder.isPopulated());
}

@Test
public void test_135_31() throws Exception {
    JSDocInfoBuilder builder = new JSDocInfoBuilder(false);
    builder.recordBlockDescription(null);



    }

@Test
public void test_135_41() throws Exception {
    JSDocInfoBuilder builder = new JSDocInfoBuilder(true);
    builder.recordBlockDescription("first");
    builder.recordBlockDescription("second");



    }

}
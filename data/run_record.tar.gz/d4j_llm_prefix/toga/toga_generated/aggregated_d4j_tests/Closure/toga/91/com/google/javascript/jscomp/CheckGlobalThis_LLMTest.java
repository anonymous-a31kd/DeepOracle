package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.NodeTraversal.Callback;
import com.google.javascript.jscomp.CheckLevel;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CheckGlobalThis_LLMTest extends CheckGlobalThis_LLMTest_scaffolding {
    
@Test
public void test_118_31() throws Exception {
    Node functionNode = new Node(Token.FUNCTION);
    Node blockNode = new Node(Token.BLOCK);

    blockNode.addChildToBack(functionNode);

    CheckGlobalThis checker = new CheckGlobalThis(null, null);
    boolean result = checker.shouldTraverse(null, functionNode, blockNode);



    }

}
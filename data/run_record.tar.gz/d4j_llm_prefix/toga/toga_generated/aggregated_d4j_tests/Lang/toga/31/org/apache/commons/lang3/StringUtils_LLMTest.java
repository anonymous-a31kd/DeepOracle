package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import java.util.Locale;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_179_01() throws Exception {
    char[] searchChars = {'a', 'b', 'c'};
    StringUtils.containsAny("hello", searchChars);


    }

@Test
public void test_179_11() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00'};
    StringUtils.containsAny("hello\uD800\uDC00world", searchChars);


    }

@Test
public void test_179_21() throws Exception {
    char[] searchChars = {'\uD800', 'x'};
    StringUtils.containsAny("hello\uD800xworld", searchChars);


    }

@Test
public void test_179_31() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00'};
    StringUtils.containsAny("hello\uD800\uDC00", searchChars);


    }

@Test
public void test_179_41() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00', 'a'};
    StringUtils.containsAny("hello", searchChars);


    }

@Test
public void test_179_51() throws Exception {
    char[] searchChars = {'a', 'b', 'c'};
    StringUtils.containsAny("", searchChars);


    }

@Test
public void test_179_61() throws Exception {
    char[] searchChars = {};
    StringUtils.containsAny("hello", searchChars);


    }

@Test
public void test_179_71() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00', 'l'};
    StringUtils.containsAny("he\uD800\uDC00llo", searchChars);


    }

}
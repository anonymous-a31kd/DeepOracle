package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class RandomStringUtils_LLMTest extends RandomStringUtils_LLMTest_scaffolding {
    
@Test
public void test_161_11() throws Exception {
	try {
    char[] chars = {'a', 'b', 'c'};
    RandomStringUtils.random(3, 0, 0, true, true, chars, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_21() throws Exception {
	try {
    RandomStringUtils.random(5, 0, 0, true, true, null, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_31() throws Exception {
	try {
    char[] chars = {'a', 'b', 'c', 'd', 'e'};
    RandomStringUtils.random(3, 0, 0, false, false, chars, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_41() throws Exception {
	try {
    RandomStringUtils.random(5, 0, 0, false, false, null, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_161_61() throws Exception {
	try {
    RandomStringUtils.random(0, 0, 0, true, true, null, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.apache.commons.lang.enums;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import org.apache.commons.lang.enums.ValuedEnum;
import org.apache.commons.lang.ClassUtils;
import java.util.Iterator;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ValuedEnum_LLMTest extends ValuedEnum_LLMTest_scaffolding {
    
@Test
public void test_205_01() throws Exception {

    ValuedEnum testEnum = new ValuedEnum("TestName", 123) {};
    String result = testEnum.toString();



    }

@Test
public void test_205_21() throws Exception {

    ValuedEnum testEnum = new ValuedEnum("Negative", -1) {};
    String result = testEnum.toString();



    }

@Test
public void test_205_31()  throws Exception {

    Object testObj = new Object() {
        public int getValue() {
            return 789;
        }
    };

    ValuedEnum testEnum = new ValuedEnum("Test", 0) {};
    Method method = ValuedEnum.class.getDeclaredMethod("getValueInOtherClassLoader", Object.class);
    method.setAccessible(true);
    int result = (Integer) method.invoke(testEnum, testObj);
      assertEquals(1, result);
}

}
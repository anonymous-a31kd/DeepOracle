package org.apache.commons.lang3.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Date;
import java.util.Calendar;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;
import java.util.TimeZone;
import java.text.ParseException;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateUtils_LLMTest extends DateUtils_LLMTest_scaffolding {
    
@Test
public void test_169_01() throws Exception {
	try {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 10);
    cal2.set(Calendar.HOUR_OF_DAY, 10);
    DateUtils.isSameLocalTime(cal1, cal2);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_169_11() throws Exception {
	try {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 22);
    cal2.set(Calendar.HOUR_OF_DAY, 22);
    DateUtils.isSameLocalTime(cal1, cal2);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_169_21() throws Exception {
	try {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 0);
    cal2.set(Calendar.HOUR_OF_DAY, 12);
    DateUtils.isSameLocalTime(cal1, cal2);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_169_31() throws Exception {
	try {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 1);
    cal2.set(Calendar.HOUR_OF_DAY, 13);
    DateUtils.isSameLocalTime(cal1, cal2);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_169_51() throws Exception {
	try {
    Calendar cal1 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    Calendar cal2 = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"));
    cal1.set(Calendar.HOUR_OF_DAY, 10);
    cal2.set(Calendar.HOUR_OF_DAY, 10);
    DateUtils.isSameLocalTime(cal1, cal2);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
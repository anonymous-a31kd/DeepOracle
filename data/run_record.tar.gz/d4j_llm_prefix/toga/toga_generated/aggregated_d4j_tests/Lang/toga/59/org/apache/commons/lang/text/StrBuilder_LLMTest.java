package org.apache.commons.lang.text;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Reader;
import org.apache.commons.lang.text.StrBuilder;
import java.util.Collection;
import java.util.Iterator;
import org.apache.commons.lang.ArrayUtils;
import java.util.List;
import org.apache.commons.lang.SystemUtils;
import java.io.Writer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StrBuilder_LLMTest extends StrBuilder_LLMTest_scaffolding {
    
@Test
public void test_197_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("abcdef", 4, '-');
      assertEquals(1, sb.length());
}

@Test
public void test_197_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("abcd", 4, '-');
      assertEquals(1, sb.length());
}

@Test
public void test_197_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.setNullText("NULL");
    sb.appendFixedWidthPadRight(null, 4, '-');
      assertEquals(1, sb.length());
}

@Test
public void test_197_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("ab", 4, '-');
      assertEquals(1, sb.length());
}

@Test
public void test_197_41() throws Exception {
    StrBuilder sb = new StrBuilder("initial");
    sb.appendFixedWidthPadRight("abc", 0, '-');
      assertEquals(0, sb.length());
}

}
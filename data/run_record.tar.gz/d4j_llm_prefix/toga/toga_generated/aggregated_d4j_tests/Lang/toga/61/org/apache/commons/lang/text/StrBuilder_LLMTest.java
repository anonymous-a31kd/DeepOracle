package org.apache.commons.lang.text;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.SystemUtils;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.io.Reader;
import org.apache.commons.lang.text.StrBuilder;
import java.io.Writer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StrBuilder_LLMTest extends StrBuilder_LLMTest_scaffolding {
    
@Test
public void test_200_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("test");
    sb.setLength(4);
    int result = sb.indexOf("es", 0);



    }

@Test
public void test_200_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("test");
    sb.setLength(4);
    int result = sb.indexOf("st", 2);



    }

@Test
public void test_200_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("testing");
    sb.setLength(7);
    int result = sb.indexOf("ing", 4);



    }

@Test
public void test_200_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("test");
    sb.setLength(4);
    int result = sb.indexOf("testx", 0);



    }

@Test
public void test_200_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.setLength(0);
    int result = sb.indexOf("test", 0);



    }

@Test
public void test_200_51() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("test");
    sb.setLength(4);
    int result = sb.indexOf("t", 4);



    }

@Test
public void test_200_61() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("test");
    sb.setLength(4);
    int result = sb.indexOf("t", 5);



    }

}
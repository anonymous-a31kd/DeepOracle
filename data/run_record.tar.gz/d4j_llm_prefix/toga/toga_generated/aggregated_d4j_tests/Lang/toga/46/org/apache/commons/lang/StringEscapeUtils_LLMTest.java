package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.exception.NestableRuntimeException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringEscapeUtils_LLMTest extends StringEscapeUtils_LLMTest_scaffolding {
    
@Test
public void test_153_01() throws Exception {
    String result = StringEscapeUtils.escapeJava(null);


    }

@Test
public void test_153_11() throws Exception {
    String result = StringEscapeUtils.escapeJava("");


    }

@Test
public void test_153_21() throws Exception {
    String result = StringEscapeUtils.escapeJava("plain text");


    }

@Test
public void test_153_31() throws Exception {
    String result = StringEscapeUtils.escapeJava("text\nwith\nnewlines");


    }

@Test
public void test_153_41() throws Exception {
    String result = StringEscapeUtils.escapeJava("\"quoted\" text");


    }

@Test
public void test_153_51() throws Exception {
    String result = StringEscapeUtils.escapeJava("text\\with\\backslashes");


    }

@Test
public void test_153_61() throws Exception {
    String result = StringEscapeUtils.escapeJava("text with \u1234 unicode");


    }

@Test
public void test_153_71() throws Exception {
    String result = StringEscapeUtils.escapeJava("text with \t tab and \b backspace");


    }

@Test
public void test_154_01() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript(null);


    }

@Test
public void test_154_11() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("");


    }

@Test
public void test_154_21() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("abc123");


    }

@Test
public void test_154_31() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("a\nb\tc");


    }

@Test
public void test_154_41() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("don't");


    }

@Test
public void test_154_51() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("\"quote\"");


    }

@Test
public void test_154_61() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("path\\to\\file");


    }

@Test
public void test_154_71() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("日本語");


    }

@Test
public void test_154_81() throws Exception {
	try {
    String result = StringEscapeUtils.escapeJavaScript("Line1\nLine2\tDon't \"quote\" \\path");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_155_01()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, null);


    }

@Test
public void test_155_11()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "");


    }

@Test
public void test_155_21()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test");


    }

@Test
public void test_155_31()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test\n\r\t\b\f\"\\");


    }

@Test
public void test_155_41()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test\u1234");


    }

@Test
public void test_155_51()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test'");


    }

@Test
public void test_156_01()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, null);


    }

@Test
public void test_156_11()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "");


    }

@Test
public void test_156_21()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "test");


    }

@Test
public void test_156_31()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "line\nbreak");


    }

@Test
public void test_156_41()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "don't");


    }

@Test
public void test_156_51()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "日本語");


    }

@Test
public void test_156_61()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "\b\t\n\f\r");


    }

@Test
public void test_156_71()  throws Exception {
    Writer writer = new StringWriter();
    writer.close();
    StringEscapeUtils.escapeJavaScript(writer, "test");


    }

}
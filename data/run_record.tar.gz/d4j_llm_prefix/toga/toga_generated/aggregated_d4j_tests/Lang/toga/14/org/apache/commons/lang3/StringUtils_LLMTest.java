package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.commons.lang3.StringUtils;
import java.util.Iterator;
import java.lang.reflect.Method;
import java.util.Locale;
import java.lang.reflect.InvocationTargetException;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.nio.CharBuffer;
import java.util.List;
import java.util.Arrays;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_162_01() throws Exception {



    }

@Test
public void test_162_11() throws Exception {
    String str = "test";



    }

@Test
public void test_162_21() throws Exception {



    }

@Test
public void test_162_31() throws Exception {
    CharBuffer buffer1 = CharBuffer.wrap("test");
    CharBuffer buffer2 = CharBuffer.wrap("test");
    CharBuffer buffer3 = CharBuffer.wrap("different");



    }

@Test
public void test_162_41() throws Exception {
    StringBuilder builder = new StringBuilder("test");
    String str = "test";
    String differentStr = "different";



    }

@Test
public void test_162_51() throws Exception {
    CharBuffer shortBuffer = CharBuffer.wrap("short");
    CharBuffer longBuffer = CharBuffer.wrap("longer");



    }

}
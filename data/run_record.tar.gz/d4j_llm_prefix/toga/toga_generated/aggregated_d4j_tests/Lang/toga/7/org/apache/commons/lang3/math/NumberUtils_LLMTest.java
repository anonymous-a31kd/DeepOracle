package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_138_01() throws Exception {
	try {
    NumberUtils.createBigDecimal(null);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_138_51() throws Exception {
	try {
    NumberUtils.createBigDecimal("123.45");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_138_61() throws Exception {
	try {
    NumberUtils.createBigDecimal("-123.45");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_138_71() throws Exception {
	try {
    NumberUtils.createBigDecimal("+123.45");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_138_81() throws Exception {
	try {
    NumberUtils.createBigDecimal("12345678901234567890.1234567890");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_139_01() throws Exception {
	try {

    NumberUtils.createNumber("--123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_139_11() throws Exception {
	try {

    NumberUtils.createNumber("-123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_139_21() throws Exception {
	try {

    NumberUtils.createNumber("0x1A");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_139_31() throws Exception {
	try {

    NumberUtils.createNumber("-0x1A");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_139_51() throws Exception {
	try {

    NumberUtils.createNumber(null);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.apache.commons.lang3.text.translate;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Writer;
import java.io.StringWriter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumericEntityUnescaper_LLMTest extends NumericEntityUnescaper_LLMTest_scaffolding {
    
@Test
public void test_142_01()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#65;";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_11()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#x41;";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_21()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_31()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#x";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_41()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#x41";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_51()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#65";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_61()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "&#xGH;";
    int result = unescaper.translate(input, 0, writer);


    }

@Test
public void test_142_71()  throws Exception {
    NumericEntityUnescaper unescaper = new NumericEntityUnescaper();
    Writer writer = new StringWriter();
    CharSequence input = "ab&#65";
    int result = unescaper.translate(input, 2, writer);


    }

}
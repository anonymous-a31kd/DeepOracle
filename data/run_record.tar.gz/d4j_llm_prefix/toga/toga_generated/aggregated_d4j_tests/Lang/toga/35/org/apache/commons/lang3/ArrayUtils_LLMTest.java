package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Array;
import org.apache.commons.lang3.builder.ToStringStyle;
import java.util.HashMap;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArrayUtils_LLMTest extends ArrayUtils_LLMTest_scaffolding {
    
@Test
public void test_144_01() throws Exception {
    String[] array = {"a", "b"};
    String[] result = ArrayUtils.add(array, "c");


    }

@Test
public void test_144_11() throws Exception {
    String[] array = null;
    String[] result = ArrayUtils.add(array, "a");


    }

@Test
public void test_144_31() throws Exception {
    String[] array = new String[0];
    String[] result = ArrayUtils.add(array, "a");


    }

@Test
public void test_144_41() throws Exception {
    String[] array = {"a", "b"};
    String[] result = ArrayUtils.add(array, null);


    }

@Test
public void test_145_01() throws Exception {
    ArrayUtils.add((Object[]) null, 0, null);


    }

@Test
public void test_145_11() throws Exception {
    String element = "test";
    String[] result = ArrayUtils.add(null, 0, element);



    }

@Test
public void test_145_21() throws Exception {
    String[] array = new String[] {"existing"};
    String[] result = ArrayUtils.add(array, 1, null);



    }

@Test
public void test_145_31() throws Exception {
    String[] array = new String[] {"existing"};
    String element = "new";
    String[] result = ArrayUtils.add(array, 1, element);



    }

@Test
public void test_145_41() throws Exception {
    String[] array = new String[0];
    String element = "new";
    String[] result = ArrayUtils.add(array, 0, element);



    }

}
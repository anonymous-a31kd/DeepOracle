package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.regex.Pattern;
import java.io.File;
import org.apache.commons.lang3.SystemUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class SystemUtils_LLMTest extends SystemUtils_LLMTest_scaffolding {
    
@Test
public void test_175_01() throws Exception {
    SystemUtils.toJavaVersionInt("1");


    }

@Test
public void test_175_11() throws Exception {
    SystemUtils.toJavaVersionInt("1.8");


    }

@Test
public void test_175_21() throws Exception {
	try {
    SystemUtils.toJavaVersionInt("1.8.0");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_175_31() throws Exception {
    SystemUtils.toJavaVersionInt("1.8.0_231");


    }

@Test
public void test_175_41() throws Exception {
    SystemUtils.toJavaVersionInt("");


    }

@Test
public void test_175_51() throws Exception {
    SystemUtils.toJavaVersionInt(null);


    }

@Test
public void test_175_61() throws Exception {
	try {
    SystemUtils.toJavaVersionInt("1.x.y");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_175_71() throws Exception {
    SystemUtils.toJavaVersionInt("11.0.2");


    }

@Test
public void test_175_81() throws Exception {
    SystemUtils.toJavaVersionInt("01.08.00");


    }

@Test
public void test_175_91() throws Exception {
    SystemUtils.toJavaVersionInt("1.8.0_231-b11");


    }

}
package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Set;
import java.util.Arrays;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocaleUtils_LLMTest extends LocaleUtils_LLMTest_scaffolding {
    
@Test
public void test_137_01() throws Exception {
	try {
    LocaleUtils.toLocale("_US");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_137_11() throws Exception {
	try {
    LocaleUtils.toLocale("_US_WINDOWS");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_137_61() throws Exception {
	try {
    LocaleUtils.toLocale("en");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_137_71() throws Exception {
	try {
    LocaleUtils.toLocale("en_US");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_137_81() throws Exception {
	try {
    LocaleUtils.toLocale("en_US_WINDOWS");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
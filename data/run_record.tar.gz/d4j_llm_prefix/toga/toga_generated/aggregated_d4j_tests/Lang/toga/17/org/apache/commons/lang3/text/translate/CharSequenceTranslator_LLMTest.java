package org.apache.commons.lang3.text.translate;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Writer;
import java.util.Locale;
import java.io.StringWriter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CharSequenceTranslator_LLMTest extends CharSequenceTranslator_LLMTest_scaffolding {
    
@Test
public void test_165_01()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            return 0;
        }
    };
    Writer writer = new StringWriter();
    translator.translate("", writer);


    }

@Test
public void test_165_11()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            return 0;
        }
    };
    Writer writer = new StringWriter();
    translator.translate("a", writer);


    }

@Test
public void test_165_21()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            return 0;
        }
    };
    Writer writer = new StringWriter();
    translator.translate("\uD83D\uDE00", writer);


    }

@Test
public void test_165_31()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            out.write("X");
            return 1;
        }
    };
    Writer writer = new StringWriter();
    translator.translate("abc", writer);


    }

@Test
public void test_165_41()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            if (index % 2 == 0) {
                out.write("X");
                return 1;
            }
            return 0;
        }
    };
    Writer writer = new StringWriter();
    translator.translate("abcdef", writer);


    }

@Test
public void test_165_51()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            out.write("X");
            return 2;
        }
    };
    Writer writer = new StringWriter();
    translator.translate("\uD83D\uDE00\uD83D\uDE01", writer);


    }

}
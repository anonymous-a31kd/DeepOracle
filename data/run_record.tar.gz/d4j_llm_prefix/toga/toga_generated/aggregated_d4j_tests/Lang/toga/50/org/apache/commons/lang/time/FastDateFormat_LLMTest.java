package org.apache.commons.lang.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.text.FieldPosition;
import java.util.Date;
import java.util.List;
import java.io.ObjectInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.apache.commons.lang.Validate;
import java.text.Format;
import java.util.TimeZone;
import java.text.ParsePosition;
import java.util.GregorianCalendar;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Calendar;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FastDateFormat_LLMTest extends FastDateFormat_LLMTest_scaffolding {
    
@Test
public void test_191_01() throws Exception {
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, null);



    }

@Test
public void test_191_11() throws Exception {
    Locale testLocale = Locale.FRANCE;
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.MEDIUM, null, testLocale);



    }

@Test
public void test_191_21() throws Exception {
    TimeZone testZone = TimeZone.getTimeZone("GMT");
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.LONG, testZone, null);



    }

@Test
public void test_191_31() throws Exception {
    TimeZone testZone = TimeZone.getTimeZone("PST");
    Locale testLocale = Locale.JAPAN;
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.FULL, testZone, testLocale);



    }

@Test
public void test_191_41() throws Exception {
    FastDateFormat format1 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, null);
    FastDateFormat format2 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, null);



    }

@Test
public void test_191_51() throws Exception {
    FastDateFormat format1 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, Locale.US);
    FastDateFormat format2 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, Locale.UK);



    }

@Test
public void test_192_01() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.SHORT,
    FastDateFormat.SHORT,
    TimeZone.getDefault(),
    null
    );


    }

@Test
public void test_192_11() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.MEDIUM,
    FastDateFormat.MEDIUM,
    TimeZone.getTimeZone("GMT"),
    Locale.FRANCE
    );


    }

@Test
public void test_192_21() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.LONG,
    FastDateFormat.LONG,
    null,
    Locale.JAPAN
    );


    }

@Test
public void test_192_31() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.FULL,
    FastDateFormat.FULL,
    null,
    null
    );


    }

@Test
public void test_192_41() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.SHORT,
    FastDateFormat.FULL,
    TimeZone.getDefault(),
    Locale.getDefault()
    );


    }

}
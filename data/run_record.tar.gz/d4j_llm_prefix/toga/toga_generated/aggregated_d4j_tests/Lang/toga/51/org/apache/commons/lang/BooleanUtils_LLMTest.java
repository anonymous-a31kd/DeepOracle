package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.math.NumberUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class BooleanUtils_LLMTest extends BooleanUtils_LLMTest_scaffolding {
    
@Test
public void test_193_01() throws Exception {

    BooleanUtils.toBoolean("yes");
    BooleanUtils.toBoolean("Yes");
    BooleanUtils.toBoolean("yEs");
    BooleanUtils.toBoolean("yeS");
    BooleanUtils.toBoolean("YEs");
    BooleanUtils.toBoolean("YeS");
    BooleanUtils.toBoolean("yES");
    BooleanUtils.toBoolean("YES");


    }

@Test
public void test_193_11() throws Exception {
	try {

    BooleanUtils.toBoolean("yex");
    BooleanUtils.toBoolean("yep");
    BooleanUtils.toBoolean("yss");
    BooleanUtils.toBoolean("yee");
    BooleanUtils.toBoolean("YEX");
    BooleanUtils.toBoolean("YEP");
    BooleanUtils.toBoolean("YSS");
    BooleanUtils.toBoolean("YEE");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_193_21() throws Exception {
	try {

    BooleanUtils.toBoolean("abc");
    BooleanUtils.toBoolean("123");
    BooleanUtils.toBoolean("no");
    BooleanUtils.toBoolean("off");
    BooleanUtils.toBoolean("xyz");
    BooleanUtils.toBoolean("   ");
    BooleanUtils.toBoolean("tru");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_193_31() throws Exception {
	try {

    BooleanUtils.toBoolean("yEs");
    BooleanUtils.toBoolean("YeS");
    BooleanUtils.toBoolean("YEs");
    BooleanUtils.toBoolean("yES");
    BooleanUtils.toBoolean("yEx");
    BooleanUtils.toBoolean("YeP");
    BooleanUtils.toBoolean("Yss");
    BooleanUtils.toBoolean("yEe");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_193_41() throws Exception {

    BooleanUtils.toBoolean("");
    BooleanUtils.toBoolean("y");
    BooleanUtils.toBoolean("ye");
    BooleanUtils.toBoolean("yes");
    BooleanUtils.toBoolean("yess");


    }

}
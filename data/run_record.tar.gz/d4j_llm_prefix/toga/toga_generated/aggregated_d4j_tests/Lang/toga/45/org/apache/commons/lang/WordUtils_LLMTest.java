package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class WordUtils_LLMTest extends WordUtils_LLMTest_scaffolding {
    
@Test
public void test_150_01() throws Exception {
    String result = WordUtils.abbreviate("short", 10, 15, "...");



    }

@Test
public void test_150_11() throws Exception {
    String result = WordUtils.abbreviate("exact", 5, 10, "...");



    }

@Test
public void test_150_21() throws Exception {
    String result = WordUtils.abbreviate("longstring", 4, 7, "...");



    }

@Test
public void test_150_31() throws Exception {
    String result = WordUtils.abbreviate("test", 2, -1, "...");



    }

@Test
public void test_150_41() throws Exception {
    String result = WordUtils.abbreviate("", 5, 10, "...");



    }

@Test
public void test_150_51() throws Exception {
    String result = WordUtils.abbreviate(null, 5, 10, "...");



    }

}
package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_189_51() throws Exception {
	try {
    NumberUtils.createNumber("5");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_189_61() throws Exception {
	try {
    NumberUtils.createNumber("123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_189_81() throws Exception {
    NumberUtils.createNumber(null);


    }

}
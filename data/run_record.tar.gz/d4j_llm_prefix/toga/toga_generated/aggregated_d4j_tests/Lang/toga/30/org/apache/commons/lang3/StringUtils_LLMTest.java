package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
import java.util.Locale;
import org.apache.commons.lang3.text.WordUtils;
import java.util.List;
import java.util.Iterator;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_176_01() throws Exception {
    char[] searchChars = {'a', 'b'};
    StringUtils.containsAny(null, searchChars);


    }

@Test
public void test_176_11() throws Exception {
    char[] searchChars = {'a', 'b'};
    StringUtils.containsAny("", searchChars);


    }

@Test
public void test_176_31() throws Exception {
    StringUtils.containsAny("abc", new char[0]);


    }

@Test
public void test_176_41() throws Exception {
    char[] searchChars = {'x', 'y', 'z'};
    StringUtils.containsAny("abcxyz", searchChars);


    }

@Test
public void test_176_51() throws Exception {
    char[] searchChars = {'\uD800', 'b'};
    StringUtils.containsAny("a\uD800", searchChars);


    }

@Test
public void test_176_61() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00', 'b'};
    StringUtils.containsAny("a\uD800\uDC00", searchChars);


    }

@Test
public void test_176_71() throws Exception {
    char[] searchChars = {'\uD800', 'b'};
    StringUtils.containsAny("a\uD800c", searchChars);


    }

@Test
public void test_176_81() throws Exception {
    char[] searchChars = {'\uD800', 'b'};
    StringUtils.containsAny("abc\uD800", searchChars);


    }

@Test
public void test_176_91() throws Exception {
    char[] searchChars = {'a', '\uD800'};
    StringUtils.containsAny("\uD800", searchChars);


    }

@Test
public void test_177_01() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC00'};
    int result = StringUtils.indexOfAny("\uD800\uDC00", searchChars);


    }

@Test
public void test_177_11() throws Exception {

    char[] searchChars = new char[]{'\uD800'};
    int result = StringUtils.indexOfAny("\uD800", searchChars);


    }

@Test
public void test_177_21() throws Exception {

    char[] searchChars = new char[]{'\uDC00'};
    int result = StringUtils.indexOfAny("\uDC00", searchChars);


    }

@Test
public void test_177_31() throws Exception {

    char[] searchChars = new char[]{'a', '\uD800', '\uDC00', 'b'};
    int result = StringUtils.indexOfAny("x\uD800\uDC00y", searchChars);


    }

@Test
public void test_177_41() throws Exception {

    char[] searchChars = new char[]{'a', 'b', 'c'};
    int result = StringUtils.indexOfAny("xyzabc", searchChars);


    }

@Test
public void test_177_51() throws Exception {

    char[] searchChars = new char[]{'a', 'b'};
    int result = StringUtils.indexOfAny("", searchChars);


    }

@Test
public void test_177_61() throws Exception {

    char[] searchChars = new char[]{};
    int result = StringUtils.indexOfAny("abc", searchChars);


    }

@Test
public void test_178_01() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC00'};
    int result = StringUtils.indexOfAnyBut("abc", searchChars);


    }

@Test
public void test_178_11() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC00'};
    int result = StringUtils.indexOfAnyBut("\uD800\uDC00abc", searchChars);


    }

@Test
public void test_178_21() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC01'};
    int result = StringUtils.indexOfAnyBut("\uD800\uDC00abc", searchChars);


    }

@Test
public void test_178_31() throws Exception {

    char[] searchChars = new char[]{'\uD800'};
    int result = StringUtils.indexOfAnyBut("\uD800\uDC00abc", searchChars);


    }

@Test
public void test_178_41() throws Exception {

    char[] searchChars = new char[]{'a', 'b', 'c'};
    int result = StringUtils.indexOfAnyBut("def", searchChars);


    }

@Test
public void test_178_51() throws Exception {

    char[] searchChars = new char[]{'a', 'b'};
    int result = StringUtils.indexOfAnyBut("", searchChars);


    }

@Test
public void test_178_61() throws Exception {

    char[] searchChars = new char[]{};
    int result = StringUtils.indexOfAnyBut("abc", searchChars);


    }

}
package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.io.Writer;
import java.util.Map;
import java.util.TreeMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Entities_LLMTest extends Entities_LLMTest_scaffolding {
    
@Test
public void test_201_01() throws Exception {
    Entities entities = new Entities();
    String input = "&#1234;";
    entities.unescape(input);


    }

@Test
public void test_201_11() throws Exception {
    Entities entities = new Entities();
    String input = "&#x1A2B;";
    entities.unescape(input);


    }

@Test
public void test_201_21() throws Exception {
    Entities entities = new Entities();
    String input = "&#65536;";
    entities.unescape(input);


    }

@Test
public void test_201_31() throws Exception {
    Entities entities = new Entities();
    String input = "&#x10000;";
    entities.unescape(input);


    }

@Test
public void test_201_41() throws Exception {
    Entities entities = new Entities();
    String input = "&#65535;";
    entities.unescape(input);


    }

@Test
public void test_201_51() throws Exception {
    Entities entities = new Entities();
    String input = "&#xFFFF;";
    entities.unescape(input);


    }

@Test
public void test_201_61() throws Exception {
    Entities entities = new Entities();
    String input = "&#invalid;";
    entities.unescape(input);


    }

@Test
public void test_201_71() throws Exception {
    Entities entities = new Entities();
    String input = "&#xinvalid;";
    entities.unescape(input);


    }

@Test
public void test_202_01()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#x1F600;");


    }

@Test
public void test_202_11()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#x1FFFF;");


    }

@Test
public void test_202_21()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#131071;");


    }

@Test
public void test_202_31()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#xZZZ;");


    }

@Test
public void test_202_41()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#ABC;");


    }

@Test
public void test_202_51()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#xA9;");


    }

@Test
public void test_202_61()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#169;");


    }

}
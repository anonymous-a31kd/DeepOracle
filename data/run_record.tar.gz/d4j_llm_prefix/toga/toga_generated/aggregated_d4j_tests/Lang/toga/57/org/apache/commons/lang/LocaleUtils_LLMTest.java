package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Collections;
import java.util.Set;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocaleUtils_LLMTest extends LocaleUtils_LLMTest_scaffolding {
    
@Test
public void test_161_01() throws Exception {
    LocaleUtils.isAvailableLocale(null);


    }

@Test
public void test_161_11() throws Exception {
    LocaleUtils.isAvailableLocale(Locale.getDefault());


    }

@Test
public void test_161_21() throws Exception {
    LocaleUtils.isAvailableLocale(Locale.US);


    }

@Test
public void test_161_31() throws Exception {
    LocaleUtils.isAvailableLocale(new Locale("xx", "XX"));


    }

@Test
public void test_161_41() throws Exception {
    LocaleUtils.isAvailableLocale(Locale.ENGLISH);


    }

@Test
public void test_161_51() throws Exception {
    LocaleUtils.isAvailableLocale(new Locale("zz", "ZZ"));


    }

}
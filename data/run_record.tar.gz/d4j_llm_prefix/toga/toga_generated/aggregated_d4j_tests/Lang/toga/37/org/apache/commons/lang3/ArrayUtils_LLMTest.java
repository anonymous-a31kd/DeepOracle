package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.builder.ToStringStyle;
import java.util.Map;
import org.apache.commons.lang3.builder.ToStringBuilder;
import java.util.HashMap;
import java.lang.reflect.Array;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.ArrayUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArrayUtils_LLMTest extends ArrayUtils_LLMTest_scaffolding {
    
@Test
public void test_183_01() throws Exception {
    String[] array1 = new String[]{"a", "b"};
    String[] array2 = new String[]{"c", "d"};
    ArrayUtils.addAll(array1, array2);


    }

@Test
public void test_183_11() throws Exception {
    String[] array1 = null;
    String[] array2 = new String[]{"a", "b"};
    ArrayUtils.addAll(array1, array2);


    }

@Test
public void test_183_21() throws Exception {
    String[] array1 = new String[]{"a", "b"};
    String[] array2 = null;
    ArrayUtils.addAll(array1, array2);


    }

@Test
public void test_183_41() throws Exception {
    String[] array1 = new String[0];
    String[] array2 = new String[0];
    ArrayUtils.addAll(array1, array2);


    }

@Test
public void test_183_51() throws Exception {
    Object[] array1 = new Object[]{"a", "b"};
    String[] array2 = new String[]{"c", "d"};
    ArrayUtils.addAll(array1, array2);


    }

}
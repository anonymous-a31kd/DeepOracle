package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
import java.util.Iterator;
import org.apache.commons.lang.StringUtils;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_186_01() throws Exception {
    StringUtils.containsIgnoreCase(null, "abc");
    StringUtils.containsIgnoreCase("abc", null);
    StringUtils.containsIgnoreCase(null, null);


    }

@Test
public void test_186_11() throws Exception {
    StringUtils.containsIgnoreCase("", "");
    StringUtils.containsIgnoreCase("abc", "");
    StringUtils.containsIgnoreCase("", "abc");


    }

@Test
public void test_186_21() throws Exception {
    StringUtils.containsIgnoreCase("abc", "abc");
    StringUtils.containsIgnoreCase("ABC", "abc");
    StringUtils.containsIgnoreCase("abc", "ABC");
    StringUtils.containsIgnoreCase("aBc", "AbC");


    }

@Test
public void test_186_31() throws Exception {
    StringUtils.containsIgnoreCase("xyzabc", "abc");
    StringUtils.containsIgnoreCase("xyzABC", "abc");
    StringUtils.containsIgnoreCase("abcxyz", "abc");
    StringUtils.containsIgnoreCase("ABCxyz", "abc");
    StringUtils.containsIgnoreCase("xabcy", "abc");
    StringUtils.containsIgnoreCase("xABCy", "abc");


    }

@Test
public void test_186_41() throws Exception {
    StringUtils.containsIgnoreCase("abc", "xyz");
    StringUtils.containsIgnoreCase("ABC", "xyz");
    StringUtils.containsIgnoreCase("abc", "XYZ");


    }

@Test
public void test_186_51() throws Exception {
    StringUtils.containsIgnoreCase("a$b#c", "A$B#C");
    StringUtils.containsIgnoreCase("123aBc456", "AbC");
    StringUtils.containsIgnoreCase("äöü", "ÄÖÜ");


    }

@Test
public void test_186_61() throws Exception {
    StringUtils.containsIgnoreCase("abc", "abcdef");
    StringUtils.containsIgnoreCase("ABC", "abcdef");


    }

}
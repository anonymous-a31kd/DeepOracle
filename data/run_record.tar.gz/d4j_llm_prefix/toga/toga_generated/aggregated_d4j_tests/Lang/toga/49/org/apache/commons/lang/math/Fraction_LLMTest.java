package org.apache.commons.lang.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import org.apache.commons.lang.math.Fraction;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Fraction_LLMTest extends Fraction_LLMTest_scaffolding {
    
@Test
public void test_159_01() throws Exception {
    Fraction zeroFraction = Fraction.getFraction(0, 1);
    Fraction result = zeroFraction.reduce();


    }

@Test
public void test_159_11() throws Exception {
    Fraction zeroFraction = Fraction.getFraction(0, 5);
    Fraction result = zeroFraction.reduce();


    }

@Test
public void test_159_21() throws Exception {
    Fraction fraction = Fraction.getFraction(2, 4);
    Fraction result = fraction.reduce();


    }

@Test
public void test_159_31() throws Exception {
    Fraction fraction = Fraction.getFraction(1, 3);
    Fraction result = fraction.reduce();


    }

@Test
public void test_159_41() throws Exception {
    Fraction fraction = Fraction.getFraction(-2, 4);
    Fraction result = fraction.reduce();


    }

}
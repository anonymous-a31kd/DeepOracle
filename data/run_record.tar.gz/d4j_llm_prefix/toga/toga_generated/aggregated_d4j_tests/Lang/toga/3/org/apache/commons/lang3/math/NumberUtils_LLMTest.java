package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Array;
import java.math.BigInteger;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_153_01() throws Exception {
	try {
    NumberUtils.createNumber("123.4567890");
    NumberUtils.createNumber("0.1234567");
    NumberUtils.createNumber("-1.0000000");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_153_11() throws Exception {
	try {
    NumberUtils.createNumber("123.45");
    NumberUtils.createNumber("0.1");
    NumberUtils.createNumber("-999.999999");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_153_21() throws Exception {
	try {
    NumberUtils.createNumber("123.45678901");
    NumberUtils.createNumber("0.12345678");
    NumberUtils.createNumber("-1.00000000");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_153_31() throws Exception {
	try {
    NumberUtils.createNumber("123.456789012345");
    NumberUtils.createNumber("0.1234567890123456");
    NumberUtils.createNumber("-999.9999999999999");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_153_41() throws Exception {
	try {
    NumberUtils.createNumber("123.45678901234567890");
    NumberUtils.createNumber("0.123456789012345678");
    NumberUtils.createNumber("-999.999999999999999");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_153_61() throws Exception {
	try {
    NumberUtils.createNumber("1.2345678e10");
    NumberUtils.createNumber("1.23456789e10");
    NumberUtils.createNumber("1.2345678901234567e10");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
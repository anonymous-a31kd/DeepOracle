package org.apache.commons.lang3.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import org.apache.commons.lang3.Validate;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.ParsePosition;
import java.util.HashMap;
import java.io.ObjectInputStream;
import java.text.DateFormat;
import java.util.Map;
import java.text.DateFormatSymbols;
import java.util.Locale;
import java.util.Date;
import java.text.FieldPosition;
import java.util.TimeZone;
import java.text.Format;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FastDateFormat_LLMTest extends FastDateFormat_LLMTest_scaffolding {
    
@Test
public void test_184_01() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance();
    Calendar calendar = Calendar.getInstance();
    StringBuffer buffer = new StringBuffer();

    format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT"), Locale.US);
    format.format(calendar, buffer);


    }

@Test
public void test_184_11() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT"), Locale.US);
    Calendar calendar = Calendar.getInstance();
    calendar.clear();
    StringBuffer buffer = new StringBuffer();

    format.format(calendar, buffer);


    }

@Test
public void test_184_21() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("GMT"), Locale.US);
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("PST"));
    StringBuffer buffer = new StringBuffer();

    format.format(calendar, buffer);


    }

@Test
public void test_184_41() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("America/New_York"), Locale.US);
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
    calendar.set(2023, Calendar.MARCH, 12, 6, 30);

    StringBuffer buffer = new StringBuffer();
    format.format(calendar, buffer);


    }

}
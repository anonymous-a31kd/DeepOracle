package org.apache.commons.lang.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import java.math.BigDecimal;
import org.apache.commons.lang.StringUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_162_01() throws Exception {
	try {
    NumberUtils.createNumber("123L");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_162_11() throws Exception {
	try {
    NumberUtils.createNumber("-123L");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_162_21() throws Exception {
	try {
    NumberUtils.createNumber("123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_162_31() throws Exception {
	try {
    NumberUtils.createNumber("-123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_162_71() throws Exception {
	try {
    NumberUtils.createNumber(null);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import org.apache.commons.lang.ClassUtils;
import java.util.HashSet;
import java.util.Map;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ClassUtils_LLMTest extends ClassUtils_LLMTest_scaffolding {
    
@Test
public void test_148_01() throws Exception {
    String result = ClassUtils.getPackageName(null, "default");



    }

@Test
public void test_148_11() throws Exception {
    String result = ClassUtils.getPackageName(String.class, "default");



    }

@Test
public void test_148_21() throws Exception {
    class Inner {}
    String result = ClassUtils.getPackageName(Inner.class, "default");



    }

@Test
public void test_148_31() throws Exception {
    String[] array = new String[0];
    String result = ClassUtils.getPackageName(array.getClass(), "default");



    }

@Test
public void test_148_41() throws Exception {
    String[][] array = new String[0][0];
    String result = ClassUtils.getPackageName(array.getClass(), "default");



    }

@Test
public void test_148_51() throws Exception {
    int[] array = new int[0];
    String result = ClassUtils.getPackageName(array.getClass(), "default");



    }

@Test
public void test_149_11() throws Exception {
    ClassUtils.getShortClassName("");


    }

@Test
public void test_149_21() throws Exception {
    ClassUtils.getShortClassName("java.lang.String");


    }

@Test
public void test_149_31() throws Exception {
    ClassUtils.getShortClassName("[Ljava.lang.String;");


    }

@Test
public void test_149_41() throws Exception {
    ClassUtils.getShortClassName("[[[Ljava.lang.String;");


    }

@Test
public void test_149_51() throws Exception {
    ClassUtils.getShortClassName("[I");


    }

@Test
public void test_149_61() throws Exception {
    ClassUtils.getShortClassName("[[[D");


    }

@Test
public void test_149_71() throws Exception {
    ClassUtils.getShortClassName("java.util.Map$Entry");


    }

@Test
public void test_149_81() throws Exception {
    ClassUtils.getShortClassName("[Ljava.util.Map$Entry;");


    }

@Test
public void test_149_91() throws Exception {
    ClassUtils.getShortClassName("int");


    }

@Test
public void test_149_101() throws Exception {
    ClassUtils.getShortClassName("I");


    }

}
package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import org.apache.commons.lang3.math.Fraction;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Fraction_LLMTest extends Fraction_LLMTest_scaffolding {
    
@Test
public void test_170_21() throws Exception {
    Fraction.getReducedFraction(1, 5);
    Fraction.getReducedFraction(5, 1);
    Fraction.getReducedFraction(-1, 5);
    Fraction.getReducedFraction(5, -1);


    }

@Test
public void test_170_31() throws Exception {
    Fraction.getReducedFraction(2, 4);
    Fraction.getReducedFraction(4, 2);
    Fraction.getReducedFraction(-2, 4);
    Fraction.getReducedFraction(4, -2);


    }

@Test
public void test_170_41() throws Exception {
    Fraction.getReducedFraction(123456, 7890);
    Fraction.getReducedFraction(7890, 123456);
    Fraction.getReducedFraction(-123456, 7890);
    Fraction.getReducedFraction(7890, -123456);


    }

@Test
public void test_170_51() throws Exception {
    Fraction.getReducedFraction(42, 42);
    Fraction.getReducedFraction(-42, -42);
    Fraction.getReducedFraction(42, -42);


    }

}
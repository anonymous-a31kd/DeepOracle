package org.apache.commons.lang.text;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Reader;
import org.apache.commons.lang.text.StrBuilder;
import java.util.Collection;
import java.util.Iterator;
import org.apache.commons.lang.ArrayUtils;
import java.util.List;
import org.apache.commons.lang.SystemUtils;
import java.io.Writer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StrBuilder_LLMTest extends StrBuilder_LLMTest_scaffolding {
    
@Test
public void test_198_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_198_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_198_21() throws Exception {
    StrBuilder sb = new StrBuilder(10);
    sb.append("abc");
    sb.buffer[5] = 'x';



    }

@Test
public void test_198_31() throws Exception {
    StrBuilder sb = new StrBuilder();



    }

@Test
public void test_198_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_198_51() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_199_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    sb.setLength(2);



    }

@Test
public void test_199_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    sb.setLength(2);



    }

@Test
public void test_199_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_199_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_199_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_199_51() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");



    }

@Test
public void test_199_61() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    sb.setLength(3);



    }

}
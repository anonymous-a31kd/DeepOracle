package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_173_01() throws Exception {
	try {
    NumberUtils.createNumber("123.45e6789");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_173_11() throws Exception {
	try {
    NumberUtils.createNumber("123e4567");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_173_31() throws Exception {
	try {
    NumberUtils.createNumber("123.45e67");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_173_41() throws Exception {
	try {
    NumberUtils.createNumber("123e45");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_173_51() throws Exception {
	try {
    NumberUtils.createNumber("123.45");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_173_61() throws Exception {
	try {
    NumberUtils.createNumber("123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
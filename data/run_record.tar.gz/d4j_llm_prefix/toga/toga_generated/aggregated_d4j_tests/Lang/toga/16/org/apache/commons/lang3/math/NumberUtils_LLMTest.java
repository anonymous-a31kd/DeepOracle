package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import java.math.BigDecimal;
import org.apache.commons.lang3.StringUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_141_01() throws Exception {
	try {
    NumberUtils.createNumber("0x1A");
    NumberUtils.createNumber("-0x1A");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_141_11() throws Exception {
	try {
    NumberUtils.createNumber("0X1A");
    NumberUtils.createNumber("-0X1A");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_141_21() throws Exception {
	try {
    NumberUtils.createNumber("0x1A");
    NumberUtils.createNumber("0X1A");
    NumberUtils.createNumber("-0x1A");
    NumberUtils.createNumber("-0X1A");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
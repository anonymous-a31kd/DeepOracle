package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class RandomStringUtils_LLMTest extends RandomStringUtils_LLMTest_scaffolding {
    
@Test
public void test_160_41() throws Exception {
	try {
    RandomStringUtils.random(5, 0, 3, true, true, new char[]{'a', 'b', 'c'}, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_160_51() throws Exception {
    RandomStringUtils.random(5, 32, 127, true, true, null, new Random());


    }

}
package com.fasterxml.jackson.core.json;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.json.JsonWriteContext;
import com.fasterxml.jackson.core.*;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonWriteContext_LLMTest extends JsonWriteContext_LLMTest_scaffolding {
    
@Test
public void test_83_01() throws Exception {
    JsonWriteContext context = JsonWriteContext.createRootContext().createChildObjectContext();

    int result = context.writeValue();
      assertEquals(0, result);
}

@Test
public void test_83_11() throws Exception {
    JsonWriteContext context = JsonWriteContext.createRootContext().createChildObjectContext();
    context.writeFieldName("field");
    int result = context.writeValue();
      assertEquals(1, result);
}

@Test
public void test_83_21() throws Exception {
    JsonWriteContext context = JsonWriteContext.createRootContext().createChildArrayContext();
    int result = context.writeValue();

    

    }

@Test
public void test_83_31() throws Exception {
    JsonWriteContext context = JsonWriteContext.createRootContext();
    int result = context.writeValue();

    

    }

}
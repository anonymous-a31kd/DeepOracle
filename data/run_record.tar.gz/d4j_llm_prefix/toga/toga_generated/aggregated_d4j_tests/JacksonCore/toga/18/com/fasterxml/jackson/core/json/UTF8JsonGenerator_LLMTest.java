package com.fasterxml.jackson.core.json;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.JsonFactory;
import java.math.BigDecimal;
import java.io.*;
import java.io.ByteArrayOutputStream;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.JsonGenerator.Feature;
import com.fasterxml.jackson.core.io.*;
import com.fasterxml.jackson.core.JsonGenerator;
import java.math.BigInteger;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UTF8JsonGenerator_LLMTest extends UTF8JsonGenerator_LLMTest_scaffolding {
    
@Test
public void test_71_01()  throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber((BigDecimal) null);
    generator.close();


    }

@Test
public void test_71_21()  throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.enable(Feature.WRITE_BIGDECIMAL_AS_PLAIN);
    generator.writeNumber(new BigDecimal("789.012"));
    generator.close();


    }

@Test
public void test_71_31()  throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber(new BigDecimal("345.678"));
    generator.close();


    }

@Test
public void test_71_41()  throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber(new BigDecimal("1.23456E+10"));
    generator.close();


    }

@Test
public void test_71_51()  throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber(new BigDecimal("12345678901234567890.12345678901234567890"));
    generator.close();


    }

}
package com.fasterxml.jackson.core.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.util.TextBuffer;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.ArrayList;
import com.fasterxml.jackson.core.io.NumberInput;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TextBuffer_LLMTest extends TextBuffer_LLMTest_scaffolding {
    
@Test
public void test_84_01() throws Exception {
    TextBuffer buffer = new TextBuffer(null);
    buffer.resetWithEmpty();

    buffer.getTextBuffer();


    }

@Test
public void test_84_21() throws Exception {
    TextBuffer buffer = new TextBuffer(null);
    buffer.resetWithString("test");
    buffer.getTextBuffer();


    }

@Test
public void test_84_31() throws Exception {
    TextBuffer buffer = new TextBuffer(null);
    char[] arr = new char[]{'t', 'e', 's', 't'};
    buffer.resetWithCopy(arr, 0, arr.length);
    buffer.getTextBuffer();


    }

@Test
public void test_84_41() throws Exception {
    char[] arr = new char[]{'t', 'e', 's', 't'};
    TextBuffer buffer = new TextBuffer(null);
    buffer.resetWithShared(arr, 0, arr.length);
    buffer.getTextBuffer();


    }

}
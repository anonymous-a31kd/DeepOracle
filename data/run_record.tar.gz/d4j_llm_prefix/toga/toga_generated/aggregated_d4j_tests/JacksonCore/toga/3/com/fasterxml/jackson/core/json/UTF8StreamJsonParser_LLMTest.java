package com.fasterxml.jackson.core.json;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.sym.*;
import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.base.ParserBase;
import com.fasterxml.jackson.core.sym.BytesToNameCanonicalizer;
import static com.fasterxml.jackson.core.JsonTokenId.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.util.*;
import java.io.*;
import java.util.Arrays;
import com.fasterxml.jackson.core.io.IOContext;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UTF8StreamJsonParser_LLMTest extends UTF8StreamJsonParser_LLMTest_scaffolding {
    
@Test
public void test_16_01()  throws Exception {
    IOContext ctxt = new IOContext(new JsonFactory()._getBufferRecycler(), null, false);
    InputStream in = new ByteArrayInputStream(new byte[0]);
    ObjectCodec codec = null;
    BytesToNameCanonicalizer sym = BytesToNameCanonicalizer.createRoot();
    byte[] inputBuffer = new byte[10];
    int start = 2;
    boolean bufferRecyclable = true;

    UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, 0, in, codec, sym,
    inputBuffer, start, inputBuffer.length, bufferRecyclable);



    }

@Test
public void test_16_21()  throws Exception {
    IOContext ctxt = new IOContext(new JsonFactory()._getBufferRecycler(), null, false);
    InputStream in = new ByteArrayInputStream(new byte[0]);
    ObjectCodec codec = null;
    BytesToNameCanonicalizer sym = BytesToNameCanonicalizer.createRoot();
    byte[] inputBuffer = new byte[10];
    int start = 0;
    boolean bufferRecyclable = true;

    UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, 0, in, codec, sym,
    inputBuffer, start, inputBuffer.length, bufferRecyclable);



    }

}
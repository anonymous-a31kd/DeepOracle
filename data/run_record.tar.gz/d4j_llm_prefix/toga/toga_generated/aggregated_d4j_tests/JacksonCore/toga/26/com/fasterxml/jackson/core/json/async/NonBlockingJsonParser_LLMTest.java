package com.fasterxml.jackson.core.json.async;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.io.CharTypes;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.async.NonBlockingInputFeeder;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.util.VersionUtil;
import com.fasterxml.jackson.core.async.ByteArrayFeeder;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import java.io.OutputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NonBlockingJsonParser_LLMTest extends NonBlockingJsonParser_LLMTest_scaffolding {
    
@Test
public void test_81_01()  throws Exception {
    NonBlockingJsonParser parser = new NonBlockingJsonParser(
    new IOContext(new JsonFactory()._getBufferRecycler(), null, false),
    JsonFactory.Feature.collectDefaults(),
    ByteQuadsCanonicalizer.createRoot()
    );
    byte[] input = new byte[]{'{', '}'};
    parser.feedInput(input, 0, input.length);



    }

@Test
public void test_81_11()  throws Exception {
    NonBlockingJsonParser parser = new NonBlockingJsonParser(
    new IOContext(new JsonFactory()._getBufferRecycler(), null, false),
    JsonFactory.Feature.collectDefaults(),
    ByteQuadsCanonicalizer.createRoot()
    );
    byte[] input = new byte[0];
    parser.feedInput(input, 0, 0);



    }

@Test
public void test_81_21()  throws Exception {
    NonBlockingJsonParser parser = new NonBlockingJsonParser(
    new IOContext(new JsonFactory()._getBufferRecycler(), null, false),
    JsonFactory.Feature.collectDefaults(),
    ByteQuadsCanonicalizer.createRoot()
    );
    byte[] input = new byte[]{' ', '{', '}'};
    parser.feedInput(input, 1, input.length);



    }

}
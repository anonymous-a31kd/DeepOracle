package com.fasterxml.jackson.core.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.io.SerializedString;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import java.io.*;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DefaultPrettyPrinter_LLMTest extends DefaultPrettyPrinter_LLMTest_scaffolding {
    
@Test
public void test_76_01() throws Exception {
    DefaultPrettyPrinter base = new DefaultPrettyPrinter();
    DefaultPrettyPrinter instance = base.createInstance();



    }

@Test
public void test_76_11() throws Exception {
    DefaultPrettyPrinter subclass = new DefaultPrettyPrinter() {

    };
    subclass.createInstance();


    }

@Test
public void test_76_21() throws Exception {
    DefaultPrettyPrinter subclass = new DefaultPrettyPrinter() {
        @Override
        public DefaultPrettyPrinter createInstance() {
            return new DefaultPrettyPrinter(this);
        }
    };
    DefaultPrettyPrinter instance = subclass.createInstance();



    }

@Test
public void test_76_31() throws Exception {
    DefaultPrettyPrinter base = new DefaultPrettyPrinter(new SerializedString("|"));
    DefaultPrettyPrinter instance = base.createInstance();



    }

}
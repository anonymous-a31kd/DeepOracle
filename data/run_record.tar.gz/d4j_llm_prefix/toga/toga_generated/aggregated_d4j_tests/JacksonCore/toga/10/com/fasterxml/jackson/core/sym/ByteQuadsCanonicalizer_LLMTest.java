package com.fasterxml.jackson.core.sym;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import com.fasterxml.jackson.core.util.InternCache;
import com.fasterxml.jackson.core.JsonFactory;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Arrays;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ByteQuadsCanonicalizer_LLMTest extends ByteQuadsCanonicalizer_LLMTest_scaffolding {
    
@Test
public void test_57_01() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(0);


    }

@Test
public void test_57_11() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(123);


    }

@Test
public void test_57_21() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(Integer.MAX_VALUE);


    }

@Test
public void test_57_31() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(-123456);


    }

@Test
public void test_57_41() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(1024);


    }

@Test
public void test_57_51() throws Exception {
    ByteQuadsCanonicalizer canonicalizer1 = ByteQuadsCanonicalizer.createRoot(123);
    int result1 = canonicalizer1.calcHash(42);

    ByteQuadsCanonicalizer canonicalizer2 = ByteQuadsCanonicalizer.createRoot(456);
    int result2 = canonicalizer2.calcHash(42);


    }

@Test
public void test_57_61() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(~0);


    }

@Test
public void test_57_71() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(0x55555555);


    }

@Test
public void test_57_81() throws Exception {
    ByteQuadsCanonicalizer canonicalizer = ByteQuadsCanonicalizer.createRoot();
    int result = canonicalizer.calcHash(0xAAAAAAAA);


    }

}
package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.util.Map.Entry;
import org.apache.commons.compress.utils.IOUtils;
import java.util.HashMap;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.Map;
import java.io.InputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.utils.CharsetNames;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveInputStream_LLMTest extends TarArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_29_01()  throws Exception {
    String input = "30 comment=This is a test comment\n";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    Map<String, String> headers = tarIn.parsePaxHeaders(is);


    }

@Test
public void test_29_11()  throws Exception {
    String input = "30\ncomment=This is a test comment\n";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    Map<String, String> headers = tarIn.parsePaxHeaders(is);


    }

@Test
public void test_29_21()  throws Exception {
    String input = "30\n\ncomment=This is a test comment\n";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    Map<String, String> headers = tarIn.parsePaxHeaders(is);


    }

@Test
public void test_29_31()  throws Exception {
    String input = "30 comment=First comment\n25 key=value\n";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    Map<String, String> headers = tarIn.parsePaxHeaders(is);


    }

@Test
public void test_29_51()  throws Exception {
    String input = "5\n";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    Map<String, String> headers = tarIn.parsePaxHeaders(is);


    }

}
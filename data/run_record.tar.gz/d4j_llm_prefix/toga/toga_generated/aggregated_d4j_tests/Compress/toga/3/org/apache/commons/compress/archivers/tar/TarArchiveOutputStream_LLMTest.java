package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.io.File;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveOutputStream_LLMTest extends TarArchiveOutputStream_LLMTest_scaffolding {
    
@Test
public void test_2_01()  throws Exception {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);

    ArchiveEntry entry = new TarArchiveEntry("test");
    tos.putArchiveEntry(entry);
    tos.closeArchiveEntry();

    tos.finish();


    }

@Test
public void test_2_11()  throws Exception {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);

    ArchiveEntry entry = new TarArchiveEntry("test");
    tos.putArchiveEntry(entry);

    tos.finish();


    }

@Test
public void test_2_21()  throws Exception {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);

    tos.finish();


    }

@Test
public void test_2_31()  throws Exception {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);

    ArchiveEntry entry1 = new TarArchiveEntry("test1");
    ArchiveEntry entry2 = new TarArchiveEntry("test2");
    tos.putArchiveEntry(entry1);
    tos.putArchiveEntry(entry2);

    tos.finish();


    }

}
package org.apache.commons.compress.utils;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.nio.ByteOrder;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class BitInputStream_LLMTest extends BitInputStream_LLMTest_scaffolding {
    
@Test
public void test_32_01()  throws Exception {
	try {
    byte[] data = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
    BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data), ByteOrder.LITTLE_ENDIAN);
    bis.readBits(56);
    bis.readBits(8);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_11()  throws Exception {
	try {
    byte[] data = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
    BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data), ByteOrder.BIG_ENDIAN);
    bis.readBits(56);
    bis.readBits(8);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_21()  throws Exception {
	try {
    byte[] data = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
    BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data), ByteOrder.LITTLE_ENDIAN);
    bis.readBits(57);
    bis.readBits(7);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_31()  throws Exception {
	try {
    byte[] data = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
    BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data), ByteOrder.BIG_ENDIAN);
    bis.readBits(57);
    bis.readBits(7);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_41()  throws Exception {
	try {
    byte[] data = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
    BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data), ByteOrder.LITTLE_ENDIAN);
    bis.readBits(56);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_32_51()  throws Exception {
	try {
    byte[] data = new byte[]{(byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF, (byte)0xFF};
    BitInputStream bis = new BitInputStream(new ByteArrayInputStream(data), ByteOrder.LITTLE_ENDIAN);
    bis.readBits(56);
    bis.readBits(8);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
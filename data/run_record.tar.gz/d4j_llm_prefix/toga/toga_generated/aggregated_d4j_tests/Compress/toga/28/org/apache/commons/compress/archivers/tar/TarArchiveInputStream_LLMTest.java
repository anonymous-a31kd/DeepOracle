package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.utils.IOUtils;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.HashMap;
import org.apache.commons.compress.utils.CharsetNames;
import org.apache.commons.compress.utils.ArchiveUtils;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import java.io.InputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveInputStream_LLMTest extends TarArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_22_01()  throws Exception {
    byte[] data = new byte[100];
    InputStream input = new ByteArrayInputStream(data);
    TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
    tarInput.setCurrentEntry(new TarArchiveEntry("test"));
    byte[] buf = new byte[10];
    int read = tarInput.read(buf, 0, 10);
      assertEquals(0, read);
}

@Test
public void test_22_11()  throws Exception {
    byte[] data = new byte[0];
    InputStream input = new ByteArrayInputStream(data);
    TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
    tarInput.setCurrentEntry(new TarArchiveEntry("test"));
    byte[] buf = new byte[10];
    tarInput.read(buf, 0, 10);


    }

@Test
public void test_22_21()  throws Exception {
    byte[] data = new byte[0];
    InputStream input = new ByteArrayInputStream(data);
    TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
    tarInput.setCurrentEntry(new TarArchiveEntry("test"));
    byte[] buf = new byte[10];
    int read = tarInput.read(buf, 0, 0);
      assertEquals(0, read);
}

@Test
public void test_22_31()  throws Exception {
    byte[] data = new byte[5];
    InputStream input = new ByteArrayInputStream(data);
    TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
    tarInput.setCurrentEntry(new TarArchiveEntry("test"));
    byte[] buf = new byte[10];
    int read = tarInput.read(buf, 0, 10);
      assertEquals(1, read);
}

@Test
public void test_22_41()  throws Exception {
    byte[] data = new byte[100];
    InputStream input = new ByteArrayInputStream(data);
    TarArchiveInputStream tarInput = new TarArchiveInputStream(input);
    byte[] buf = new byte[10];
    tarInput.read(buf, 0, 10);


    }

}
package org.apache.commons.compress.utils;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import org.apache.commons.compress.utils.ArchiveUtils;
import java.util.Arrays;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArchiveUtils_LLMTest extends ArchiveUtils_LLMTest_scaffolding {
    
@Test
public void test_31_01() throws Exception {
    String input = "test";
    ArchiveUtils.sanitize(input);


    }

@Test
public void test_31_31() throws Exception {
    String input = "test\u0000\u001Ftest";
    ArchiveUtils.sanitize(input);


    }

@Test
public void test_31_41() throws Exception {
    String input = "test\uFFF0test";
    ArchiveUtils.sanitize(input);


    }

@Test
public void test_31_51() throws Exception {
    String input = "";
    ArchiveUtils.sanitize(input);


    }

}
package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.nio.channels.SeekableByteChannel;
import static org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MIN_VERSION;
import java.nio.file.Files;
import static org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MAGIC_SHORT;
import java.util.EnumSet;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import static org.apache.commons.compress.archivers.zip.ZipConstants.DWORD;
import java.util.zip.Deflater;
import static org.apache.commons.compress.archivers.zip.ZipShort.putShort;
import static org.apache.commons.compress.archivers.zip.ZipConstants.WORD;
import java.io.FileOutputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import java.util.List;
import java.io.InputStream;
import org.apache.commons.compress.utils.IOUtils;
import java.io.File;
import static org.apache.commons.compress.archivers.zip.ZipConstants.DEFLATE_MIN_VERSION;
import static org.apache.commons.compress.archivers.zip.ZipLong.putLong;
import java.util.Map;
import java.util.LinkedList;
import java.util.Calendar;
import java.util.HashMap;
import static org.apache.commons.compress.archivers.zip.ZipConstants.SHORT;
import static org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MAGIC;
import static org.apache.commons.compress.archivers.zip.ZipConstants.DATA_DESCRIPTOR_MIN_VERSION;
import static org.apache.commons.compress.archivers.zip.ZipConstants.INITIAL_VERSION;
import java.util.zip.ZipException;
import java.nio.file.StandardOpenOption;
import java.io.ByteArrayOutputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveOutputStream_LLMTest extends ZipArchiveOutputStream_LLMTest_scaffolding {
    
@Test
public void test_51_01()  throws Exception {
    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    entry.setMethod(ZipArchiveOutputStream.DEFLATED);
    zos.writeDataDescriptor(entry);


    }

@Test
public void test_51_11()  throws Exception {
    ZipArchiveOutputStream zos = new ZipArchiveOutputStream(new ByteArrayOutputStream());
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    entry.setMethod(ZipArchiveOutputStream.STORED);
    zos.writeDataDescriptor(entry);


    }

}
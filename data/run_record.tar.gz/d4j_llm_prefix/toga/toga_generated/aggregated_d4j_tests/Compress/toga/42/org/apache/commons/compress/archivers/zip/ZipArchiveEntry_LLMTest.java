package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import java.util.Arrays;
import org.apache.commons.compress.archivers.zip.UnixStat;
import java.util.Date;
import java.util.zip.ZipException;
import java.util.ArrayList;
import java.io.File;
import java.util.List;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveEntry_LLMTest extends ZipArchiveEntry_LLMTest_scaffolding {
    
@Test
public void test_33_01() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    entry.setUnixMode(UnixStat.FILE_FLAG | 0644);
    entry.isUnixSymlink();


    }

@Test
public void test_33_21() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    entry.setUnixMode(UnixStat.DIR_FLAG);
    entry.isUnixSymlink();


    }

@Test
public void test_33_31() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    entry.setUnixMode(0);
    entry.isUnixSymlink();


    }

}
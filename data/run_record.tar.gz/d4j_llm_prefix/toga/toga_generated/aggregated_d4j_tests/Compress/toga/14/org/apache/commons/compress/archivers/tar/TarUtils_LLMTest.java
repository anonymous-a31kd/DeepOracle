package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.tar.TarUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_8_01() throws Exception {
    byte[] buffer = {0, 0, 0, 0};
    long result = TarUtils.parseOctal(buffer, 0, 4);



    }

@Test
public void test_8_21() throws Exception {
    byte[] buffer = {'1', '2', '3', ' '};
    long result = TarUtils.parseOctal(buffer, 0, 4);



    }

@Test
public void test_8_31() throws Exception {
    byte[] buffer = {0, '1', '2', '3'};
    long result = TarUtils.parseOctal(buffer, 0, 4);



    }

}
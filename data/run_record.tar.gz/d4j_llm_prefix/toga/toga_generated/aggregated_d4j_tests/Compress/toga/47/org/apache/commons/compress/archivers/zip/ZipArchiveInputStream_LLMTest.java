package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import java.util.zip.CRC32;
import org.apache.commons.compress.utils.IOUtils;
import static org.apache.commons.compress.archivers.zip.ZipConstants.DWORD;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import static org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MAGIC;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.compressors.deflate64.Deflate64CompressorInputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.Inflater;
import java.io.InputStream;
import static org.apache.commons.compress.archivers.zip.ZipConstants.WORD;
import java.io.EOFException;
import java.util.zip.DataFormatException;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import java.io.ByteArrayInputStream;
import static org.apache.commons.compress.archivers.zip.ZipConstants.SHORT;
import java.util.zip.ZipException;
import java.io.PushbackInputStream;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.UnsupportedZipFeatureException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveInputStream_LLMTest extends ZipArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_35_01() throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
    ZipArchiveEntry entry = new ZipArchiveEntry("test");

    entry.setMethod(ZipEntry.STORED);
    entry.setSize(100);
    entry.setCompressedSize(100);



    }

@Test
public void test_35_11() throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
    ZipArchiveEntry entry = new ZipArchiveEntry("test");

    entry.setMethod(ZipEntry.STORED);
    entry.setSize(100);
    entry.setCompressedSize(-1);



    }

@Test
public void test_35_31() throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new ByteArrayInputStream(new byte[0]));
    ZipArchiveEntry entry = new ZipArchiveEntry("test");

    entry.setMethod(ZipEntry.DEFLATED);
    entry.setSize(100);
    entry.setCompressedSize(100);



    }

}
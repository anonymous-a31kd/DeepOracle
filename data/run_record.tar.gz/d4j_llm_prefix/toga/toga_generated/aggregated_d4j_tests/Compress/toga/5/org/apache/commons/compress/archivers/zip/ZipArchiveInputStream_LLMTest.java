package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import java.io.EOFException;
import java.util.zip.Inflater;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.io.InputStream;
import java.util.zip.CRC32;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import java.util.zip.DataFormatException;
import java.io.PushbackInputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveInputStream_LLMTest extends ZipArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_3_01()  throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
    java.lang.reflect.Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
    infField.setAccessible(true);
    java.util.zip.Inflater inf = (java.util.zip.Inflater) infField.get(zais);
    inf.end();
    byte[] buffer = new byte[10];



    }

@Test
public void test_3_11()  throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
    java.lang.reflect.Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
    infField.setAccessible(true);
    java.util.zip.Inflater inf = (java.util.zip.Inflater) infField.get(zais);
    java.lang.reflect.Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
    lengthField.setAccessible(true);
    lengthField.set(zais, -1);
    byte[] buffer = new byte[10];
    zais.read(buffer, 0, 10);


    }

@Test
public void test_3_21()  throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
    java.lang.reflect.Field infField = ZipArchiveInputStream.class.getDeclaredField("inf");
    infField.setAccessible(true);
    java.util.zip.Inflater inf = (java.util.zip.Inflater) infField.get(zais);
    java.lang.reflect.Field lengthField = ZipArchiveInputStream.class.getDeclaredField("lengthOfLastRead");
    lengthField.setAccessible(true);
    lengthField.set(zais, 10);
    byte[] buffer = new byte[10];
    inf.setInput(new byte[10]);
    zais.read(buffer, 0, 10);


    }

@Test
public void test_3_31()  throws Exception {
    ZipArchiveInputStream zais = new ZipArchiveInputStream(new java.io.ByteArrayInputStream(new byte[0]));
    java.lang.reflect.Field currentField = ZipArchiveInputStream.class.getDeclaredField("current");
    currentField.setAccessible(true);
    org.apache.commons.compress.archivers.zip.ZipArchiveEntry entry = new org.apache.commons.compress.archivers.zip.ZipArchiveEntry("test");
    entry.setMethod(ZipArchiveOutputStream.STORED);
    entry.setSize(10);
    currentField.set(zais, entry);
    byte[] buffer = new byte[10];
    zais.read(buffer, 0, 10);


    }

}
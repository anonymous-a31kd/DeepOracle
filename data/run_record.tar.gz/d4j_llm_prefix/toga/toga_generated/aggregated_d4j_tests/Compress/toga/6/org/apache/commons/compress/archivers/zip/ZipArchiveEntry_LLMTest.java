package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Date;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import java.util.LinkedHashMap;
import java.util.zip.ZipException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.io.File;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveEntry_LLMTest extends ZipArchiveEntry_LLMTest_scaffolding {
    
@Test
public void test_32_01() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    entry1.setName(null);
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry2.setName(null);
    

    }

@Test
public void test_32_11() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    entry1.setName(null);
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    

    }

@Test
public void test_32_21() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");
    

    }

@Test
public void test_32_31() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    

    }

@Test
public void test_32_41() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    

    }

@Test
public void test_32_51() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    

    }

@Test
public void test_32_61() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    

    }

}
package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;
import java.io.InputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.utils.ArchiveUtils;
import java.util.Map.Entry;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import java.util.HashMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveInputStream_LLMTest extends TarArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_6_01()  throws Exception {
    byte[] invalidHeader = new byte[512];
    InputStream is = new ByteArrayInputStream(invalidHeader);
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    tarIn.getNextTarEntry();


    }

@Test
public void test_6_11()  throws Exception {
    byte[] validHeader = new byte[512];

    System.arraycopy(TarArchiveEntry.GNU_LONGLINK.getBytes(), 0, validHeader, 0,
    TarArchiveEntry.GNU_LONGLINK.getBytes().length);

    InputStream is = new ByteArrayInputStream(validHeader);
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    TarArchiveEntry entry = tarIn.getNextTarEntry();



    }

@Test
public void test_6_21()  throws Exception {
    byte[] shortHeader = new byte[100];
    InputStream is = new ByteArrayInputStream(shortHeader);
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    tarIn.getNextTarEntry();


    }

@Test
public void test_6_31()  throws Exception {
    InputStream is = new ByteArrayInputStream(new byte[0]);
    TarArchiveInputStream tarIn = new TarArchiveInputStream(is);
    TarArchiveEntry entry = tarIn.getNextTarEntry();



    }

}
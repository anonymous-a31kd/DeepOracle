package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_4_01() throws Exception {
    byte[] buffer = {65, 66, 67, 68, 69};
    String result = TarUtils.parseName(buffer, 0, buffer.length);



    }

@Test
public void test_4_11() throws Exception {
    byte[] buffer = {65, 66, 0, 68, 69};
    String result = TarUtils.parseName(buffer, 0, buffer.length);



    }

@Test
public void test_4_21() throws Exception {
    byte[] buffer = {(byte)0x80, (byte)0xFF, 65};
    String result = TarUtils.parseName(buffer, 0, buffer.length);



    }

@Test
public void test_4_31() throws Exception {
    byte[] buffer = {65, 66, 67, 68, 69};
    String result = TarUtils.parseName(buffer, 1, 3);



    }

@Test
public void test_4_41() throws Exception {
    byte[] buffer = {65, 66, 67};
    String result = TarUtils.parseName(buffer, 0, 0);



    }

@Test
public void test_4_51() throws Exception {
    byte[] buffer = {0, 0, 0, 0};
    String result = TarUtils.parseName(buffer, 0, buffer.length);



    }

@Test
public void test_4_61() throws Exception {
    byte[] buffer = {65};
    String result = TarUtils.parseName(buffer, 0, 1);



    }

}
package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.apache.commons.compress.archivers.zip.ZipConstants.WORD;
import java.util.zip.ZipException;
import static org.apache.commons.compress.archivers.zip.ZipConstants.DWORD;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Zip64ExtendedInformationExtraField_LLMTest extends Zip64ExtendedInformationExtraField_LLMTest_scaffolding {
    
@Test
public void test_37_11()  throws Exception {
    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();

    field.parseFromCentralDirectoryData(new byte[8], 0, 8);
    field.reparseCentralDirectoryData(true, false, false, false);


    }

@Test
public void test_37_31()  throws Exception {
    Zip64ExtendedInformationExtraField field = new Zip64ExtendedInformationExtraField();

    field.parseFromCentralDirectoryData(new byte[16], 0, 16);
    field.reparseCentralDirectoryData(true, true, false, false);


    }

}
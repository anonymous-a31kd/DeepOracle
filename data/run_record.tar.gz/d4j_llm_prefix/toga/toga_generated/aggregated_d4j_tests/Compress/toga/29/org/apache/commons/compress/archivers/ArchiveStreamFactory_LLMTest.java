package org.apache.commons.compress.archivers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.ArchiveException;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import static org.junit.Assert.assertTrue;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.ArjArchiveInputStream;
import java.io.InputStream;
import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import java.io.OutputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArchiveStreamFactory_LLMTest extends ArchiveStreamFactory_LLMTest_scaffolding {
    
@Test
public void test_42_01()  throws Exception {
	try {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_42_11()  throws Exception {
	try {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.setEntryEncoding("UTF-8");
    factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_42_21()  throws Exception {
	try {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.setEntryEncoding("");
    factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_42_31()  throws Exception {
	try {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
    factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
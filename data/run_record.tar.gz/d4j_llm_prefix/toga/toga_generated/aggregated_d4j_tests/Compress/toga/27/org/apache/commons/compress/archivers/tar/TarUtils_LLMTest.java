package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUMLEN;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import java.nio.ByteBuffer;
import java.math.BigInteger;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUM_OFFSET;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_40_01() throws Exception {
	try {
    byte[] buffer = {' ', ' ', ' ', ' '};
    parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_40_11() throws Exception {
	try {
    byte[] buffer = {0, 0, 0, 0};
    parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_40_21() throws Exception {
	try {
    byte[] buffer = {' ', 0, ' ', 0};
    parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_40_31() throws Exception {
	try {
    byte[] buffer = {' ', ' ', '1', '2', 0, 0};
    parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_40_61() throws Exception {
	try {
    byte[] buffer = {' ', 0};
    parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
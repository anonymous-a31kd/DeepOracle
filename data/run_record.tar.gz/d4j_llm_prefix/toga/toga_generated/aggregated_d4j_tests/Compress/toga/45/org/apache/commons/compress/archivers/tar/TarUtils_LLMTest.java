package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import java.util.Arrays;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUMLEN;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUM_OFFSET;
import org.apache.commons.compress.archivers.tar.TarUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_34_01() throws Exception {
    byte[] buf = new byte[8];
    int offset = 0;
    int length = 8;
    long value = 12345678L;
    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
      assertEquals(1, result);
}

@Test
public void test_34_21() throws Exception {
    byte[] buf = new byte[8];
    int offset = 0;
    int length = 8;
    long value = -12345678L;
    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);



    }

@Test
public void test_34_31() throws Exception {
    byte[] buf = new byte[10];
    int offset = 0;
    int length = 10;
    long value = -1234567890L;
    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);
      assertEquals(1, result);
}

@Test
public void test_34_41() throws Exception {
    byte[] buf = new byte[8];
    int offset = 0;
    int length = 8;
    long value = TarConstants.MAXSIZE;
    int result = TarUtils.formatLongOctalOrBinaryBytes(value, buf, offset, length);



    }

}
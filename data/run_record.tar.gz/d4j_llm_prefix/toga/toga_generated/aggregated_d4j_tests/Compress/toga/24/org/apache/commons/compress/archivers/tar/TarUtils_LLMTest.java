package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import java.nio.ByteBuffer;
import java.math.BigInteger;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUMLEN;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUM_OFFSET;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_39_01() throws Exception {
    byte[] buffer = {'1', '2', '3', ' '};
    TarUtils.parseOctal(buffer, 0, buffer.length);


    }

@Test
public void test_39_11() throws Exception {
    byte[] buffer = {'1', '2', '3', ' ', ' ', ' '};
    TarUtils.parseOctal(buffer, 0, buffer.length);


    }

@Test
public void test_39_21() throws Exception {
	try {
    byte[] buffer = {'1', '2', '3', 0};
    TarUtils.parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_39_31() throws Exception {
	try {
    byte[] buffer = {'1', '2', '3', 0, 0, 0};
    TarUtils.parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_39_41() throws Exception {
    byte[] buffer = {'1', '2', '3', ' ', 0, ' ', 0};
    TarUtils.parseOctal(buffer, 0, buffer.length);


    }

@Test
public void test_39_51() throws Exception {
	try {
    byte[] buffer = {' ', ' ', ' ', ' '};
    TarUtils.parseOctal(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_39_61() throws Exception {
    byte[] buffer = {0, 0, 0, 0};
    TarUtils.parseOctal(buffer, 0, buffer.length);


    }

@Test
public void test_39_81() throws Exception {
    byte[] buffer = {'1', '2', '3', '4'};
    TarUtils.parseOctal(buffer, 0, buffer.length);


    }

@Test
public void test_39_91() throws Exception {
    byte[] buffer = {' ', ' ', '1', '2', '3', 0, 0};
    TarUtils.parseOctal(buffer, 0, buffer.length);


    }

}
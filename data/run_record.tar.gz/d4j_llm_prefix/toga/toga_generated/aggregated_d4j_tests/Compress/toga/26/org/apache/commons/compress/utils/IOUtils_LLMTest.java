package org.apache.commons.compress.utils;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class IOUtils_LLMTest extends IOUtils_LLMTest_scaffolding {
    
@Test
public void test_21_01()  throws Exception {
    byte[] data = new byte[1024];
    InputStream input = new ByteArrayInputStream(data);
    long skipped = IOUtils.skip(input, 512);


    }

@Test
public void test_21_11()  throws Exception {
    byte[] data = new byte[1024];
    InputStream input = new ByteArrayInputStream(data);
    long skipped = IOUtils.skip(input, 1024);


    }

@Test
public void test_21_21()  throws Exception {
    byte[] data = new byte[512];
    InputStream input = new ByteArrayInputStream(data);
    long skipped = IOUtils.skip(input, 1024);


    }

@Test
public void test_21_31()  throws Exception {
    byte[] data = new byte[0];
    InputStream input = new ByteArrayInputStream(data);
    long skipped = IOUtils.skip(input, 100);


    }

@Test
public void test_21_41()  throws Exception {
    InputStream input = new InputStream() {
        @Override
        public int read() throws IOException {
            return -1;
        }

        @Override
        public long skip(long n) throws IOException {
            return 0;
        }
    };
    long skipped = IOUtils.skip(input, 100);


    }

@Test
public void test_21_51()  throws Exception {
    InputStream input = new InputStream() {
        private int position = 0;
        private byte[] data = new byte[100];

        @Override
        public int read() throws IOException {
            return position < data.length ? data[position++] : -1;
        }

        @Override
        public long skip(long n) throws IOException {
            long toSkip = Math.min(n, 10);
            position += toSkip;
            return toSkip;
        }
    };
    long skipped = IOUtils.skip(input, 50);


    }

}
package org.apache.commons.compress.archivers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArchiveStreamFactory_LLMTest extends ArchiveStreamFactory_LLMTest_scaffolding {
    
@Test
public void test_10_01()  throws Exception {
	try {

    byte[] validTarHeader = new byte[512];

    InputStream in = new ByteArrayInputStream(validTarHeader);
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.createArchiveInputStream(in);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_10_11()  throws Exception {
	try {

    byte[] invalidTarHeader = new byte[512];

    InputStream in = new ByteArrayInputStream(invalidTarHeader);
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.createArchiveInputStream(in);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_10_31()  throws Exception {
	try {

    byte[] nonTarData = new byte[512];
    InputStream in = new ByteArrayInputStream(nonTarData);
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.createArchiveInputStream(in);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
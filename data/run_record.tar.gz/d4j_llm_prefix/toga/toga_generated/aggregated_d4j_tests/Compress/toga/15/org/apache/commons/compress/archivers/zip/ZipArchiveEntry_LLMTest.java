package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Date;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.io.File;
import java.util.zip.ZipException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveEntry_LLMTest extends ZipArchiveEntry_LLMTest_scaffolding {
    
@Test
public void test_9_01() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry1.setComment(null);
    entry2.setComment(null);



    }

@Test
public void test_9_11() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry1.setComment(null);
    entry2.setComment("comment");



    }

@Test
public void test_9_21() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry1.setComment("comment1");
    entry2.setComment("comment2");



    }

@Test
public void test_9_31() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry1.setComment("comment");
    entry2.setComment("comment");



    }

@Test
public void test_9_41() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry1.setComment("");
    entry2.setComment("");



    }

}
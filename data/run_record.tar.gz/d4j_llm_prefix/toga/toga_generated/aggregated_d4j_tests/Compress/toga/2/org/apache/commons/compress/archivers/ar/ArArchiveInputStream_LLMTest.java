package org.apache.commons.compress.archivers.ar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArArchiveInputStream_LLMTest extends ArArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_24_21()  throws Exception {
	try {
    byte[] data = new byte[0];
    ByteArrayInputStream in = new ByteArrayInputStream(data);
    ArArchiveInputStream arIn = new ArArchiveInputStream(in);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_24_31()  throws Exception {
    byte[] data = "!<arch>\n".getBytes();
    ByteArrayInputStream in = new ByteArrayInputStream(data);
    ArArchiveInputStream arIn = new ArArchiveInputStream(in);


    }

@Test
public void test_24_41()  throws Exception {
	try {
    byte[] data = "invalid\n".getBytes();
    ByteArrayInputStream in = new ByteArrayInputStream(data);
    ArArchiveInputStream arIn = new ArArchiveInputStream(in);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_25_01()  throws Exception {
    byte[] data = {0x41, 0x42, 0x43};
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    int result = arInput.read();


    }

@Test
public void test_25_11()  throws Exception {
    byte[] data = {};
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    int result = arInput.read();


    }

@Test
public void test_25_21()  throws Exception {
    byte[] data = {(byte)0xFF};
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    int result = arInput.read();


    }

@Test
public void test_25_31()  throws Exception {
    byte[] data = {0x01, 0x02, 0x03};
    byte[] buffer = new byte[2];
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    int result = arInput.read(buffer, 0, 2);


    }

@Test
public void test_25_41()  throws Exception {
    byte[] data = {0x01, 0x02, 0x03};
    byte[] buffer = new byte[3];
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    int result = arInput.read(buffer, 1, 2);


    }

@Test
public void test_25_51()  throws Exception {
    byte[] data = {};
    byte[] buffer = new byte[1];
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    int result = arInput.read(buffer, 0, 1);


    }

@Test
public void test_25_61()  throws Exception {
    byte[] data = {0x01};
    InputStream input = new ByteArrayInputStream(data);
    ArArchiveInputStream arInput = new ArArchiveInputStream(input);
    arInput.close();
    int result = arInput.read();


    }

@Test
public void test_26_01()  throws Exception {
    byte[] data = new byte[100];
    ArArchiveInputStream in = new ArArchiveInputStream(new ByteArrayInputStream(data));
    byte[] buffer = new byte[10];
    in.read(buffer, 0, 5);


    }

@Test
public void test_26_31() throws Exception {
    byte[] signature = {0x21, 0x3c, 0x61, 0x72, 0x63, 0x68, 0x3e, 0x0a};
    ArArchiveInputStream.matches(signature, 8);


    }

@Test
public void test_26_41() throws Exception {
    byte[] signature = {0x00, 0x3c, 0x61, 0x72, 0x63, 0x68, 0x3e, 0x0a};
    ArArchiveInputStream.matches(signature, 8);


    }

@Test
public void test_26_51() throws Exception {
    byte[] signature = {0x21, 0x3c, 0x61, 0x72};
    ArArchiveInputStream.matches(signature, 4);


    }

@Test
public void test_27_01()  throws Exception {
    byte[] data = "!<arch>\n".getBytes();
    ByteArrayInputStream in = new ByteArrayInputStream(data);
    ArArchiveInputStream arIn = new ArArchiveInputStream(in);
    arIn.close();



    }

@Test
public void test_27_11()  throws Exception {
    byte[] data = "!<arch>\n".getBytes();
    ByteArrayInputStream in = new ByteArrayInputStream(data);
    ArArchiveInputStream arIn = new ArArchiveInputStream(in);
    arIn.close();
    arIn.close();


    }

}
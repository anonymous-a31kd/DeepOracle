package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.utils.CountingOutputStream;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.io.File;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveOutputStream_LLMTest extends TarArchiveOutputStream_LLMTest_scaffolding {
    
@Test
public void test_34_41()  throws Exception {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
    byte[] data = new byte[0];
    tos.write(data, 0, data.length);
    tos.close();


    }

}
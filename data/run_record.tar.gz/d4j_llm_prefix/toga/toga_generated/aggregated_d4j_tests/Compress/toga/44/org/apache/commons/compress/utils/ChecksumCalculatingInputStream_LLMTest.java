package org.apache.commons.compress.utils;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Checksum;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ChecksumCalculatingInputStream_LLMTest extends ChecksumCalculatingInputStream_LLMTest_scaffolding {
    
@Test
public void test_52_01() throws Exception {
    InputStream mockStream = new InputStream() {
        @Override
        public int read() {
            return 0;
        }
    };
    new ChecksumCalculatingInputStream(null, mockStream);


    }

@Test
public void test_52_1() throws Exception {
    Checksum mockChecksum = new Checksum() {
        @Override
        public void update(int b) {}

        @Override
        public void update(byte[] b, int off, int len) {}

        @Override
        public long getValue() { return 0L; }

        @Override
        public void reset1() {}
    };
    new ChecksumCalculatingInputStream(mockChecksum, null);


    }

@Test
public void test_52_21() throws Exception {
    new ChecksumCalculatingInputStream(null, null);


    }

@Test
public void test_52_3() throws Exception {
    Checksum mockChecksum = new Checksum() {
        @Override
        public void update(int b) {}

        @Override
        public void update(byte[] b, int off, int len) {}

        @Override
        public long getValue() { return 0L; }

        @Override
        public void reset2() {}
    };
    InputStream mockStream = new InputStream() {
        @Override
        public int read() {
            return 0;
        }
    };
    new ChecksumCalculatingInputStream(mockChecksum, mockStream);


    }

}
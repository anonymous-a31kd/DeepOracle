package org.apache.commons.collections4;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Comparator;
import org.apache.commons.collections4.iterators.EmptyListIterator;
import org.apache.commons.collections4.iterators.BoundedIterator;
import org.apache.commons.collections4.iterators.EmptyMapIterator;
import java.util.ListIterator;
import org.apache.commons.collections4.iterators.UnmodifiableIterator;
import java.lang.reflect.Method;
import org.apache.commons.collections4.iterators.ListIteratorWrapper;
import org.apache.commons.collections4.iterators.EmptyOrderedMapIterator;
import java.util.Arrays;
import org.apache.commons.collections4.iterators.ObjectArrayListIterator;
import org.apache.commons.collections4.iterators.FilterListIterator;
import java.lang.reflect.InvocationTargetException;
import org.apache.commons.collections4.iterators.CollatingIterator;
import org.apache.commons.collections4.iterators.LoopingListIterator;
import org.apache.commons.collections4.iterators.ObjectGraphIterator;
import org.apache.commons.collections4.iterators.PeekingIterator;
import org.apache.commons.collections4.iterators.ArrayIterator;
import java.util.ArrayList;
import org.apache.commons.collections4.iterators.LoopingIterator;
import org.apache.commons.collections4.iterators.IteratorEnumeration;
import org.apache.commons.collections4.iterators.NodeListIterator;
import org.apache.commons.collections4.iterators.TransformIterator;
import java.util.Iterator;
import org.apache.commons.collections4.iterators.EnumerationIterator;
import org.apache.commons.collections4.functors.EqualPredicate;
import org.apache.commons.collections4.iterators.IteratorIterable;
import org.apache.commons.collections4.iterators.ArrayListIterator;
import org.apache.commons.collections4.iterators.SingletonIterator;
import org.apache.commons.collections4.iterators.UnmodifiableListIterator;
import org.apache.commons.collections4.iterators.SingletonListIterator;
import java.lang.reflect.Array;
import org.apache.commons.collections4.iterators.EmptyIterator;
import java.util.Dictionary;
import org.apache.commons.collections4.iterators.EmptyOrderedIterator;
import java.util.Enumeration;
import java.util.Map;
import org.apache.commons.collections4.iterators.ObjectArrayIterator;
import java.util.Collections;
import java.util.List;
import org.apache.commons.collections4.iterators.FilterIterator;
import org.apache.commons.collections4.iterators.IteratorChain;
import java.util.Collection;
import org.apache.commons.collections4.iterators.ZippingIterator;
import org.apache.commons.collections4.iterators.UnmodifiableMapIterator;
import org.w3c.dom.Node;
import org.apache.commons.collections4.iterators.SkippingIterator;
import org.apache.commons.collections4.iterators.PushbackIterator;
import org.w3c.dom.NodeList;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class IteratorUtils_LLMTest extends IteratorUtils_LLMTest_scaffolding {
    
@Test
public void test_0_01() throws Exception {
	try {
    List<String> list1 = Arrays.asList("a", "c");
    List<String> list2 = Arrays.asList("b", "d");
    Iterator<String> it = IteratorUtils.collatedIterator(null, list1.iterator(), list2.iterator());



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_0_11() throws Exception {
	try {
    List<String> list1 = Arrays.asList("a", "c");
    List<String> list2 = Arrays.asList("b", "d");
    Comparator<String> reverseComparator = Collections.reverseOrder();
    Iterator<String> it = IteratorUtils.collatedIterator(reverseComparator, list1.iterator(), list2.iterator());



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_0_21() throws Exception {
	try {
    List<String> emptyList = Collections.emptyList();
    Iterator<String> it = IteratorUtils.collatedIterator(null, emptyList.iterator(), emptyList.iterator());



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_0_31() throws Exception {
	try {
    List<Integer> list1 = Arrays.asList(1, 3);
    List<Integer> list2 = Arrays.asList(2, 4);
    Iterator<Integer> it = IteratorUtils.collatedIterator(null, list1.iterator(), list2.iterator());



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.apache.commons.collections4.keyvalue;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.collections4.keyvalue.MultiKey;
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.util.Arrays;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MultiKey_LLMTest extends MultiKey_LLMTest_scaffolding {
    
@Test
public void test_1_11()  throws Exception {
    MultiKey<String> original = new MultiKey<>(new String[]{"a", "b"});
    int originalHash = original.hashCode();

    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    ObjectOutputStream oos = new ObjectOutputStream(baos);
    oos.writeObject(original);
    oos.close();

    ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
    ObjectInputStream ois = new ObjectInputStream(bais);
    MultiKey<String> deserialized = (MultiKey<String>) ois.readObject();
    ois.close();
      assertNotNull(deserialized.hashCode());
}

}
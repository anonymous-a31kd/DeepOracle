package org.mockito.internal.stubbing.defaultanswers;

 
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;

public class ReturnsEmptyValues_LLMTest_scaffolding {
     
}
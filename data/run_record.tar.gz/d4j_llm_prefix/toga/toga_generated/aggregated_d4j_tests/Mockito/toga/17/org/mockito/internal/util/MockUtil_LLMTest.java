package org.mockito.internal.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.mockito.internal.util.reflection.LenientCopyTool;
import org.mockito.internal.creation.MethodInterceptorFilter;
import org.mockito.exceptions.misusing.NotAMockException;
import org.mockito.internal.MockHandler;
import org.mockito.internal.creation.MockSettingsImpl;
import static org.mockito.Mockito.withSettings;
import org.mockito.cglib.proxy.*;
import java.io.Serializable;
import org.mockito.internal.MockHandlerInterface;
import org.mockito.internal.creation.jmock.ClassImposterizer;
import static org.mockito.Mockito.RETURNS_DEFAULTS;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MockUtil_LLMTest extends MockUtil_LLMTest_scaffolding {
    
@Test
public void test_151_01() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.serializable();
    mockUtil.createMock(Object.class, settings);


    }

@Test
public void test_151_11() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.serializable();
    settings.extraInterfaces(Runnable.class);
    mockUtil.createMock(Object.class, settings);


    }

@Test
public void test_151_21() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    mockUtil.createMock(Object.class, settings);


    }

@Test
public void test_151_31() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.extraInterfaces(Runnable.class);
    mockUtil.createMock(Object.class, settings);


    }

}
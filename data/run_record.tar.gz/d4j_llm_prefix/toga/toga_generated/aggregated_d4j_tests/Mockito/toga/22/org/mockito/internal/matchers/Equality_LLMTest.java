package org.mockito.internal.matchers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Equality_LLMTest extends Equality_LLMTest_scaffolding {
    
@Test
public void test_161_01() throws Exception {
    Object obj = new Object();
    Equality.areEqual(obj, obj);


    }

@Test
public void test_161_11() throws Exception {
    Equality.areEqual(null, null);


    }

@Test
public void test_161_21() throws Exception {
    Equality.areEqual(null, new Object());


    }

@Test
public void test_161_31() throws Exception {
    Equality.areEqual(new Object(), null);


    }

@Test
public void test_161_41() throws Exception {
    String s1 = new String("test");
    String s2 = new String("test");
    Equality.areEqual(s1, s2);


    }

@Test
public void test_161_51() throws Exception {
    String s1 = "test1";
    String s2 = "test2";
    Equality.areEqual(s1, s2);


    }

@Test
public void test_161_61() throws Exception {
    int[] arr1 = {1, 2, 3};
    int[] arr2 = {1, 2, 3};
    Equality.areEqual(arr1, arr2);


    }

@Test
public void test_161_71() throws Exception {
    int[] arr1 = {1, 2, 3};
    int[] arr2 = {1, 2, 4};
    Equality.areEqual(arr1, arr2);


    }

}
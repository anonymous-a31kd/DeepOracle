package org.mockito.internal.creation;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.mockito.stubbing.Answer;
import org.mockito.MockSettings;
import org.mockito.internal.creation.MockSettingsImpl;
import org.mockito.internal.util.MockName;
import java.io.Serializable;
import org.mockito.exceptions.Reporter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MockSettingsImpl_LLMTest extends MockSettingsImpl_LLMTest_scaffolding {
    
@Test
public void test_149_01() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
    MockSettings result = settings.serializable();



    }

@Test
public void test_149_11() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.serializable();



    }

@Test
public void test_149_21() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
    MockSettings result = settings.serializable()
    .name("testMock")
    .defaultAnswer(null);



    }

@Test
public void test_149_31() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();



    }

@Test
public void test_150_01() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.serializable();
      assertFalse(settings.isSerializable());
}

@Test
public void test_150_11() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
      assertFalse(settings.isSerializable());
}

@Test
public void test_150_31() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.initiateMockName(String.class);



    }

@Test
public void test_150_41() throws Exception {
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.initiateMockName(Serializable.class);



    }

}
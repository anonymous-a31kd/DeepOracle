package org.mockito;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.mockito.internal.matchers.apachecommons.ReflectionEquals;
import java.util.List;
import java.util.Collection;
import org.mockito.internal.progress.HandyReturnValues;
import org.hamcrest.Matcher;
import org.mockito.internal.progress.MockingProgress;
import org.mockito.internal.progress.ThreadSafeMockingProgress;
import org.mockito.Matchers;
import java.util.Map;
import org.mockito.internal.matchers.*;
import static org.mockito.Matchers.*;
import java.util.Set;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Matchers_LLMTest extends Matchers_LLMTest_scaffolding {
    
@Test
public void test_176_01() throws Exception {
    String testString = "test";
    String result = eq(testString);


    }

@Test
public void test_176_11() throws Exception {
    Integer testInt = 123;
    Integer result = eq(testInt);


    }

@Test
public void test_176_21() throws Exception {
    Object testObj = new Object();
    Object result = eq(testObj);


    }

@Test
public void test_176_31() throws Exception {
    boolean testBool = true;
    boolean result = eq(testBool);


    }

@Test
public void test_176_41() throws Exception {
    byte testByte = 1;
    byte result = eq(testByte);


    }

@Test
public void test_176_51() throws Exception {
    char testChar = 'a';
    char result = eq(testChar);


    }

@Test
public void test_176_61() throws Exception {
    double testDouble = 1.23;
    double result = eq(testDouble);


    }

@Test
public void test_176_71() throws Exception {
    float testFloat = 1.23f;
    float result = eq(testFloat);


    }

@Test
public void test_176_81() throws Exception {
    long testLong = 123L;
    long result = eq(testLong);


    }

@Test
public void test_176_91() throws Exception {
    short testShort = 123;
    short result = eq(testShort);


    }

@Test
public void test_177_01() throws Exception {
    String result = isA(String.class);



    }

@Test
public void test_177_11() throws Exception {
    Integer result = isA(Integer.class);



    }

@Test
public void test_177_21() throws Exception {
    List result = isA(List.class);



    }

@Test
public void test_177_31() throws Exception {
    class CustomClass {}
    CustomClass result = isA(CustomClass.class);



    }

@Test
public void test_177_41() throws Exception {
    int result = isA(int.class);



    }

@Test
public void test_178_01() throws Exception {
    String input = "test";
    String result = Matchers.same(input);



    }

@Test
public void test_178_11() throws Exception {
    Integer input = 123;
    Integer result = Matchers.same(input);



    }

@Test
public void test_178_21() throws Exception {
    Object input = new Object();
    Object result = Matchers.same(input);



    }

@Test
public void test_178_31() throws Exception {
    Boolean input = true;
    Boolean result = Matchers.same(input);



    }

@Test
public void test_178_41() throws Exception {
    Object input = null;
    Object result = Matchers.same(input);



    }

}
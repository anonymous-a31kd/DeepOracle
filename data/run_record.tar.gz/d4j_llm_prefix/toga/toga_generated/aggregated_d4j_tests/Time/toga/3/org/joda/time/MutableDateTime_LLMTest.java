package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Serializable;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.format.DateTimeFormatter;
import java.io.ObjectOutputStream;
import org.joda.time.field.AbstractReadableInstantFieldProperty;
import org.joda.convert.FromString;
import org.joda.convert.ToString;
import java.util.Locale;
import java.io.ObjectInputStream;
import org.joda.time.DurationFieldType;
import org.joda.time.base.BaseDateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.field.FieldUtils;
import org.joda.time.MutableDateTime;
import org.joda.time.format.ISODateTimeFormat;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MutableDateTime_LLMTest extends MutableDateTime_LLMTest_scaffolding {
    
@Test
public void test_185_01() throws Exception {
	try {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.days(), 0);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_185_11() throws Exception {
	try {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.days(), 1);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_185_21() throws Exception {
	try {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.days(), -1);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_185_41() throws Exception {
	try {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.hours(), 2);

    originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.minutes(), 30);

    originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.seconds(), -45);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_186_01() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    long originalMillis = dt.getMillis();
    dt.addDays(0);



    }

@Test
public void test_186_11() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.addDays(1);



    }

@Test
public void test_186_21() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.addDays(-1);



    }

@Test
public void test_186_31() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(12);



    }

@Test
public void test_186_41() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(0);



    }

@Test
public void test_186_51() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(23);



    }

@Test
public void test_186_61() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.addDays(2);
    dt.setHourOfDay(15);



    }

@Test
public void test_186_71() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(8);
    dt.addDays(3);



    }

}
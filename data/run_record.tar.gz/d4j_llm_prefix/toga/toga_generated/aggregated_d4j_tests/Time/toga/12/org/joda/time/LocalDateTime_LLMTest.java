package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.convert.ToString;
import java.util.GregorianCalendar;
import org.joda.convert.FromString;
import org.joda.time.LocalDateTime;
import java.io.ObjectOutputStream;
import org.joda.time.convert.ConverterManager;
import java.util.Date;
import org.joda.time.field.AbstractReadableInstantFieldProperty;
import org.joda.time.convert.PartialConverter;
import org.joda.time.format.DateTimeFormatter;
import java.util.TimeZone;
import org.joda.time.format.DateTimeFormat;
import java.util.Locale;
import java.io.Serializable;
import java.io.ObjectInputStream;
import org.joda.time.base.BaseLocal;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.chrono.ISOChronology;
import java.util.Calendar;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocalDateTime_LLMTest extends LocalDateTime_LLMTest_scaffolding {
    
@Test
public void test_198_01() throws Exception {
	try {

    Date date = new Date(122, 5, 15, 10, 30, 45);
    LocalDateTime.fromDateFields(date);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_198_11() throws Exception {
	try {

    Date date = new Date(-62135773200000L);
    LocalDateTime.fromDateFields(date);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_198_21() throws Exception {
	try {

    Date date = new Date(0);
    LocalDateTime.fromDateFields(date);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_198_41() throws Exception {
	try {

    Date date = new Date(Long.MIN_VALUE);
    LocalDateTime.fromDateFields(date);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_199_01() throws Exception {
	try {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.ERA, GregorianCalendar.AD);
    calendar.set(Calendar.YEAR, 2023);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_199_11() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    calendar.set(Calendar.YEAR, 1);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);


    }

@Test
public void test_199_31() throws Exception {
    Calendar calendar = Calendar.getInstance();
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);


    }

@Test
public void test_199_41() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    calendar.set(Calendar.YEAR, Integer.MAX_VALUE);
    calendar.set(Calendar.MONTH, Calendar.DECEMBER);
    calendar.set(Calendar.DAY_OF_MONTH, 31);
    calendar.set(Calendar.HOUR_OF_DAY, 23);
    calendar.set(Calendar.MINUTE, 59);
    calendar.set(Calendar.SECOND, 59);
    calendar.set(Calendar.MILLISECOND, 999);
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);


    }

}
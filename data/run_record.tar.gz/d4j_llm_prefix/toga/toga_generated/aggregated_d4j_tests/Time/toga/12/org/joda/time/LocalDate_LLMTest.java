package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.convert.ToString;
import java.util.GregorianCalendar;
import org.joda.convert.FromString;
import java.io.ObjectOutputStream;
import org.joda.time.convert.ConverterManager;
import java.util.HashSet;
import java.util.Set;
import java.util.Date;
import org.joda.time.field.AbstractReadableInstantFieldProperty;
import org.joda.time.convert.PartialConverter;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.field.FieldUtils;
import java.util.TimeZone;
import org.joda.time.format.DateTimeFormat;
import java.util.Locale;
import java.io.Serializable;
import java.io.ObjectInputStream;
import org.joda.time.base.BaseLocal;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.chrono.ISOChronology;
import java.util.Calendar;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocalDate_LLMTest extends LocalDate_LLMTest_scaffolding {
    
@Test
public void test_196_11() throws Exception {
	try {
    Date date = new Date(121, 5, 15);
    LocalDate result = LocalDate.fromDateFields(date);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_196_21() throws Exception {
	try {
    GregorianCalendar cal = new GregorianCalendar();
    cal.set(Calendar.ERA, GregorianCalendar.BC);
    cal.set(Calendar.YEAR, 100);
    cal.set(Calendar.MONTH, Calendar.JANUARY);
    cal.set(Calendar.DAY_OF_MONTH, 1);
    Date bcDate = cal.getTime();
    LocalDate result = LocalDate.fromDateFields(bcDate);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_196_31() throws Exception {
	try {
    Date date = new Date(0);
    LocalDate result = LocalDate.fromDateFields(date);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_196_41() throws Exception {
	try {
    Date date = new Date(-1000L * 60 * 60 * 24 * 365);
    LocalDate result = LocalDate.fromDateFields(date);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_197_01() throws Exception {
	try {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 2023);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.AD);
    LocalDate date = LocalDate.fromCalendarFields(calendar);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_197_11() throws Exception {
	try {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 100);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    LocalDate date = LocalDate.fromCalendarFields(calendar);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_197_21() throws Exception {
	try {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 1);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.AD);
    LocalDate date = LocalDate.fromCalendarFields(calendar);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_197_31() throws Exception {
	try {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 1);
    calendar.set(Calendar.MONTH,Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    LocalDate date = LocalDate.fromCalendarFields(calendar);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.joda.time.format;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.DateTimeUtils;
import java.io.Writer;
import org.joda.time.ReadWritableInstant;
import org.joda.time.Chronology;
import org.joda.time.ReadablePartial;
import org.joda.time.*;
import org.joda.time.ReadableInstant;
import org.joda.time.MutableDateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.DateTime;
import org.joda.time.DateTimeFieldType;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;
import java.util.Locale;
import org.joda.time.format.DateTimeFormatterBuilder;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateTimeFormatter_LLMTest extends DateTimeFormatter_LLMTest_scaffolding {
    
@Test
public void test_204_01() throws Exception {
	try {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(0L);
    int pos = formatter.parseInto(instant, "2023", 0);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_204_11() throws Exception {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(0L);
    int pos = formatter.parseInto(instant, "2000", 0);



    }

@Test
public void test_204_21() throws Exception {
	try {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(0L);
    int pos = formatter.parseInto(instant, "-1000", 0);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_204_41() throws Exception {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(System.currentTimeMillis());
    int pos = formatter.parseInto(instant, "1999", 0);



    }

}
package org.joda.time.format;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.ReadWritablePeriod;
import org.joda.time.format.PeriodFormatterBuilder;
import java.io.Writer;
import org.joda.time.Period;
import java.util.ArrayList;
import java.util.Collections;
import org.joda.time.DateTimeConstants;
import java.util.List;
import java.util.TreeSet;
import org.joda.time.DurationFieldType;
import java.util.Locale;
import org.joda.time.ReadablePeriod;
import org.joda.time.PeriodType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PeriodFormatterBuilder_LLMTest extends PeriodFormatterBuilder_LLMTest_scaffolding {
    
@Test
public void test_201_01() throws Exception {
    PeriodFormatterBuilder builder = new PeriodFormatterBuilder();
    builder.appendSecondsWithMillis();
    Period period = new Period(-500);
    StringBuffer buf = new StringBuffer();
    builder.toPrinter().printTo(buf, period, Locale.ENGLISH);


    }

@Test
public void test_201_11() throws Exception {
    PeriodFormatterBuilder builder = new PeriodFormatterBuilder();
    builder.appendSecondsWithMillis();
    Period period = new Period(-1000);
    StringBuffer buf = new StringBuffer();
    builder.toPrinter().printTo(buf, period, Locale.ENGLISH);


    }

@Test
public void test_201_21() throws Exception {
    PeriodFormatterBuilder builder = new PeriodFormatterBuilder();
    builder.appendSecondsWithMillis();
    Period period = new Period(-1500);
    StringBuffer buf = new StringBuffer();
    builder.toPrinter().printTo(buf, period, Locale.ENGLISH);


    }

@Test
public void test_201_31() throws Exception {
    PeriodFormatterBuilder builder = new PeriodFormatterBuilder();
    builder.appendSecondsWithMillis();
    Period period = new Period(500);
    StringBuffer buf = new StringBuffer();
    builder.toPrinter().printTo(buf, period, Locale.ENGLISH);


    }

@Test
public void test_201_41() throws Exception {
    PeriodFormatterBuilder builder = new PeriodFormatterBuilder();
    builder.appendSecondsWithMillis();
    Period period = new Period(0);
    StringBuffer buf = new StringBuffer();
    builder.toPrinter().printTo(buf, period, Locale.ENGLISH);


    }

@Test
public void test_201_51() throws Exception {
    PeriodFormatterBuilder builder = new PeriodFormatterBuilder();
    builder.appendPrefix("T").appendSecondsWithMillis();
    Period period = new Period(-500);
    StringBuffer buf = new StringBuffer();
    builder.toPrinter().printTo(buf, period, Locale.ENGLISH);


    }

}
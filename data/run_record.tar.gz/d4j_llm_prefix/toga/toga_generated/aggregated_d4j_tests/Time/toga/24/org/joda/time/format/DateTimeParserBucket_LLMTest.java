package org.joda.time.format;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.DateTimeUtils;
import org.joda.time.Chronology;
import org.joda.time.DurationFieldType;
import org.joda.time.DurationField;
import org.joda.time.DateTimeField;
import org.joda.time.DateTimeZone;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.DateTimeFieldType;
import java.util.Locale;
import java.util.Arrays;
import org.joda.time.chrono.ISOChronology;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateTimeParserBucket_LLMTest extends DateTimeParserBucket_LLMTest_scaffolding {
    
@Test
public void test_211_01() throws Exception {
    DateTimeParserBucket bucket = new DateTimeParserBucket(0L, ISOChronology.getInstance(), null);
    bucket.saveField(DateTimeFieldType.year(), 2023);
    bucket.saveField(DateTimeFieldType.monthOfYear(), 6);
    bucket.computeMillis(true, "test");



    }

@Test
public void test_211_11() throws Exception {
    DateTimeParserBucket bucket = new DateTimeParserBucket(0L, ISOChronology.getInstance(), null);
    bucket.saveField(DateTimeFieldType.year(), 2023);
    bucket.saveField(DateTimeFieldType.monthOfYear(), 6);
    bucket.computeMillis(false, "test");



    }

@Test
public void test_211_21() throws Exception {
    DateTimeParserBucket bucket = new DateTimeParserBucket(0L, ISOChronology.getInstance(), null);
    bucket.saveField(DateTimeFieldType.year(), 2023);
    bucket.saveField(DateTimeFieldType.monthOfYear(), 6);
    bucket.saveField(DateTimeFieldType.dayOfMonth(), 15);
    bucket.computeMillis(true, "test");



    }

@Test
public void test_211_41() throws Exception {
    DateTimeParserBucket bucket = new DateTimeParserBucket(0L, ISOChronology.getInstance(), null);
    bucket.saveField(DateTimeFieldType.year(), 2023);
    bucket.computeMillis(true, "test");



    }

}
package org.joda.time.chrono;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import org.joda.time.ReadablePartial;
import org.joda.time.chrono.JulianChronology;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.field.BaseDateTimeField;
import org.joda.time.DateTimeUtils;
import org.joda.time.DurationField;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.IllegalFieldValueException;
import java.util.Map;
import org.joda.time.Chronology;
import java.util.HashMap;
import org.joda.time.chrono.GregorianChronology;
import java.util.Locale;
import org.joda.time.chrono.GJChronology;
import org.joda.time.ReadableInstant;
import org.joda.time.field.DecoratedDurationField;
import org.joda.time.DateTimeField;
import org.joda.time.DateTimeZone;
import org.joda.time.Instant;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GJChronology_LLMTest extends GJChronology_LLMTest_scaffolding {
    
@Test
public void test_206_01() throws Exception {
	try {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    chronology.getDateTimeMillis(1582, 10, 1, 0, 0, 0, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_206_11() throws Exception {
	try {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    chronology.getDateTimeMillis(1583, 1, 1, 0, 0, 0, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_206_31() throws Exception {
	try {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    chronology.getDateTimeMillis(1500, 2, 29, 0, 0, 0, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_206_51() throws Exception {
	try {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    chronology.getDateTimeMillis(2000, 2, 29, 0, 0, 0, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
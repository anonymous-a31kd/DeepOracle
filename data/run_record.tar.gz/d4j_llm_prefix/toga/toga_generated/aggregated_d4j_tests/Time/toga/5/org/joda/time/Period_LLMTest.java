package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Serializable;
import org.joda.time.Period;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.format.ISOPeriodFormat;
import org.joda.convert.FromString;
import org.joda.time.PeriodType;
import org.joda.time.base.BasePeriod;
import org.joda.time.DurationFieldType;
import org.joda.time.field.FieldUtils;
import org.joda.time.format.PeriodFormatter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Period_LLMTest extends Period_LLMTest_scaffolding {
    
@Test
public void test_188_01() throws Exception {
    Period period = new Period(2, 14, 0, 0, 0, 0, 0, 0);
    Period result = period.normalizedStandard(PeriodType.yearMonthDayTime());


    }

@Test
public void test_188_21() throws Exception {
    Period period = new Period(0, 25, 0, 0, 0, 0, 0, 0);
    PeriodType type = PeriodType.months();
    Period result = period.normalizedStandard(type);


    }

@Test
public void test_188_41() throws Exception {
    Period period = new Period(0, 0, 1, 1, 0, 0, 0, 0);
    Period result = period.normalizedStandard(PeriodType.yearMonthDayTime());


    }

@Test
public void test_188_51() throws Exception {
    Period period = new Period(0, 123, 0, 0, 0, 0, 0, 0);
    Period result = period.normalizedStandard(PeriodType.yearMonthDayTime());


    }

@Test
public void test_188_61() throws Exception {
    Period period = new Period(-1, -13, 0, 0, 0, 0, 0, 0);
    Period result = period.normalizedStandard(PeriodType.yearMonthDayTime());


    }

}
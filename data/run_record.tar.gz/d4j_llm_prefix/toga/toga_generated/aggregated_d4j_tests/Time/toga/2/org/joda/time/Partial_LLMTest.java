package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.base.AbstractPartial;
import java.util.List;
import org.joda.time.chrono.ISOChronology;
import java.util.Locale;
import java.util.ArrayList;
import org.joda.time.field.AbstractPartialFieldProperty;
import java.util.Arrays;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.DateTimeFieldType;
import org.joda.time.field.FieldUtils;
import org.joda.time.format.DateTimeFormat;
import java.io.Serializable;
import org.joda.time.Chronology;
import org.joda.time.DurationFieldType;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.Partial;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Partial_LLMTest extends Partial_LLMTest_scaffolding {
    
@Test
public void test_182_01() throws Exception {
    DateTimeFieldType fieldType = DateTimeFieldType.secondOfMinute();
    Partial partial = new Partial();
    partial.with(fieldType, 30);


    }

@Test
public void test_182_11() throws Exception {
    DateTimeFieldType fieldType = DateTimeFieldType.dayOfMonth();
    Partial partial = new Partial();
    partial.with(fieldType, 15);


    }

@Test
public void test_182_21() throws Exception {
    DateTimeFieldType type1 = DateTimeFieldType.secondOfMinute();
    DateTimeFieldType type2 = DateTimeFieldType.dayOfMonth();
    Partial partial = new Partial(new DateTimeFieldType[]{type1}, new int[]{30});
    partial.with(type2, 15);


    }

@Test
public void test_182_31() throws Exception {
    DateTimeFieldType type1 = DateTimeFieldType.secondOfMinute();
    DateTimeFieldType type2 = DateTimeFieldType.millisOfSecond();
    DateTimeFieldType newType = DateTimeFieldType.minuteOfHour();
    Partial partial = new Partial(new DateTimeFieldType[]{type1, type2}, new int[]{30, 500});
    partial.with(newType, 15);


    }

@Test
public void test_183_01() throws Exception {
    DateTimeFieldType[] types = new DateTimeFieldType[] {
        DateTimeFieldType.year(),
        DateTimeFieldType.monthOfYear(),
        DateTimeFieldType.dayOfMonth()
    };
    int[] values = new int[] {2023, 6, 15};
    new Partial(types, values, ISOChronology.getInstanceUTC());


    }

}
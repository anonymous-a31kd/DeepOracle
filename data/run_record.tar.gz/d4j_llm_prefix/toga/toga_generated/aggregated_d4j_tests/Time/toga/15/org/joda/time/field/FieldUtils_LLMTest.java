package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.DateTimeFieldType;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.DateTimeField;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FieldUtils_LLMTest extends FieldUtils_LLMTest_scaffolding {
    
@Test
public void test_203_01() throws Exception {
    FieldUtils.safeMultiply(Long.MIN_VALUE, -1);


    }

@Test
public void test_203_11() throws Exception {
    FieldUtils.safeMultiply(100L, -1);


    }

@Test
public void test_203_21() throws Exception {
    FieldUtils.safeMultiply(Long.MAX_VALUE, 0);


    }

@Test
public void test_203_31() throws Exception {
    FieldUtils.safeMultiply(123456789L, 1);


    }

@Test
public void test_203_41() throws Exception {
    FieldUtils.safeMultiply(1000L, 50);


    }

@Test
public void test_203_51() throws Exception {
    FieldUtils.safeMultiply(-500L, -3);


    }

@Test
public void test_203_61() throws Exception {
    FieldUtils.safeMultiply(-200L, 4);


    }

}
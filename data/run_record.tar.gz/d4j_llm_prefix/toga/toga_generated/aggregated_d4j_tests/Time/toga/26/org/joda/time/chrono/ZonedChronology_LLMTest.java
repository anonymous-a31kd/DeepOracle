package org.joda.time.chrono;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Locale;
import org.joda.time.field.BaseDateTimeField;
import org.joda.time.field.MillisDurationField;
import org.joda.time.Instant;
import org.joda.time.field.BaseDurationField;
import org.joda.time.ReadablePartial;
import org.joda.time.Chronology;
import org.joda.time.DateTimeField;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.DurationField;
import org.joda.time.chrono.ZonedChronology;
import org.joda.time.DateTimeConstants;
import org.joda.time.chrono.ISOChronology;
import java.util.HashMap;
import org.joda.time.field.StrictDateTimeField;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.chrono.GregorianChronology;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZonedChronology_LLMTest extends ZonedChronology_LLMTest_scaffolding {
    
@Test
public void test_215_01() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/London");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.dayOfMonth();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, 1);


    }

@Test
public void test_215_11() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("America/New_York");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.monthOfYear();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, 1);


    }

@Test
public void test_215_21() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/London");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.hourOfDay();

    long instant = 1616900400000L;
    field.addWrapField(instant, 1);


    }

@Test
public void test_215_31() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Asia/Tokyo");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.dayOfMonth();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, -5);


    }

@Test
public void test_215_41() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("UTC");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.monthOfYear();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, 100);


    }

@Test
public void test_216_01() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/London");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.dayOfMonth();
    long instant = System.currentTimeMillis();
    field.roundCeiling(instant);


    }

@Test
public void test_216_11() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("America/New_York");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.monthOfYear();
    long instant = System.currentTimeMillis();
    field.roundCeiling(instant);


    }

@Test
public void test_216_21() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/Paris");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.hourOfDay();

    long instant = 1616893200000L;
    field.roundCeiling(instant);


    }

@Test
public void test_216_31() throws Exception {
    DateTimeZone zone = DateTimeZone.UTC;
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.secondOfMinute();
    long instant = System.currentTimeMillis();
    field.roundCeiling(instant);


    }

@Test
public void test_216_41() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Asia/Tokyo");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.year();
    long instant = -100000000000L;
    field.roundCeiling(instant);


    }

@Test
public void test_218_01() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(2);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 1000000000L;
    field.set(instant, "5", Locale.ENGLISH);


    }

@Test
public void test_218_11() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(-5);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = -1000000000L;
    field.set(instant, "12", Locale.ENGLISH);


    }

@Test
public void test_218_21() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(0);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 0L;
    field.set(instant, "1", Locale.ENGLISH);


    }

@Test
public void test_218_31() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(3);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 500000000L;
    field.set(instant, "June", Locale.ENGLISH);
    field.set(instant, "juin", Locale.FRENCH);


    }

@Test
public void test_218_41() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("America/New_York");
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 1593568800000L;
    field.set(instant, "11", Locale.ENGLISH);


    }

}
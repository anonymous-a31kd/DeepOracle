package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.DateTimeConstants;
import org.joda.convert.ToString;
import java.io.ObjectStreamException;
import org.joda.time.tz.FixedDateTimeZone;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormatter;
import java.lang.ref.Reference;
import org.joda.time.tz.ZoneInfoProvider;
import java.io.Serializable;
import org.joda.time.tz.UTCProvider;
import java.io.ObjectOutputStream;
import org.joda.time.format.DateTimeFormatterBuilder;
import java.util.Set;
import org.joda.time.tz.NameProvider;
import java.util.Locale;
import java.lang.ref.SoftReference;
import java.util.TimeZone;
import java.util.Map;
import org.joda.convert.FromString;
import org.joda.time.format.FormatUtils;
import org.joda.time.tz.Provider;
import org.joda.time.tz.DefaultNameProvider;
import java.util.HashMap;
import java.io.ObjectInputStream;
import org.joda.time.field.FieldUtils;
import org.joda.time.chrono.BaseChronology;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateTimeZone_LLMTest extends DateTimeZone_LLMTest_scaffolding {
    
@Test
public void test_193_01() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(0, -59);


    }

@Test
public void test_193_41() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(-1, -30);


    }

@Test
public void test_193_51() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(23, 59);


    }

@Test
public void test_193_61() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(-23, -59);


    }

@Test
public void test_193_71() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(0, 0);


    }

@Test
public void test_193_101() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(-5, 30);


    }

@Test
public void test_193_111() throws Exception {
    DateTimeZone.forOffsetHoursMinutes(-1, -30);


    }

}
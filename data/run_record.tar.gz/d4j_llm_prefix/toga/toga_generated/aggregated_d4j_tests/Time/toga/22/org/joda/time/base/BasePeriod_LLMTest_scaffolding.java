package org.joda.time.base;

 
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;

public class BasePeriod_LLMTest_scaffolding {
     
}
package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Collection;
import java.util.NoSuchElementException;
import java.util.List;
import java.net.URL;
import static org.apache.commons.csv.Token.Type.*;
import java.util.Iterator;
import java.io.File;
import java.util.Map;
import java.io.FileInputStream;
import java.nio.charset.Charset;
import java.io.StringReader;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.io.InputStreamReader;
import java.io.Reader;
import org.apache.commons.csv.CSVParser;
import java.util.ArrayList;
import java.io.Closeable;
import org.apache.commons.csv.CSVFormat;
import java.io.FileReader;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVParser_LLMTest extends CSVParser_LLMTest_scaffolding {
    
@Test
public void test_43_01()  throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null).withIgnoreEmptyHeaders(false);
    CSVParser parser = new CSVParser(new StringReader(""), format);
    Map<String, Integer> headerMap = parser.getHeaderMap();



    }

@Test
public void test_43_11()  throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("").withIgnoreEmptyHeaders(false);
    CSVParser parser = new CSVParser(new StringReader(""), format);
    Map<String, Integer> headerMap = parser.getHeaderMap();



    }

@Test
public void test_43_21()  throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null).withIgnoreEmptyHeaders(true);
    CSVParser parser = new CSVParser(new StringReader(""), format);
    Map<String, Integer> headerMap = parser.getHeaderMap();



    }

@Test
public void test_43_31()  throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("col1", null, "col2").withIgnoreEmptyHeaders(false);
    CSVParser parser = new CSVParser(new StringReader(""), format);
    Map<String, Integer> headerMap = parser.getHeaderMap();



    }

}
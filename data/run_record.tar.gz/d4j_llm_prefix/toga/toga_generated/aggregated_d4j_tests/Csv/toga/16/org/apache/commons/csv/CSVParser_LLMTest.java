package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Map;
import org.apache.commons.csv.CSVFormat;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.util.TreeMap;
import java.io.Closeable;
import java.util.LinkedHashMap;
import static org.apache.commons.csv.Token.Type.TOKEN;
import java.nio.file.Files;
import org.apache.commons.csv.CSVRecord;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Arrays;
import java.io.File;
import java.util.NoSuchElementException;
import java.util.List;
import java.nio.charset.Charset;
import java.io.Reader;
import org.apache.commons.csv.CSVParser;
import java.util.ArrayList;
import java.nio.file.Path;
import java.io.FileInputStream;
import java.net.URL;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVParser_LLMTest extends CSVParser_LLMTest_scaffolding {
    
@Test
public void test_46_01()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader(""), CSVFormat.DEFAULT);
    parser.close();
    Iterator<CSVRecord> iterator = parser.iterator();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_46_21()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader(""), CSVFormat.DEFAULT);
    Iterator<CSVRecord> iterator = parser.iterator();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_46_41()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader("a,b,c"), CSVFormat.DEFAULT);
    Iterator<CSVRecord> iterator = parser.iterator();

    iterator.next();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_46_51()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader("a,b,c\n1,2,3"), CSVFormat.DEFAULT);
    Iterator<CSVRecord> iterator = parser.iterator();

    iterator.next();

    iterator.next();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_47_01()  throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 0L, 1L);

    parser.iterator();


    }

@Test
public void test_47_11()  throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 10L, 5L);

    parser.iterator();


    }

@Test
public void test_47_21()  throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 0L, 1L);

    parser.iterator();
    parser.iterator();


    }

@Test
public void test_47_31()  throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 0L, 1L);
    parser.close();

    parser.iterator();


    }

}
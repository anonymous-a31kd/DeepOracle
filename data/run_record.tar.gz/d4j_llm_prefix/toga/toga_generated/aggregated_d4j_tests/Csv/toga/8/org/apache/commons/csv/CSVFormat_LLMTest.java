package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.apache.commons.csv.Constants.TAB;
import static org.apache.commons.csv.Constants.COMMA;
import static org.apache.commons.csv.Constants.DOUBLE_QUOTE_CHAR;
import java.util.HashSet;
import java.util.Set;
import static org.apache.commons.csv.Constants.CRLF;
import java.io.StringWriter;
import static org.apache.commons.csv.Constants.BACKSLASH;
import static org.apache.commons.csv.Constants.LF;
import java.util.Arrays;
import java.io.Reader;
import java.io.Serializable;
import static org.apache.commons.csv.Constants.CR;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVFormat_LLMTest extends CSVFormat_LLMTest_scaffolding {
    
@Test
public void test_57_01() throws Exception {
	try {
    CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null);
    format.validate();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_11() throws Exception {
	try {
    CSVFormat format = CSVFormat.DEFAULT.withHeader(new String[0]);
    format.validate();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_21() throws Exception {
	try {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("name");
    format.validate();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_31() throws Exception {
	try {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "age", "city");
    format.validate();


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_57_61() throws Exception {
	try {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("Name", "name", "NAME");
    format.validate();


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
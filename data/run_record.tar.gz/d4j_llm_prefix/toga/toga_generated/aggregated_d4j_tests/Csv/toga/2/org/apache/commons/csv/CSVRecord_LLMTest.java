package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.io.Serializable;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVRecord_LLMTest extends CSVRecord_LLMTest_scaffolding {
    
@Test
public void test_38_01() throws Exception {
	try {
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("header1", 0);
    String[] values = {"value1"};
    CSVRecord record = new CSVRecord(values, mapping, null, 1);
    record.get("header1");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_38_11() throws Exception {
	try {
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("header1", null);
    String[] values = {"value1"};
    CSVRecord record = new CSVRecord(values, mapping, null, 1);
    record.get("header1");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_38_41() throws Exception {
	try {
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("header1", 0);
    String[] values = {"value1"};
    CSVRecord record = new CSVRecord(values, mapping, null, 1);
    record.get("nonexistent");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Map.Entry;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVRecord_LLMTest extends CSVRecord_LLMTest_scaffolding {
    
@Test
public void test_55_01() throws Exception {
    String[] values = {"val1", "val2"};
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("key1", 0);
    mapping.put("key2", 1);
    CSVRecord record = new CSVRecord(values, mapping, null, 1);
    Map<String, String> map = new HashMap<>();
    record.putIn(map);



    }

@Test
public void test_55_11() throws Exception {
    String[] values = {"val1"};
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("key1", 0);
    mapping.put("key2", 1);
    CSVRecord record = new CSVRecord(values, mapping, null, 1);
    Map<String, String> map = new HashMap<>();
    record.putIn(map);



    }

@Test
public void test_55_21() throws Exception {
    String[] values = {};
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("key1", 0);
    CSVRecord record = new CSVRecord(values, mapping, null, 1);
    Map<String, String> map = new HashMap<>();
    record.putIn(map);



    }

@Test
public void test_55_31() throws Exception {
    Map<String, Integer> mapping = new HashMap<>();
    mapping.put("key1", 0);
    CSVRecord record = new CSVRecord(null, mapping, null, 1);
    Map<String, String> map = new HashMap<>();
    record.putIn(map);



    }

}
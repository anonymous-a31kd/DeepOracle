package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.DecoderException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Base64_LLMTest extends Base64_LLMTest_scaffolding {
    
@Test
public void test_10_01() throws Exception {
    byte[] input = "Test input for chunked encoding".getBytes();
    Base64.encodeBase64(input, true, false, Integer.MAX_VALUE);


    }

@Test
public void test_10_11() throws Exception {
    byte[] input = "Test input for non-chunked encoding".getBytes();
    Base64.encodeBase64(input, false, false, Integer.MAX_VALUE);


    }

@Test
public void test_10_21() throws Exception {
    byte[] input = "Test input for url-safe chunked encoding".getBytes();
    Base64.encodeBase64(input, true, true, Integer.MAX_VALUE);


    }

@Test
public void test_10_31() throws Exception {
    byte[] input = "Test input for url-safe non-chunked encoding".getBytes();
    Base64.encodeBase64(input, false, true, Integer.MAX_VALUE);


    }

@Test
public void test_10_61() throws Exception {
    byte[] input = new byte[0];
    byte[] result = Base64.encodeBase64(input, true, false, Integer.MAX_VALUE);



    }

@Test
public void test_10_71() throws Exception {
    byte[] input = null;
    byte[] result = Base64.encodeBase64(input, true, false, Integer.MAX_VALUE);



    }

}
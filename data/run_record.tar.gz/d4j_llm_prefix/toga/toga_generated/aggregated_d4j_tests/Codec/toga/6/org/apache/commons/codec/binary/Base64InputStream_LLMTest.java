package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.codec.binary.Base64InputStream;
import java.io.FilterInputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Base64InputStream_LLMTest extends Base64InputStream_LLMTest_scaffolding {
    
@Test
public void test_6_01()  throws Exception {
	try {
    InputStream emptyInput = new ByteArrayInputStream(new byte[0]);
    Base64InputStream bis = new Base64InputStream(emptyInput);
    byte[] buffer = new byte[1024];
    int read = bis.read(buffer, 0, buffer.length);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_6_11()  throws Exception {
	try {

    String input = "ABC123!@#DEF456";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    Base64InputStream bis = new Base64InputStream(is, false);
    byte[] buffer = new byte[1024];
    int read = bis.read(buffer, 0, buffer.length);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_6_21()  throws Exception {
	try {
    String input = "QUJDMTIzREVGNDU2";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    Base64InputStream bis = new Base64InputStream(is, false);
    byte[] buffer = new byte[1024];
    int read = bis.read(buffer, 0, buffer.length);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_6_31()  throws Exception {
	try {
    String input = "QUJDMTIzREVGNDU2";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    Base64InputStream bis = new Base64InputStream(is, false);
    byte[] buffer = new byte[1024];
    int read = bis.read(buffer, 10, 100);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_6_41()  throws Exception {
	try {
    String input = "QUJDMTIzREVGNDU2";
    InputStream is = new ByteArrayInputStream(input.getBytes());
    Base64InputStream bis = new Base64InputStream(is, false);
    byte[] buffer = new byte[1024];
    int read = bis.read(buffer, 0, 0);



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
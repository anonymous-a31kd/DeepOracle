package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.codec.Charsets;
import java.nio.ByteBuffer;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import org.apache.commons.codec.CharEncoding;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_22_01() throws Exception {
    CharSequence cs = "test";
    

    }

@Test
public void test_22_11() throws Exception {
    

    }

@Test
public void test_22_21() throws Exception {
    

    }

@Test
public void test_22_31() throws Exception {
    

    }

@Test
public void test_22_41() throws Exception {
    CharSequence cs1 = new StringBuilder("test");
    CharSequence cs2 = new StringBuffer("test");
    

    }

@Test
public void test_22_51() throws Exception {
    CharSequence cs1 = "test";
    CharSequence cs2 = "testing";
    

    }

@Test
public void test_22_61() throws Exception {
    CharSequence cs1 = "test1";
    CharSequence cs2 = "test2";
    

    }

@Test
public void test_22_71() throws Exception {
    

    }

@Test
public void test_22_81() throws Exception {
    

    }

}
package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import org.apache.commons.codec.binary.Base64InputStream;
import java.io.InputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Base64InputStream_LLMTest extends Base64InputStream_LLMTest_scaffolding {
    
@Test
public void test_9_01()  throws Exception {
	try {
    byte[] input = "test".getBytes();
    ByteArrayInputStream bais = new ByteArrayInputStream(input);
    Base64InputStream bis = new Base64InputStream(bais, true);
    byte[] buffer = new byte[4];
    bis.read(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_9_11()  throws Exception {
	try {
    byte[] input = "test".getBytes();
    ByteArrayInputStream bais = new ByteArrayInputStream(input);
    Base64InputStream bis = new Base64InputStream(bais, true);
    byte[] buffer = new byte[8];
    bis.read(buffer, 0, 4);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_9_31()  throws Exception {
	try {
    byte[] input = new byte[0];
    ByteArrayInputStream bais = new ByteArrayInputStream(input);
    Base64InputStream bis = new Base64InputStream(bais, true);
    byte[] buffer = new byte[4];
    bis.read(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_9_41()  throws Exception {
	try {
    byte[] input = "dGVzdA==".getBytes();
    ByteArrayInputStream bais = new ByteArrayInputStream(input);
    Base64InputStream bis = new Base64InputStream(bais, false);
    byte[] buffer = new byte[4];
    bis.read(buffer, 0, buffer.length);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
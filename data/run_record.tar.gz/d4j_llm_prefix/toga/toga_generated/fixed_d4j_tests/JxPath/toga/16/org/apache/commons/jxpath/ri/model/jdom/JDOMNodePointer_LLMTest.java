package org.apache.commons.jxpath.ri.model.jdom;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.JXPathException;
import org.jdom.ProcessingInstruction;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.jdom.Attribute;
import org.apache.commons.jxpath.ri.Compiler;
import org.jdom.Element;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import java.util.Locale;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.util.TypeUtils;
import java.util.List;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.jdom.Namespace;
import org.jdom.Comment;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.jdom.CDATA;
import org.apache.commons.jxpath.ri.QName;
import org.jdom.Document;
import org.jdom.Text;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JDOMNodePointer_LLMTest extends JDOMNodePointer_LLMTest_scaffolding {
    
@Test
public void test_134_01() throws Exception {
    Element element = new Element("test");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    JDOMNodePointer.testNode(null, element, test);


    }

@Test
public void test_134_11() throws Exception {
    Document doc = new Document();
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    JDOMNodePointer.testNode(null, doc, test);


    }

@Test
public void test_134_21() throws Exception {
    Text text = new Text("test");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    JDOMNodePointer.testNode(null, text, test);


    }

@Test
public void test_134_31() throws Exception {
    CDATA cdata = new CDATA("<test>");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    JDOMNodePointer.testNode(null, cdata, test);


    }

@Test
public void test_134_41() throws Exception {
    Comment comment = new Comment("test");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    JDOMNodePointer.testNode(null, comment, test);


    }

@Test
public void test_134_51() throws Exception {
    ProcessingInstruction pi = new ProcessingInstruction("target", "data");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    JDOMNodePointer.testNode(null, pi, test);


    }

@Test
public void test_134_61() throws Exception {
    Text text = new Text("test");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_TEXT);
    JDOMNodePointer.testNode(null, text, test);


    }

@Test
public void test_134_71() throws Exception {
    Comment comment = new Comment("test");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_COMMENT);
    JDOMNodePointer.testNode(null, comment, test);


    }

}
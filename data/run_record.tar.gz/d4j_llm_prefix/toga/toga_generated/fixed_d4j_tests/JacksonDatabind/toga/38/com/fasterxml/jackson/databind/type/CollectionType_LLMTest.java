package com.fasterxml.jackson.databind.type;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.databind.JavaType;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CollectionType_LLMTest extends CollectionType_LLMTest_scaffolding {
    
@Test
public void test_70_01() throws Exception {
    Class<?> rawType = ArrayList.class;
    JavaType elemT = TypeFactory.unknownType();
    CollectionType result = CollectionType.construct(rawType, elemT);



    }

@Test
public void test_70_11() throws Exception {
    Class<?> rawType = Object.class;
    JavaType elemT = TypeFactory.unknownType();
    CollectionType result = CollectionType.construct(rawType, elemT);



    }

@Test
public void test_70_21() throws Exception {
    Class<?> rawType = List.class;
    JavaType elemT = TypeFactory.unknownType();
    CollectionType result = CollectionType.construct(rawType, elemT);



    }

}
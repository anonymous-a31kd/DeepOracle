package com.fasterxml.jackson.databind.type;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.databind.type.SimpleType;
import com.fasterxml.jackson.databind.JavaType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class SimpleType_LLMTest extends SimpleType_LLMTest_scaffolding {
    
@Test
public void test_72_01() throws Exception {
	try {
    SimpleType type = SimpleType.construct(String.class);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_72_41() throws Exception {
	try {
    SimpleType type = SimpleType.construct(Object.class);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_72_51() throws Exception {
	try {
    SimpleType type = SimpleType.construct(Integer.class);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_72_61() throws Exception {
	try {
    SimpleType type = SimpleType.construct(Comparable.class);



		fail("Expecting exception"); } catch (Exception e) { }
	}

}
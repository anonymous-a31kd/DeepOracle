package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.apache.commons.compress.archivers.zip.ZipConstants.WORD;
import java.util.zip.Inflater;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import static org.apache.commons.compress.archivers.zip.ZipConstants.DWORD;
import java.io.InputStream;
import java.util.zip.CRC32;
import java.nio.ByteBuffer;
import java.util.zip.DataFormatException;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.utils.IOUtils;
import java.io.EOFException;
import static org.apache.commons.compress.archivers.zip.ZipConstants.SHORT;
import java.io.PushbackInputStream;
import static org.apache.commons.compress.archivers.zip.ZipConstants.ZIP64_MAGIC;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveInputStream_LLMTest extends ZipArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_46_01() throws Exception {
    InputStream input = new ByteArrayInputStream(new byte[0]);
    String testEncoding = "UTF-8";
    ZipArchiveInputStream zis = new ZipArchiveInputStream(
    input, testEncoding, true, false);



    }

@Test
public void test_46_11() throws Exception {
    InputStream input = new ByteArrayInputStream(new byte[0]);
    ZipArchiveInputStream zis = new ZipArchiveInputStream(
    input, null, false, true);



    }

@Test
public void test_46_31() throws Exception {
    InputStream input = new ByteArrayInputStream(new byte[0]);
    String testEncoding = "ISO-8859-1";
    ZipArchiveInputStream zis = new ZipArchiveInputStream(
    input, testEncoding, false, true);



    }

}
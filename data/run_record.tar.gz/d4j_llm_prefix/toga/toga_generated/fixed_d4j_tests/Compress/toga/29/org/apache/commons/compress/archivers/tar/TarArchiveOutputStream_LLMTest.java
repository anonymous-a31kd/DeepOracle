package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.Map;
import java.util.Arrays;
import org.apache.commons.compress.utils.CountingOutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.CharsetNames;
import java.io.File;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import java.util.Date;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveOutputStream_LLMTest extends TarArchiveOutputStream_LLMTest_scaffolding {
    
@Test
public void test_45_01() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    new TarArchiveOutputStream(os, 512, 512, null);


    }

@Test
public void test_45_21() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    new TarArchiveOutputStream(os, 512, 512, CharsetNames.UTF_8);


    }

@Test
public void test_45_31() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    new TarArchiveOutputStream(os, 512, 512, CharsetNames.US_ASCII);


    }

@Test
public void test_45_41() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    new TarArchiveOutputStream(os, 512, 512, CharsetNames.ISO_8859_1);


    }

@Test
public void test_45_51() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    new TarArchiveOutputStream(os, 1024, 512, CharsetNames.UTF_8);


    }

}
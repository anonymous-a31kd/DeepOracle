package org.apache.commons.compress.utils;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.Checksum;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ChecksumCalculatingInputStream_LLMTest extends ChecksumCalculatingInputStream_LLMTest_scaffolding {
    
@Test
public void test_52_01() throws Exception {
    InputStream mockStream = new InputStream() {
        @Override
        public int read() {
            return 0;
        }
    };
    new ChecksumCalculatingInputStream(null, mockStream);


    }

@Test
public void test_52_21() throws Exception {
    new ChecksumCalculatingInputStream(null, null);


    }

}
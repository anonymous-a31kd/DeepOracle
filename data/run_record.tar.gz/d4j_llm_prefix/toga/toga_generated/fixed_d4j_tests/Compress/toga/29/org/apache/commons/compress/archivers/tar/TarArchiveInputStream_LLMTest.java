package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.utils.CharsetNames;
import java.util.HashMap;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Map;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import java.util.Map.Entry;
import org.apache.commons.compress.utils.ArchiveUtils;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveInputStream_LLMTest extends TarArchiveInputStream_LLMTest_scaffolding {
    
@Test
public void test_44_01() throws Exception {
    InputStream dummyInput = new ByteArrayInputStream(new byte[0]);
    String testEncoding = "UTF-8";
    TarArchiveInputStream tais = new TarArchiveInputStream(dummyInput, 512, 1024, testEncoding);



    }

@Test
public void test_44_11() throws Exception {
    InputStream dummyInput = new ByteArrayInputStream(new byte[0]);
    TarArchiveInputStream tais = new TarArchiveInputStream(dummyInput, 512, 1024, null);



    }

@Test
public void test_44_31() throws Exception {
    InputStream dummyInput = new ByteArrayInputStream(new byte[0]);
    String unsupportedEncoding = "UNSUPPORTED_ENCODING";
    TarArchiveInputStream tais = new TarArchiveInputStream(dummyInput, 512, 1024, unsupportedEncoding);



    }

@Test
public void test_44_41() throws Exception {
    InputStream dummyInput = new ByteArrayInputStream(new byte[0]);
    String testEncoding = "ISO-8859-1";
    TarArchiveInputStream tais = new TarArchiveInputStream(dummyInput, 512, 1024, testEncoding);



    }

}
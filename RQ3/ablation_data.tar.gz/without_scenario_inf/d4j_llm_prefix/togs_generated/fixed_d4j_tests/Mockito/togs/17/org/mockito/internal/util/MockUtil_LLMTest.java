package org.mockito.internal.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.mockito.internal.creation.MockSettingsImpl;
import org.mockito.internal.MockHandlerInterface;
import org.mockito.internal.creation.MethodInterceptorFilter;
import org.mockito.cglib.proxy.*;
import static org.mockito.Mockito.RETURNS_DEFAULTS;
import org.mockito.exceptions.misusing.NotAMockException;
import org.mockito.internal.creation.jmock.ClassImposterizer;
import org.mockito.internal.util.reflection.LenientCopyTool;
import java.io.Serializable;
import static org.mockito.Mockito.withSettings;
import org.mockito.internal.MockHandler;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MockUtil_LLMTest extends MockUtil_LLMTest_scaffolding {
    
@Test
public void test_151_01() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.serializable();
    Object mock = mockUtil.createMock(Object.class, settings);
    
    // Assert that the created object is a mock
    assertTrue(mockUtil.isMock(mock));
}

@Test
public void test_151_11() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.serializable();
    settings.extraInterfaces(Runnable.class);
    Object mock = mockUtil.createMock(Object.class, settings);
    
    // Assert that the created mock is indeed a mock
    assertTrue(mockUtil.isMock(mock));
}

@Test
public void test_151_21() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    Object mockObject = mockUtil.createMock(Object.class, settings);
    assertTrue(mockUtil.isMock(mockObject));
}

@Test
public void test_151_31() throws Exception {
    MockUtil mockUtil = new MockUtil();
    MockSettingsImpl settings = new MockSettingsImpl();
    settings.extraInterfaces(Runnable.class);
    Object mock = mockUtil.createMock(Object.class, settings);
    
    // Verify that the mock object is created and is indeed a mock
    assertTrue(mockUtil.isMock(mock));
}

}
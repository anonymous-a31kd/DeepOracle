package org.apache.commons.math.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Arrays;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MathUtils_LLMTest extends MathUtils_LLMTest_scaffolding {
    
@Test
public void test_190_11() throws Exception {
    // Test binomialCoefficient method with valid inputs
    long result1 = MathUtils.binomialCoefficient(62, 31);
    long result2 = MathUtils.binomialCoefficient(66, 33);
    
    // Assert the expected results
    assertEquals(465428353255261088L, result1);
    assertEquals(7219428434016265740L, result2);
}

@Test
public void test_190_31() throws Exception {

    long result1 = MathUtils.binomialCoefficient(10, 3);
    long result2 = MathUtils.binomialCoefficient(10, 7);
    long result3 = MathUtils.binomialCoefficient(50, 20);
    long result4 = MathUtils.binomialCoefficient(50, 30);

    assertEquals(result1, result2);
    assertEquals(result3, result4);
}

@Test
public void test_190_41() throws Exception {
    assertEquals(1, MathUtils.binomialCoefficient(5, 0));
    assertEquals(1, MathUtils.binomialCoefficient(5, 5));
    assertEquals(5, MathUtils.binomialCoefficient(5, 1));
    assertEquals(5, MathUtils.binomialCoefficient(5, 4));
}

}
package org.apache.commons.math.linear;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Serializable;
import org.apache.commons.math.linear.BigMatrixImpl;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class BigMatrixImpl_LLMTest extends BigMatrixImpl_LLMTest_scaffolding {
    
@Test
public void test_193_01() throws Exception {
    BigDecimal[][] data = {
        {new BigDecimal(1), new BigDecimal(2)},
        {new BigDecimal(3), new BigDecimal(4)}
    };
    BigMatrixImpl matrix = new BigMatrixImpl(data);
    BigDecimal[] vector = {new BigDecimal(5), new BigDecimal(6)};
    BigDecimal[] result = matrix.operate(vector);
    assertArrayEquals(new BigDecimal[]{new BigDecimal(17), new BigDecimal(39)}, result);
}

@Test
public void test_193_11() throws Exception {
    BigDecimal[][] data = {
        {new BigDecimal(1), new BigDecimal(2)},
        {new BigDecimal(3), new BigDecimal(4)},
        {new BigDecimal(5), new BigDecimal(6)}
    };
    BigMatrixImpl matrix = new BigMatrixImpl(data);
    BigDecimal[] vector = {new BigDecimal(7), new BigDecimal(8)};
    BigDecimal[] result = matrix.operate(vector);

    // The expected result is calculated as follows:
    // [1*7 + 2*8, 3*7 + 4*8, 5*7 + 6*8] = [23, 53, 83]
    BigDecimal[] expected = {new BigDecimal(23), new BigDecimal(53), new BigDecimal(83)};
    assertArrayEquals(expected, result);
}

@Test
public void test_193_21() throws Exception {
    BigDecimal[][] data = {
        {new BigDecimal(1), new BigDecimal(2), new BigDecimal(3)},
        {new BigDecimal(4), new BigDecimal(5), new BigDecimal(6)}
    };
    BigMatrixImpl matrix = new BigMatrixImpl(data);
    BigDecimal[] vector = {new BigDecimal(7), new BigDecimal(8), new BigDecimal(9)};
    BigDecimal[] result = matrix.operate(vector);

    // Expected result of the matrix-vector multiplication:
    // [1*7 + 2*8 + 3*9, 4*7 + 5*8 + 6*9] = [50, 122]
    BigDecimal[] expected = {new BigDecimal(50), new BigDecimal(122)};

    // Assert that the result matches the expected values
    assertArrayEquals(expected, result);
}

@Test
public void test_193_41() throws Exception {
    BigDecimal[][] data = {
        {BigDecimal.ZERO, BigDecimal.ZERO},
        {BigDecimal.ZERO, BigDecimal.ZERO}
    };
    BigMatrixImpl matrix = new BigMatrixImpl(data);
    BigDecimal[] vector = {new BigDecimal(1), new BigDecimal(2)};
    BigDecimal[] result = matrix.operate(vector);
    
    // The expected result of multiplying a zero matrix by any vector is a zero vector.
    BigDecimal[] expected = {BigDecimal.ZERO, BigDecimal.ZERO};
    
    assertArrayEquals(expected, result);
}

}
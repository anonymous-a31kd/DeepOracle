package org.apache.commons.math.linear;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.linear.RealMatrixImpl;
import java.io.Serializable;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class RealMatrixImpl_LLMTest extends RealMatrixImpl_LLMTest_scaffolding {
    
@Test
public void test_194_01() throws Exception {
    double[][] matrixData = {{1, 2}, {3, 4}};
    RealMatrixImpl matrix = new RealMatrixImpl(matrixData);
    double[] vector = {5, 6};
    double[] result = matrix.operate(vector);

    // Expected result is the matrix-vector product: [1*5 + 2*6, 3*5 + 4*6] = [17, 39]
    assertArrayEquals(new double[]{17, 39}, result, 1e-10);
}

@Test
public void test_194_11() throws Exception {
    double[][] matrixData = {{1, 2, 3}, {4, 5, 6}};
    RealMatrixImpl matrix = new RealMatrixImpl(matrixData);
    double[] vector = {7, 8, 9};
    double[] result = matrix.operate(vector);

    // Asserting that the operation is successful and the result is as expected
    // Expected result: {1*7 + 2*8 + 3*9, 4*7 + 5*8 + 6*9} = {50, 122}
    assertArrayEquals(new double[]{50, 122}, result, 1e-10);
}

}
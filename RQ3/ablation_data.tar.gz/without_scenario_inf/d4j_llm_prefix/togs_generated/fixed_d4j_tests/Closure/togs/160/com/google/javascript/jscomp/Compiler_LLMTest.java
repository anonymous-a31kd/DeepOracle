package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.CompilerOptions.DevMode;
import com.google.common.collect.Maps;
import com.google.javascript.jscomp.DiagnosticGroupWarningsGuard;
import java.util.logging.Level;
import com.google.javascript.jscomp.CheckLevel;
import java.nio.charset.Charset;
import com.google.common.base.Preconditions;
import com.google.javascript.jscomp.CompilerOptions.TracerMode;
import com.google.javascript.jscomp.ReferenceCollectingCallback.ReferenceCollection;
import java.util.Map;
import java.util.List;
import java.util.Set;
import com.google.javascript.jscomp.deps.SortedDependencies.MissingProvideException;
import com.google.javascript.jscomp.parsing.Config;
import com.google.javascript.jscomp.deps.SortedDependencies.CircularDependencyException;
import com.google.javascript.jscomp.WarningsGuard;
import com.google.common.annotations.VisibleForTesting;
import com.google.javascript.jscomp.Scope.Var;
import java.util.concurrent.Callable;
import java.util.logging.Logger;
import com.google.common.base.Supplier;
import com.google.javascript.jscomp.mozilla.rhino.ErrorReporter;
import java.util.HashMap;
import com.google.javascript.jscomp.parsing.ParserRunner;
import com.google.javascript.jscomp.ReferenceCollectingCallback.ReferenceMap;
import com.google.common.collect.Lists;
import com.google.javascript.rhino.JSDocInfo;
import java.io.Serializable;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.Node;
import java.io.PrintStream;
import com.google.javascript.jscomp.DiagnosticGroups;
import com.google.javascript.jscomp.CompilerOptions.LanguageMode;
import java.util.Collections;
import com.google.javascript.jscomp.CompilerOptions;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Compiler_LLMTest extends Compiler_LLMTest_scaffolding {
    
@Test
public void test_103_01() throws Exception {
    Compiler compiler = new Compiler();
    CompilerOptions options = new CompilerOptions();
    options.checkSymbols = false;
    options.setWarningLevel(DiagnosticGroups.CHECK_VARIABLES, CheckLevel.WARNING);
    compiler.initOptions(options);
    assertEquals(options, compiler.getOptions());
}

@Test
public void test_103_11() throws Exception {
    Compiler compiler = new Compiler();
    CompilerOptions options = new CompilerOptions();
    options.checkSymbols = false;
    options.setWarningLevel(DiagnosticGroups.CHECK_VARIABLES, CheckLevel.OFF);
    compiler.initOptions(options);
    
    // Assert that the compiler's options are set to the options passed in
    assertEquals(options, compiler.getOptions());
}

}
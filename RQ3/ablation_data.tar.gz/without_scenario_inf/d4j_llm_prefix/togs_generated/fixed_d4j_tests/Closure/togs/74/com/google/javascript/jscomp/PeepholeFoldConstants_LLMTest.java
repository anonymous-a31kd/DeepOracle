package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.collect.Lists;
import com.google.javascript.jscomp.mozilla.rhino.ScriptRuntime;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.javascript.rhino.Node;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Token;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PeepholeFoldConstants_LLMTest extends PeepholeFoldConstants_LLMTest_scaffolding {
    
@Test
public void test_96_11() throws Exception {
    Node nullNode = new Node(Token.NULL);
    Node right = new Node(Token.NULL);
    Node comparison = new Node(Token.SHEQ, nullNode, right);

}

}
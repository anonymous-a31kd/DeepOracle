package com.google.javascript.rhino;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.jstype.SimpleSourceFile;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.jstype.StaticSourceFile;
import java.util.Collections;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.Node;
import java.util.Arrays;
import com.google.common.base.Objects;
import com.google.common.annotations.VisibleForTesting;
import java.util.Iterator;
import java.util.Set;
import java.util.NoSuchElementException;
import java.io.Serializable;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Node_LLMTest extends Node_LLMTest_scaffolding {
    
@Test
public void test_142_11() throws Exception {
    Node parent = new Node(1);
    Node child = new Node(2);
    parent.addChildToFront(child);
    Node result = parent.getChildBefore(child);

    // Since 'child' is the only child, there is no child before it.
    assertNull(result);
}

@Test
public void test_142_21() throws Exception {
    Node parent = new Node(1);
    Node child1 = new Node(2);
    Node child2 = new Node(3);
    parent.addChildToFront(child1);
    parent.addChildToBack(child2);
    Node result = parent.getChildBefore(child2);

    assertEquals(child1, result);
}

}
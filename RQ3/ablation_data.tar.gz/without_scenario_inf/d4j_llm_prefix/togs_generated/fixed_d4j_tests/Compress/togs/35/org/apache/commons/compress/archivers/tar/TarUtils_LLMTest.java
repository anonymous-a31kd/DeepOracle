package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUM_OFFSET;
import java.math.BigInteger;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUMLEN;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_27_01() throws Exception {
    byte[] header = new byte[512];

    String checksum = "000123";
    System.arraycopy(checksum.getBytes(), 0, header, 148, checksum.length());

    boolean result = TarUtils.verifyCheckSum(header);

    // Assuming the test is designed to verify that the checksum "000123" is valid
    assertTrue(result);
}

@Test
public void test_27_11() throws Exception {
    byte[] header = new byte[512];

    for (int i = CHKSUM_OFFSET; i < CHKSUM_OFFSET + CHKSUMLEN; i++) {
        header[i] = ' ';
    }
    boolean result = TarUtils.verifyCheckSum(header);
    assertTrue("Checksum should be valid for header with spaces in checksum area", result);
}

@Test
public void test_27_31() throws Exception {
    byte[] header = new byte[100];
    boolean result = TarUtils.verifyCheckSum(header);
    assertFalse(result);
}

@Test
public void test_27_51() throws Exception {
    byte[] header = new byte[512];

    String checksum = "000000";
    System.arraycopy(checksum.getBytes(), 0, header, CHKSUM_OFFSET, checksum.length());
    TarUtils.verifyCheckSum(header);
}

}
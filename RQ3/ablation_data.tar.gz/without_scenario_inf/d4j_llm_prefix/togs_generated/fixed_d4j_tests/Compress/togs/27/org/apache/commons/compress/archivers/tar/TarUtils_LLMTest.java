package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUMLEN;
import java.nio.ByteBuffer;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import static org.apache.commons.compress.archivers.tar.TarConstants.CHKSUM_OFFSET;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import java.math.BigInteger;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_40_11() throws Exception {
    byte[] buffer = {0, 0, 0, 0};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(0L, result);
}

@Test
public void test_40_21() throws Exception {
    byte[] buffer = {' ', 0, ' ', 0};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(0L, result);
}

@Test
public void test_40_61() throws Exception {
    byte[] buffer = {' ', 0};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(0L, result);
}

}
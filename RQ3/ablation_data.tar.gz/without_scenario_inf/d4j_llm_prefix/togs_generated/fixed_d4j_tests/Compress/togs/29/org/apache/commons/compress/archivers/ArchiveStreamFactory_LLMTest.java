package org.apache.commons.compress.archivers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
import java.io.InputStream;
import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
import static org.junit.Assert.assertTrue;
import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArchiveStreamFactory_LLMTest extends ArchiveStreamFactory_LLMTest_scaffolding {
    
@Test
public void test_42_01() throws Exception {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    ArchiveOutputStream archiveOutputStream = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
    
    assertNotNull("The archive output stream should not be null", archiveOutputStream);
}

@Test
public void test_42_11() throws Exception {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.setEntryEncoding("UTF-8");
    ArchiveOutputStream archiveOut = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
    assertNotNull("The archive output stream should not be null", archiveOut);
}

@Test
public void test_42_21() throws Exception {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory();
    factory.setEntryEncoding("");
    ArchiveOutputStream archiveOutputStream = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
    assertNotNull("The ArchiveOutputStream should not be null", archiveOutputStream);
}

@Test
public void test_42_31() throws Exception {
    OutputStream out = new ByteArrayOutputStream();
    ArchiveStreamFactory factory = new ArchiveStreamFactory("UTF-8");
    ArchiveOutputStream archiveOutputStream = factory.createArchiveOutputStream(ArchiveStreamFactory.JAR, out);
    assertNotNull("The created ArchiveOutputStream should not be null", archiveOutputStream);
}

}
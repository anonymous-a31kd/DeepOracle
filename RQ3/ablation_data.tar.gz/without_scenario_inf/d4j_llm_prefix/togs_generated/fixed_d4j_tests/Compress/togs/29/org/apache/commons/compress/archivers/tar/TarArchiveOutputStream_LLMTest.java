package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Date;
import java.io.OutputStream;
import java.util.Map;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.io.StringWriter;
import org.apache.commons.compress.utils.CountingOutputStream;
import java.nio.ByteBuffer;
import java.io.File;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.utils.CharsetNames;
import java.util.HashMap;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveOutputStream_LLMTest extends TarArchiveOutputStream_LLMTest_scaffolding {
    
@Test
public void test_45_01() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os, 512, 512, null);
    
    assertEquals(512, tarOut.getRecordSize());
}

@Test
public void test_45_21() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os, 512, 512, CharsetNames.UTF_8);
    
    // Assert that the record size is set correctly
    assertEquals(512, tarOut.getRecordSize());
}

@Test
public void test_45_31() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    TarArchiveOutputStream tarOutput = new TarArchiveOutputStream(os, 512, 512, CharsetNames.US_ASCII);
    
    // Validate that the TarArchiveOutputStream is correctly initialized
    assertEquals(512, tarOutput.getRecordSize());
}

@Test
public void test_45_41() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(os, 512, 512, CharsetNames.ISO_8859_1);
    
    // Validate whether the TarArchiveOutputStream instance has been initialized correctly
    assertEquals(512, tarOut.getRecordSize());
}

@Test
public void test_45_51() throws Exception {
    OutputStream os = new ByteArrayOutputStream();
    TarArchiveOutputStream tarOutputStream = new TarArchiveOutputStream(os, 1024, 512, CharsetNames.UTF_8);
    
    // Assert that the TarArchiveOutputStream has been initialized with the correct record size
    assertEquals(512, tarOutputStream.getRecordSize());
}

}
package com.fasterxml.jackson.databind.type;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.databind.type.SimpleType;
import com.fasterxml.jackson.databind.JavaType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class SimpleType_LLMTest extends SimpleType_LLMTest_scaffolding {
    
@Test
public void test_72_01() throws Exception {
    SimpleType type = SimpleType.construct(String.class);
    assertEquals("java.lang.String", type.toString());
}

@Test
public void test_72_41() throws Exception {
    SimpleType type = SimpleType.construct(Object.class);
    assertNotNull("The SimpleType instance should not be null", type);
}

@Test
public void test_72_51() throws Exception {
    SimpleType type = SimpleType.construct(Integer.class);
    assertEquals("Expected constructed SimpleType to be of class Integer", Integer.class, type.getRawClass());
}

@Test
public void test_72_61() throws Exception {
    SimpleType type = SimpleType.construct(Comparable.class);
    assertNotNull(type);
}

}
package org.jsoup.parser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.jsoup.parser.CharacterReader;
import org.jsoup.nodes.Entities;
import org.jsoup.parser.Token;
import org.jsoup.parser.Tokeniser;
import org.jsoup.parser.TokeniserState;
import java.util.Arrays;
import org.jsoup.helper.Validate;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Tokeniser_LLMTest extends Tokeniser_LLMTest_scaffolding {
    
@Test
public void test_19_41() throws Exception {
    CharacterReader reader = new CharacterReader("<div>");
    Tokeniser tokeniser = new Tokeniser(reader, null);
    Token token = tokeniser.read();
    
    // Assert that the token is of type StartTag and has the expected name
    assertTrue(token instanceof Token.StartTag);
    assertEquals("div", ((Token.StartTag) token).tagName);
}

@Test
public void test_20_01() throws Exception {
    Tokeniser tokeniser = new Tokeniser(null, null);
    Token.StartTag startTag = new Token.StartTag();
    startTag.tagName = "br";
    startTag.selfClosing = true;
    tokeniser.emit(startTag);
    
    // Verify that the emitted token is stored correctly
    assertEquals("br", tokeniser.startPending.tagName);
    assertTrue(tokeniser.startPending.selfClosing);
}

@Test
public void test_20_11() throws Exception {
    Tokeniser tokeniser = new Tokeniser(null, null);
    Token.StartTag startTag = new Token.StartTag();
    startTag.tagName = "div";
    startTag.selfClosing = false;
    tokeniser.emit(startTag);

}

@Test
public void test_20_31() throws Exception {
    Tokeniser tokeniser = new Tokeniser(null, null);
    Token.EndTag endTag = new Token.EndTag();
    endTag.attributes = null;
    tokeniser.emit(endTag);
    
    // Assuming that emitting the endTag should set the endPending field in Tokeniser
    assertEquals(endTag, tokeniser.endPending);
}

@Test
public void test_20_41() throws Exception {
    Tokeniser tokeniser = new Tokeniser(null, null);
    Token.Character charToken = new Token.Character();
    tokeniser.emit(charToken);
    
    // Verify that the emitted token is the same as the charToken
    assertEquals(charToken, tokeniser.charPending);
}

}
package org.jsoup.nodes;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.jsoup.nodes.FormElement;
import org.jsoup.select.Elements;
import org.jsoup.helper.HttpConnection;
import org.jsoup.nodes.Element;
import org.jsoup.helper.Validate;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Attributes;
import org.jsoup.Connection;
import org.jsoup.parser.Tag;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FormElement_LLMTest extends FormElement_LLMTest_scaffolding {
    
@Test
public void test_75_11() throws Exception {
    FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
    Element button = new Element(Tag.valueOf("input"), "")
    .attr("type", "BUTTON")
    .attr("name", "buttonName");
    form.addElement(button);
    List<Connection.KeyVal> data = form.formData();
}

@Test
public void test_75_21() throws Exception {
    FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
    Element textInput = new Element(Tag.valueOf("input"), "")
    .attr("type", "text")
    .attr("name", "textName")
    .attr("value", "textValue");
    form.addElement(textInput);
    List<Connection.KeyVal> data = form.formData();

    assertEquals(1, data.size());
    assertEquals("textName", data.get(0).key());
    assertEquals("textValue", data.get(0).value());
}

@Test
public void test_75_41() throws Exception {
    FormElement form = new FormElement(Tag.valueOf("form"), "", new Attributes());
    Element button = new Element(Tag.valueOf("input"), "")
    .attr("type", "button")
    .attr("name", "buttonName");
    Element textInput = new Element(Tag.valueOf("input"), "")
    .attr("type", "text")
    .attr("name", "textName")
    .attr("value", "textValue");
    form.addElement(button);
    form.addElement(textInput);
    List<Connection.KeyVal> data = form.formData();

    assertEquals(1, data.size());
    assertEquals("textName", data.get(0).key());
    assertEquals("textValue", data.get(0).value());
}

}
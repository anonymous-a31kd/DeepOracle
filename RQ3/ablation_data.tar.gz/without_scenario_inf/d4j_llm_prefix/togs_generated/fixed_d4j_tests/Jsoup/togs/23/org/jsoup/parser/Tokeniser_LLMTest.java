package org.jsoup.parser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.jsoup.parser.Tokeniser;
import org.jsoup.parser.CharacterReader;
import java.util.List;
import java.util.ArrayList;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Entities;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Tokeniser_LLMTest extends Tokeniser_LLMTest_scaffolding {
    
@Test
public void test_212_01() throws Exception {
    CharacterReader reader = new CharacterReader("amp;");
    Tokeniser tokeniser = new Tokeniser(reader, null);
    Character result = tokeniser.consumeCharacterReference(null, false);

    // Verify that the result is the replacement character because "amp;" is not a valid character reference
    assertEquals(Tokeniser.replacementChar, result.charValue());
}

@Test
public void test_212_11() throws Exception {
    CharacterReader reader = new CharacterReader("frac12;");
    Tokeniser tokeniser = new Tokeniser(reader, null);
    Character result = tokeniser.consumeCharacterReference(null, false);

    // Assert that the consumeCharacterReference method returns the correct replacement character.
    assertEquals(Character.valueOf('\uFFFD'), result);
}

}
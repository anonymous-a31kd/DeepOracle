package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.BinaryDecoder;
import java.math.BigInteger;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Base64_LLMTest extends Base64_LLMTest_scaffolding {
    
@Test
public void test_10_01() throws Exception {
    byte[] input = "Test input for chunked encoding".getBytes();
    Base64.encodeBase64(input, true, false, Integer.MAX_VALUE);
}

@Test
public void test_10_21() throws Exception {
    byte[] input = "Test input for url-safe chunked encoding".getBytes();
    Base64.encodeBase64(input, true, true, Integer.MAX_VALUE);
}

@Test
public void test_10_31() throws Exception {
    byte[] input = "Test input for url-safe non-chunked encoding".getBytes();
    byte[] encoded = Base64.encodeBase64(input, false, true, Integer.MAX_VALUE);
    
    // Verify that the encoded data is base64 and url-safe, i.e., contains '-' and '_' instead of '+' and '/'
    String encodedString = new String(encoded);
    assertTrue("Encoded string should be URL safe", !encodedString.contains("+") && !encodedString.contains("/"));
}

@Test
public void test_10_61() throws Exception {
    byte[] input = new byte[0];
    byte[] result = Base64.encodeBase64(input, true, false, Integer.MAX_VALUE);
    assertArrayEquals("The encoded result of an empty byte array should also be an empty byte array.", new byte[0], result);
}

@Test
public void test_10_71() throws Exception {
    byte[] input = null;
    byte[] result = Base64.encodeBase64(input, true, false, Integer.MAX_VALUE);
    assertNull(result); // Assuming the method returns null for null input
}

}
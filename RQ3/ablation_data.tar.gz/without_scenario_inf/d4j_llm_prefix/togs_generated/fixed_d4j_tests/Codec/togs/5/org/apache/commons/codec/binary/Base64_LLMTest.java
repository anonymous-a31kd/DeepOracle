package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.BinaryDecoder;
import java.math.BigInteger;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Base64_LLMTest extends Base64_LLMTest_scaffolding {
    
@Test
public void test_5_01()  throws Exception {
    Base64 base64 = new Base64();
    byte[] input = new byte[] {'A', 'Q', '='};
    base64.decode(input, 0, input.length);
}

@Test
public void test_5_11()  throws Exception {
    Base64 base64 = new Base64();
    byte[] input = new byte[] {'A', 'Q', 'I', 'D', '='};
    byte[] smallBuffer = new byte[1];
    base64.setInitialBuffer(smallBuffer, 0, smallBuffer.length);
    base64.decode(input, 0, input.length);
}

@Test
public void test_5_21()  throws Exception {
    Base64 base64 = new Base64();
    byte[] input = new byte[] {'A', 'Q', '='};
    byte[] exactBuffer = new byte[1];
    base64.setInitialBuffer(exactBuffer, 0, exactBuffer.length);
    base64.decode(input, 0, input.length);
}

}
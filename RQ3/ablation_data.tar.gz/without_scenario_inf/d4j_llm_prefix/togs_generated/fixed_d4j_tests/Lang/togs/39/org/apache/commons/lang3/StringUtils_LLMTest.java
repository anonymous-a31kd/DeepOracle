package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_185_01() throws Exception {
    String text = "abc def ghi";
    String[] searchList = new String[] {null, "def"};
    String[] replacementList = new String[] {"xyz", "123"};
    String result = StringUtils.replaceEach(text, searchList, replacementList);
    assertEquals("abc 123 ghi", result);
}

@Test
public void test_185_11() throws Exception {
    String text = "abc def ghi";
    String[] searchList = new String[] {"abc", "def"};
    String[] replacementList = new String[] {"xyz", null};
    String result = StringUtils.replaceEach(text, searchList, replacementList);
    assertEquals("xyz def ghi", result);
}

@Test
public void test_185_21() throws Exception {
    String text = "abc def ghi";
    String[] searchList = new String[] {null, "def"};
    String[] replacementList = new String[] {"xyz", null};
    String result = StringUtils.replaceEach(text, searchList, replacementList);
    assertEquals("abc def ghi", result);
}

@Test
public void test_185_31() throws Exception {
    String text = "abc def ghi def";
    String[] searchList = new String[] {null, "def"};
    String[] replacementList = new String[] {"xyz", null};
    String result = StringUtils.replaceEachRepeatedly(text, searchList, replacementList);
    assertEquals("abc def ghi def", result);
}

}
package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import org.apache.commons.lang3.math.Fraction;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Fraction_LLMTest extends Fraction_LLMTest_scaffolding {
    
@Test
public void test_170_41() throws Exception {
    Fraction.getReducedFraction(123456, 7890);
    Fraction.getReducedFraction(7890, 123456);
    Fraction.getReducedFraction(-123456, 7890);
    Fraction.getReducedFraction(7890, -123456);
}

@Test
public void test_170_51() throws Exception {
    Fraction fraction1 = Fraction.getReducedFraction(42, 42);
    Fraction fraction2 = Fraction.getReducedFraction(-42, -42);
    Fraction fraction3 = Fraction.getReducedFraction(42, -42);
    
    assertEquals(Fraction.ONE, fraction1);
    assertEquals(Fraction.ONE, fraction2);
    assertEquals(Fraction.ONE.negate(), fraction3);
}

}
package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.sql.ResultSet;
import org.apache.commons.csv.CSVPrinter;
import java.io.Flushable;
import static org.apache.commons.csv.Constants.SP;
import static org.apache.commons.csv.Constants.LF;
import static org.apache.commons.csv.Constants.CR;
import java.io.StringWriter;
import java.sql.SQLException;
import org.apache.commons.csv.CSVFormat;
import static org.apache.commons.csv.Constants.COMMENT;
import java.io.Closeable;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVPrinter_LLMTest extends CSVPrinter_LLMTest_scaffolding {
    
@Test
public void test_40_01() throws Exception {
    StringWriter writer = new StringWriter();
    CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator(null);
    CSVPrinter printer = new CSVPrinter(writer, format);
    printer.println();
    assertEquals("", writer.toString());
}

@Test
public void test_40_11() throws Exception {
    StringWriter writer = new StringWriter();
    CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("");
    CSVPrinter printer = new CSVPrinter(writer, format);
    printer.println();
    
    assertEquals("", writer.toString());
}

@Test
public void test_40_21() throws Exception {
    StringWriter writer = new StringWriter();
    CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\r\n");
    CSVPrinter printer = new CSVPrinter(writer, format);
    printer.println();
    
    assertEquals("\r\n", writer.toString());
}

@Test
public void test_40_31() throws Exception {
    StringWriter writer = new StringWriter();
    CSVFormat format = CSVFormat.DEFAULT.withRecordSeparator("\n");
    CSVPrinter printer = new CSVPrinter(writer, format);
    printer.println();
    
    // Assert that the writer contains only the record separator
    assertEquals("\n", writer.toString());
}

}
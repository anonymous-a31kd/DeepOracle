package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Closeable;
import java.net.URL;
import java.util.LinkedHashMap;
import java.io.InputStream;
import java.io.StringReader;
import java.util.List;
import java.util.Arrays;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Map;
import java.io.FileInputStream;
import org.apache.commons.csv.CSVFormat;
import java.util.Iterator;
import org.apache.commons.csv.CSVRecord;
import java.io.File;
import java.util.NoSuchElementException;
import java.nio.file.Files;
import org.apache.commons.csv.CSVParser;
import java.util.TreeMap;
import java.io.InputStreamReader;
import static org.apache.commons.csv.Token.Type.TOKEN;
import java.util.ArrayList;
import java.nio.file.Path;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVParser_LLMTest extends CSVParser_LLMTest_scaffolding {
    
@Test
public void test_46_01()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader(""), CSVFormat.DEFAULT);
    parser.close();
    Iterator<CSVRecord> iterator = parser.iterator();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_46_21() throws Exception {
    CSVParser parser = CSVParser.parse(new StringReader(""), CSVFormat.DEFAULT);
    Iterator<CSVRecord> iterator = parser.iterator();
    
    // Since the input is an empty string, there should be no records.
    assertFalse("Iterator should not have any records", iterator.hasNext());
}

@Test
public void test_46_41()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader("a,b,c"), CSVFormat.DEFAULT);
    Iterator<CSVRecord> iterator = parser.iterator();

    iterator.next();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_46_51()  throws Exception {
	try {
    CSVParser parser = CSVParser.parse(new StringReader("a,b,c\n1,2,3"), CSVFormat.DEFAULT);
    Iterator<CSVRecord> iterator = parser.iterator();

    iterator.next();

    iterator.next();



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_47_01() throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 0L, 1L);

    Iterator<CSVRecord> iterator = parser.iterator();
    
    assertTrue(iterator.hasNext());
    CSVRecord record = iterator.next();
    assertEquals("1", record.get(0));
    assertEquals("2", record.get(1));
    assertEquals("3", record.get(2));
    
    parser.close();
}

@Test
public void test_47_11() throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 10L, 5L);

    Iterator<CSVRecord> iterator = parser.iterator();
    assertTrue(iterator.hasNext());
}

@Test
public void test_47_21() throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 0L, 1L);

    Iterator<CSVRecord> iterator1 = parser.iterator();
    Iterator<CSVRecord> iterator2 = parser.iterator();

    // Assert that calling iterator() multiple times returns the same iterator instance
    assertSame(iterator1, iterator2);
}

@Test
public void test_47_31()  throws Exception {
    StringReader reader = new StringReader("a,b,c\n1,2,3");
    CSVFormat format = CSVFormat.DEFAULT;
    CSVParser parser = new CSVParser(reader, format, 0L, 1L);
    parser.close();

    parser.iterator();
}

}
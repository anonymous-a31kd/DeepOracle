package org.apache.commons.csv;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Set;
import java.io.Reader;
import static org.apache.commons.csv.Constants.CRLF;
import java.util.HashSet;
import static org.apache.commons.csv.Constants.DOUBLE_QUOTE_CHAR;
import static org.apache.commons.csv.Constants.LF;
import java.util.Arrays;
import static org.apache.commons.csv.Constants.CR;
import static org.apache.commons.csv.Constants.COMMA;
import static org.apache.commons.csv.Constants.BACKSLASH;
import java.io.StringWriter;
import java.io.Serializable;
import static org.apache.commons.csv.Constants.TAB;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CSVFormat_LLMTest extends CSVFormat_LLMTest_scaffolding {
    
@Test
public void test_57_01() throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader((String[]) null);
    format.validate();
    // No exception should be thrown, so no assert is necessary
}

@Test
public void test_57_11() throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader(new String[0]);
    format.validate();
}

@Test
public void test_57_21() throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("name");
    format.validate();
    assertArrayEquals(new String[]{"name"}, format.getHeader());
}

@Test
public void test_57_31() throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("name", "age", "city");
    format.validate();
    assertArrayEquals(new String[]{"name", "age", "city"}, format.getHeader());
}

@Test
public void test_57_61() throws Exception {
    CSVFormat format = CSVFormat.DEFAULT.withHeader("Name", "name", "NAME");
    format.validate();
}

}
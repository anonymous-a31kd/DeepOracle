package org.mockito.internal.stubbing.defaultanswers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashSet;
import org.mockito.invocation.InvocationOnMock;
import java.io.Serializable;
import org.mockito.internal.util.Primitives;
import static org.mockito.Mockito.mock;
import java.util.Set;
import org.mockito.internal.util.MockUtil;
import org.mockito.stubbing.Answer;
import java.util.LinkedHashMap;
import java.util.SortedSet;
import java.util.TreeMap;
import org.mockito.internal.util.ObjectMethodsGuru;
import java.util.LinkedHashSet;
import org.mockito.mock.MockName;
import java.util.Collection;
import org.mockito.internal.stubbing.defaultanswers.ReturnsEmptyValues;
import static org.mockito.Mockito.when;
import java.util.TreeSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ReturnsEmptyValues_LLMTest extends ReturnsEmptyValues_LLMTest_scaffolding {
    
@Test
public void test_165_01() throws Exception {
    ReturnsEmptyValues answer = new ReturnsEmptyValues();
    InvocationOnMock invocation = mock(InvocationOnMock.class);
    Object mockObj = new Object();

    when(invocation.getMethod()).thenReturn(Comparable.class.getMethod("compareTo", Object.class));
    when(invocation.getMock()).thenReturn(mockObj);
    when(invocation.getArguments()).thenReturn(new Object[]{mockObj});

    int result = (Integer) answer.answer(invocation);

    assertEquals(0, result);
}

@Test
public void test_165_11() throws Exception {
    ReturnsEmptyValues answer = new ReturnsEmptyValues();
    InvocationOnMock invocation = mock(InvocationOnMock.class);
    Object mockObj1 = new Object();
    Object mockObj2 = new Object();

    when(invocation.getMethod()).thenReturn(Comparable.class.getMethod("compareTo", Object.class));
    when(invocation.getMock()).thenReturn(mockObj1);
    when(invocation.getArguments()).thenReturn(new Object[]{mockObj2});

    int result = (Integer) answer.answer(invocation);

    assertEquals(0, result);
}

@Test
public void test_165_21() throws Exception {
    ReturnsEmptyValues answer = new ReturnsEmptyValues();
    InvocationOnMock invocation = mock(InvocationOnMock.class);

    when(invocation.getMethod()).thenReturn(Object.class.getMethod("hashCode"));

    Object result = answer.answer(invocation);

    assertEquals(0, result);
}

}
package org.mockito.internal.stubbing.defaultanswers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static org.mockito.Mockito.*;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.internal.MockitoCore;
import java.io.Serializable;
import org.mockito.MockSettings;
import org.mockito.internal.stubbing.InvocationContainerImpl;
import org.mockito.internal.stubbing.StubbedInvocationMatcher;
import org.mockito.internal.InternalMockHandler;
import org.mockito.internal.util.MockUtil;
import org.mockito.internal.util.reflection.GenericMetadataSupport;
import org.mockito.stubbing.Answer;
import org.mockito.internal.creation.settings.CreationSettings;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ReturnsDeepStubs_LLMTest extends ReturnsDeepStubs_LLMTest_scaffolding {
    
@Test
public void test_164_11() throws Exception {
    ReturnsDeepStubs answer = new ReturnsDeepStubs();
    Object mock = mock(Object.class);
    GenericMetadataSupport result = answer.actualParameterizedType(mock);
    
    assertNotNull("The actualParameterizedType method should not return null", result);
}

@Test
public void test_164_21() throws Exception {
    ReturnsDeepStubs answer = new ReturnsDeepStubs();
    MockSettings settings = withSettings().extraInterfaces(Serializable.class);
    Object mock = mock(Object.class, settings);
    GenericMetadataSupport result = answer.actualParameterizedType(mock);
    
    assertNotNull("Result should not be null", result);
}

}
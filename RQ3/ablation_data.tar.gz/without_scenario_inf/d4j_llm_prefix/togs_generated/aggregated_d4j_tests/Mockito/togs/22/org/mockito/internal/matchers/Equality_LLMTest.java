package org.mockito.internal.matchers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Equality_LLMTest extends Equality_LLMTest_scaffolding {
    
@Test
public void test_161_01() throws Exception {
    Object obj = new Object();
    boolean result = Equality.areEqual(obj, obj);
    assertTrue(result);
}

@Test
public void test_161_11() throws Exception {
    assertTrue(Equality.areEqual(null, null));
}

@Test
public void test_161_21() throws Exception {
    // Since the method areEqual is expected to compare two objects for equality,
    // and one of the objects is null, the expected result should be false.
    boolean result = Equality.areEqual(null, new Object());
    assertFalse(result);
}

@Test
public void test_161_31() throws Exception {
    boolean result = Equality.areEqual(new Object(), null);
    assertFalse(result);
}

@Test
public void test_161_41() throws Exception {
    String s1 = new String("test");
    String s2 = new String("test");
    assertTrue(Equality.areEqual(s1, s2));
}

@Test
public void test_161_51() throws Exception {
    String s1 = "test1";
    String s2 = "test2";
    boolean result = Equality.areEqual(s1, s2);
    assertFalse("Expected strings to be unequal", result);
}

@Test
public void test_161_61() throws Exception {
    int[] arr1 = {1, 2, 3};
    int[] arr2 = {1, 2, 3};
    boolean result = Equality.areEqual(arr1, arr2);
    assertTrue("The arrays should be equal", result);
}

@Test
public void test_161_71() throws Exception {
    int[] arr1 = {1, 2, 3};
    int[] arr2 = {1, 2, 4};
    boolean result = Equality.areEqual(arr1, arr2);
    assertFalse(result);
}

}
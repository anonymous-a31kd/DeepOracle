package org.mockito.internal.util.reflection;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Type;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GenericMaster_LLMTest extends GenericMaster_LLMTest_scaffolding {
    
@Test
public void test_141_21() throws Exception {
    class TestClass {
        public String nonGenericField;
    }
    Field field = TestClass.class.getDeclaredField("nonGenericField");
    GenericMaster master = new GenericMaster();
    Class<?> result = master.getGenericType(field);
    assertEquals(Object.class, result);
}

}
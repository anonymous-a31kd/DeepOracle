package org.mockito.internal.matchers;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.hamcrest.Description;
import static org.mockito.Mockito.mock;
import org.mockito.ArgumentMatcher;
import org.mockito.internal.matchers.Same;
import java.io.Serializable;
import static org.mockito.Mockito.verify;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Same_LLMTest extends Same_LLMTest_scaffolding {
    
@Test
public void test_170_01() throws Exception {
    Description description = mock(Description.class);
    Object wanted = "testObject";
    Same matcher = new Same(wanted);

    matcher.describeTo(description);
    verify(description).appendText("same(");
    verify(description).appendText("testObject");
    verify(description).appendText(")");
}

@Test
public void test_170_11() throws Exception {
    Description description = mock(Description.class);
    Object wanted = null;
    Same matcher = new Same(wanted);

    matcher.describeTo(description);
    verify(description).appendText("same(");
    verify(description).appendText("null");
    verify(description).appendText(")");
}

@Test
public void test_170_21() throws Exception {
    Description description = mock(Description.class);
    Object wanted = "";
    Same matcher = new Same(wanted);

    matcher.describeTo(description);
    verify(description).appendText("same(");
    verify(description).appendText("");
    verify(description).appendText(")");

    // Assert that the description is correctly appended with the expected format
    verify(description).appendText(")");
}

}
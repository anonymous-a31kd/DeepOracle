package com.fasterxml.jackson.core.json;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.io.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.io.*;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonGenerator.Feature;
import java.math.BigDecimal;
import com.fasterxml.jackson.core.JsonFactory;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UTF8JsonGenerator_LLMTest extends UTF8JsonGenerator_LLMTest_scaffolding {
    
@Test
public void test_71_01() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber((BigDecimal) null);
    generator.close();
    
    // Verify that the output is "null" since writing a null BigDecimal should result in a null value in JSON
    assertEquals("null", out.toString("UTF-8"));
}

@Test
public void test_71_21() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.enable(Feature.WRITE_BIGDECIMAL_AS_PLAIN);
    generator.writeNumber(new BigDecimal("789.012"));
    generator.close();

    // Assert that the output is the plain string representation of the BigDecimal
    String expectedOutput = "789.012";
    String actualOutput = out.toString("UTF-8");
    assertEquals(expectedOutput, actualOutput);
}

@Test
public void test_71_31() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber(new BigDecimal("345.678"));
    generator.close();
    
    // Verify the output
    String expectedJson = "345.678";
    assertEquals(expectedJson, out.toString("UTF-8"));
}

@Test
public void test_71_41() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber(new BigDecimal("1.23456E+10"));
    generator.close();

    // Assert that the output is as expected
    String expectedOutput = "1.23456E+10";
    assertEquals(expectedOutput, out.toString("UTF-8").trim());
}

@Test
public void test_71_51() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    JsonGenerator generator = factory.createGenerator(out);
    generator.writeNumber(new BigDecimal("12345678901234567890.12345678901234567890"));
    generator.close();
    
    // Assert that the output is as expected after writing the BigDecimal
    String expectedJson = "12345678901234567890.12345678901234567890";
    String actualJson = out.toString("UTF-8");
    assertEquals(expectedJson, actualJson);
}

}
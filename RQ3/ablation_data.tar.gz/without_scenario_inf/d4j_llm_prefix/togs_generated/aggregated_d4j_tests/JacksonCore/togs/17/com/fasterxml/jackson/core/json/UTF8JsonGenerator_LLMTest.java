package com.fasterxml.jackson.core.json;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.io.*;
import java.math.BigInteger;
import java.io.*;
import com.fasterxml.jackson.core.*;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UTF8JsonGenerator_LLMTest extends UTF8JsonGenerator_LLMTest_scaffolding {
    
@Test
public void test_87_01() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    UTF8JsonGenerator gen = (UTF8JsonGenerator) factory.createGenerator(out);
    String shortText = "short";
    gen.writeRaw(shortText, 0, shortText.length());
    gen.flush();
    
    // Verify the output stream content
    assertEquals("short", out.toString("UTF-8"));
}

@Test
public void test_87_11() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    UTF8JsonGenerator gen = (UTF8JsonGenerator) factory.createGenerator(out);
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 1000; i++) {
        sb.append("a");
    }
    String longText = sb.toString();
    gen.writeRaw(longText, 0, longText.length());
    gen.flush();
    String output = out.toString("UTF-8");
    assertEquals(longText, output);
}

@Test
public void test_87_31() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    UTF8JsonGenerator gen = (UTF8JsonGenerator) factory.createGenerator(out);
    String fullText = "This is a complete string";
    int offset = 5;
    int len = 10;
    gen.writeRaw(fullText, offset, len);
    gen.flush();  // Ensure all data is written to the output stream

    String expectedOutput = fullText.substring(offset, offset + len);
    String actualOutput = out.toString("UTF-8");
    assertEquals(expectedOutput, actualOutput);
}

@Test
public void test_87_41() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    UTF8JsonGenerator gen = (UTF8JsonGenerator) factory.createGenerator(out);
    gen.writeRaw("", 0, 0);
    gen.flush();
    assertEquals("", out.toString("UTF-8"));
}

@Test
public void test_87_51() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    JsonFactory factory = new JsonFactory();
    UTF8JsonGenerator gen = (UTF8JsonGenerator) factory.createGenerator(out);
    gen.writeRaw("a", 0, 1);
    gen.flush();
    String result = out.toString("UTF-8");
    assertEquals("a", result);
}

}
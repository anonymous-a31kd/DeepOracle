package com.fasterxml.jackson.core.util;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.*;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class JsonParserSequence_LLMTest extends JsonParserSequence_LLMTest_scaffolding {
    
@Test
public void test_69_01() throws Exception {
    JsonParser parserWithToken = new JsonFactory().createParser("{\"key\":\"value\"}");
    parserWithToken.nextToken();
    JsonParser[] parsers = new JsonParser[]{parserWithToken};
    JsonParserSequence sequence = new JsonParserSequence(parsers);
    
    // Assert that the sequence contains exactly one parser
    assertEquals(1, sequence.containedParsersCount());
}

@Test
public void test_69_11() throws Exception {
    JsonParser parserWithoutToken = new JsonFactory().createParser("{}");
    JsonParser[] parsers = new JsonParser[]{parserWithoutToken};
    JsonParserSequence sequence = new JsonParserSequence(parsers);

    // Since the sequence is initialized with a single parser, 
    // the containedParsersCount should return 1.
    assertEquals(1, sequence.containedParsersCount());
}

@Test
public void test_69_31() throws Exception {
    JsonParser parser1 = new JsonFactory().createParser("{}");
    JsonParser parser2 = new JsonFactory().createParser("[]");
    JsonParser[] parsers = new JsonParser[]{parser1, parser2};
    JsonParserSequence sequence = new JsonParserSequence(parsers);
    
    // Assert that the sequence contains exactly two parsers
    assertEquals(2, sequence.containedParsersCount());
}

}
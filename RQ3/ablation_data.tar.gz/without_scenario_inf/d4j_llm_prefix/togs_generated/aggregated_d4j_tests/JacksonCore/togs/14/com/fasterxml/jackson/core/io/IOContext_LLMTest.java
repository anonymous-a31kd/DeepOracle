package com.fasterxml.jackson.core.io;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.util.BufferRecycler;
import com.fasterxml.jackson.core.util.TextBuffer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class IOContext_LLMTest extends IOContext_LLMTest_scaffolding {
    
@Test
public void test_85_01() throws Exception {
	try {
    IOContext context = new IOContext(new BufferRecycler(), null, false);
    byte[] buffer = new byte[1024];
    context._verifyRelease(buffer, buffer);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_85_11() throws Exception {
    IOContext context = new IOContext(new BufferRecycler(), null, false);
    byte[] srcBuffer = new byte[1024];
    byte[] toRelease = new byte[2048];
    context._verifyRelease(toRelease, srcBuffer);
}

@Test
public void test_85_21() throws Exception {
    IOContext context = new IOContext(new BufferRecycler(), null, false);
    byte[] srcBuffer = new byte[1024];
    byte[] toRelease = new byte[1024];
    context._verifyRelease(toRelease, srcBuffer);
}

}
package com.fasterxml.jackson.core.json;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Arrays;
import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
import static com.fasterxml.jackson.core.JsonTokenId.*;
import com.fasterxml.jackson.core.io.CharTypes;
import java.io.*;
import com.fasterxml.jackson.core.io.IOContext;
import com.fasterxml.jackson.core.*;
import java.io.ByteArrayInputStream;
import com.fasterxml.jackson.core.util.*;
import com.fasterxml.jackson.core.base.ParserBase;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UTF8StreamJsonParser_LLMTest extends UTF8StreamJsonParser_LLMTest_scaffolding {
    
@Test
public void test_65_21() throws Exception {
    byte[] input = "".getBytes();
    IOContext ctxt = new IOContext(null, null, false);
    ByteQuadsCanonicalizer sym = ByteQuadsCanonicalizer.createRoot();
    UTF8StreamJsonParser parser = new UTF8StreamJsonParser(ctxt, 0, new ByteArrayInputStream(input), null, sym, null, 0, 0, false);

    JsonLocation loc = parser.getTokenLocation();
    
    // Assert that the location is at the start since the input is empty
    assertEquals(new JsonLocation(null, 0L, 1, 0), loc);
}

}
package org.apache.commons.jxpath.ri;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.ri.model.NodePointer;
import java.util.Iterator;
import org.apache.commons.jxpath.Pointer;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NamespaceResolver_LLMTest extends NamespaceResolver_LLMTest_scaffolding {
    
@Test
public void test_97_01() throws Exception {
    NamespaceResolver resolver = new NamespaceResolver();
    resolver.registerNamespace("test", "http://test.com");
    String prefix = resolver.getPrefix("http://test.com");
    assertEquals("test", prefix);
}

@Test
public void test_97_21() throws Exception {
    NamespaceResolver parent = new NamespaceResolver();
    parent.registerNamespace("parent", "http://parent.com");
    NamespaceResolver resolver = new NamespaceResolver(parent);
    String prefix = resolver.getPrefix("http://parent.com");
    assertEquals("parent", prefix);
}

@Test
public void test_97_31() throws Exception {
    NamespaceResolver resolver = new NamespaceResolver();
    String result = resolver.getPrefix(null);
    assertNull("The prefix should be null when the namespace URI is null", result);
}

@Test
public void test_97_41() throws Exception {
    NamespaceResolver resolver = new NamespaceResolver();
    resolver.registerNamespace("test", "http://test.com");
    String prefix = resolver.getPrefix("http://nonexistent.com");
    assertNull("Expected null for nonexistent namespace URI", prefix);
}

}
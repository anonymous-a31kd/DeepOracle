package org.apache.commons.jxpath.ri.model.dom;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.ri.NamespaceResolver;
import org.apache.commons.jxpath.JXPathContext;
import org.apache.commons.jxpath.util.TypeUtils;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import org.w3c.dom.Comment;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.w3c.dom.NodeList;
import org.apache.commons.jxpath.ri.QName;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Document;
import java.util.Locale;
import org.w3c.dom.ProcessingInstruction;
import java.util.HashMap;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.Pointer;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.w3c.dom.Node;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.w3c.dom.Element;
import java.util.Map;
import org.apache.commons.jxpath.AbstractFactory;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DOMNodePointer_LLMTest extends DOMNodePointer_LLMTest_scaffolding {
    
@Test
public void test_133_01() throws Exception {
    Element element = new org.apache.xerces.dom.ElementImpl(null, "test");
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    boolean result = DOMNodePointer.testNode(element, test);
    assertTrue("The node should pass the NodeTypeTest for NODE_TYPE_NODE.", result);
}

@Test
public void test_133_11() throws Exception {
    Document document = new org.apache.xerces.dom.DocumentImpl();
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    boolean result = DOMNodePointer.testNode(document, test);
    assertTrue("The document node should pass the node type test.", result);
}

@Test
public void test_133_21() throws Exception {
    Text text = new org.apache.xerces.dom.TextImpl();
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_NODE);
    boolean result = DOMNodePointer.testNode(text, test);
    assertFalse("Text node should not pass the NODE_TYPE_NODE test", result);
}

@Test
public void test_133_51() throws Exception {
    Text text = new org.apache.xerces.dom.TextImpl();
    NodeTypeTest test = new NodeTypeTest(Compiler.NODE_TYPE_TEXT);
    boolean result = DOMNodePointer.testNode(text, test);
    assertTrue("The node should pass the text node type test.", result);
}

}
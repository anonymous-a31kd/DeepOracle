package org.apache.commons.jxpath.ri.model.dom;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.jxpath.ri.compiler.NodeNameTest;
import org.w3c.dom.Attr;
import org.apache.commons.jxpath.JXPathException;
import java.util.Locale;
import java.util.HashMap;
import org.apache.commons.jxpath.Pointer;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.apache.commons.jxpath.ri.compiler.NodeTest;
import org.apache.commons.jxpath.ri.compiler.ProcessingInstructionTest;
import org.apache.commons.jxpath.ri.model.NodeIterator;
import org.apache.commons.jxpath.ri.model.beans.NullPointer;
import org.w3c.dom.Node;
import org.apache.commons.jxpath.ri.model.NodePointer;
import org.apache.commons.jxpath.ri.QName;
import org.apache.commons.jxpath.AbstractFactory;
import org.apache.commons.jxpath.JXPathAbstractFactoryException;
import org.apache.commons.jxpath.util.TypeUtils;
import java.util.Map;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Comment;
import org.w3c.dom.ProcessingInstruction;
import org.apache.commons.jxpath.JXPathContext;
import org.w3c.dom.Element;
import org.apache.commons.jxpath.ri.Compiler;
import org.apache.commons.jxpath.ri.model.dom.DOMNodePointer;
import org.apache.commons.jxpath.ri.compiler.NodeTypeTest;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DOMNodePointer_LLMTest extends DOMNodePointer_LLMTest_scaffolding {
    
@Test
public void test_131_01() throws Exception {
    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
    Element element = doc.createElementNS("http://example.com", "test:element");
    NodeNameTest test = new NodeNameTest(new QName("test", "element"), "http://example.com");
    boolean result = DOMNodePointer.testNode(element, test);
    assertTrue("The element should match the NodeTest criteria", result);
}

@Test
public void test_131_11() throws Exception {
    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
    Element element = doc.createElement("prefix:element");
    NodeNameTest test = new NodeNameTest(new QName("prefix", "element"), null);
    boolean result = DOMNodePointer.testNode(element, test);
    assertTrue("The node should match the NodeTest", result);
}

@Test
public void test_131_21() throws Exception {
    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
    Element element = doc.createElement("prefix1:element");
    NodeNameTest test = new NodeNameTest(new QName("prefix2", "element"), null);
    boolean result = DOMNodePointer.testNode(element, test);
    assertFalse(result);
}

@Test
public void test_131_31() throws Exception {
    Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
    Element element = doc.createElementNS("http://example.com", "test:element");
    NodeNameTest test = new NodeNameTest(new QName("test", "element"), "http://different.com");
    boolean result = DOMNodePointer.testNode(element, test);
    assertFalse(result);
}

}
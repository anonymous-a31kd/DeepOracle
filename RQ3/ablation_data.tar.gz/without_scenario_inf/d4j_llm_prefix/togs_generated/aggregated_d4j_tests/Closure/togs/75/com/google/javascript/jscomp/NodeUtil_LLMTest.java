package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.NodeUtil;
import java.util.Arrays;
import java.util.HashSet;
import com.google.javascript.rhino.TokenStream;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.common.base.Predicates;
import java.util.Map;
import com.google.common.base.Predicate;
import com.google.javascript.rhino.Node;
import com.google.common.base.Preconditions;
import javax.annotation.Nullable;
import com.google.common.collect.ImmutableSet;
import java.util.Collection;
import java.util.List;
import com.google.javascript.rhino.jstype.FunctionType;
import com.google.javascript.rhino.JSDocInfo;
import java.util.Set;
import com.google.javascript.rhino.jstype.JSType;
import com.google.common.collect.Maps;
import java.util.Collections;
import com.google.javascript.rhino.Token;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NodeUtil_LLMTest extends NodeUtil_LLMTest_scaffolding {
    
@Test
public void test_97_01() throws Exception {
    String input = "123\u000b456";
    NodeUtil.getStringNumberValue(input);
}

@Test
public void test_97_11() throws Exception {
    String input = "\u000b123456";
    Double result = NodeUtil.getStringNumberValue(input);
    assertEquals(Double.valueOf(123456), result);
}

@Test
public void test_97_21() throws Exception {
    String input = "123456\u000b";
    Double result = NodeUtil.getStringNumberValue(input);
    assertEquals(123456.0, result);
}

@Test
public void test_97_31() throws Exception {
    String input = "1\u000b2\u000b3\u000b4\u000b5\u000b6";
    Double result = NodeUtil.getStringNumberValue(input);
    assertNull("The input contains non-numeric separators, so the result should be null.", result);
}

@Test
public void test_97_41() throws Exception {
    String input = "123456";
    Double result = NodeUtil.getStringNumberValue(input);
    assertEquals(Double.valueOf(123456), result);
}

@Test
public void test_97_51() throws Exception {
    String input = "";
    Double result = NodeUtil.getStringNumberValue(input);
    assertNull(result);
}

@Test
public void test_97_61() throws Exception {
    String input = "   ";
    Double result = NodeUtil.getStringNumberValue(input);
    assertEquals(Double.NaN, result);
}

@Test
public void test_97_71() throws Exception {
    String input = "0x1A";
    Double result = NodeUtil.getStringNumberValue(input);
    assertEquals(Double.valueOf(26.0), result);
}

@Test
public void test_97_81() throws Exception {
    String input = "infinity";
    Double result = NodeUtil.getStringNumberValue(input);
    assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
}

@Test
public void test_98_01() throws Exception {
    TernaryValue result = NodeUtil.isStrWhiteSpaceChar('\u000B');
    assertEquals(TernaryValue.TRUE, result);
}

@Test
public void test_98_11() throws Exception {

    TernaryValue spaceResult = NodeUtil.isStrWhiteSpaceChar(' ');
    TernaryValue newlineResult = NodeUtil.isStrWhiteSpaceChar('\n');
    TernaryValue tabResult = NodeUtil.isStrWhiteSpaceChar('\t');
    TernaryValue nonBreakingSpaceResult = NodeUtil.isStrWhiteSpaceChar('\u00A0');

    assertEquals(TernaryValue.TRUE, spaceResult);
    assertEquals(TernaryValue.TRUE, newlineResult);
    assertEquals(TernaryValue.TRUE, tabResult);
    assertEquals(TernaryValue.TRUE, nonBreakingSpaceResult);
}

@Test
public void test_98_21() throws Exception {
    TernaryValue nonWhitespaceResult = NodeUtil.isStrWhiteSpaceChar('a');
    assertEquals(TernaryValue.FALSE, nonWhitespaceResult);
}

@Test
public void test_98_31() throws Exception {
    TernaryValue spaceSeparatorResult = NodeUtil.isStrWhiteSpaceChar('\u2002');
    assertEquals(TernaryValue.TRUE, spaceSeparatorResult);
}

@Test
public void test_98_41() throws Exception {
    TernaryValue formFeedResult = NodeUtil.isStrWhiteSpaceChar('\u000C');
    TernaryValue lineSeparatorResult = NodeUtil.isStrWhiteSpaceChar('\u2028');
    TernaryValue paragraphSeparatorResult = NodeUtil.isStrWhiteSpaceChar('\u2029');
    TernaryValue bomResult = NodeUtil.isStrWhiteSpaceChar('\uFEFF');

    // Assert that the form feed character is considered a whitespace character
    assertEquals(TernaryValue.TRUE, formFeedResult);

    // Assert that the line separator character is considered a whitespace character
    assertEquals(TernaryValue.TRUE, lineSeparatorResult);

    // Assert that the paragraph separator character is considered a whitespace character
    assertEquals(TernaryValue.TRUE, paragraphSeparatorResult);

    // Assert that the BOM character is not considered a whitespace character
    assertEquals(TernaryValue.FALSE, bomResult);
}

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import com.google.common.base.Charsets;
import com.google.javascript.jscomp.NodeUtil.MatchNotFunction;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.Charset;
import com.google.javascript.rhino.TokenStream;
import com.google.common.base.Preconditions;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CodeGenerator_LLMTest extends CodeGenerator_LLMTest_scaffolding {
    
@Test
public void test_101_01() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String input = "test\0string";
    String result = CodeGenerator.strEscape(input, '\'', "\\\"", "\\'", "\\\\", encoder);
    assertEquals("test\\u0000string", result);
}

@Test
public void test_101_11() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String input = "test\0string";
    String result = CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", encoder);
    assertEquals("test\\u0000string", result);
}

@Test
public void test_101_21() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String input = "\0test\0string\0";
    String result = CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", encoder);
    assertEquals("\\0test\\0string\\0", result);
}

@Test
public void test_101_31() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String input = "test\0\n\r\tstring";
    String result = CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", encoder);
    assertEquals("test\\u0000\\n\\r\\tstring", result);
}

@Test
public void test_101_41() throws Exception {
    String input = "test\0string";
    String result = CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", null);
    assertEquals("test\\0string", result);
}

@Test
public void test_101_51() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String input = "\0";
    String result = CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", encoder);
    assertEquals("\\0", result);
}

@Test
public void test_101_61() throws Exception {
    CharsetEncoder encoder = StandardCharsets.UTF_8.newEncoder();
    String input = "\0<script>\0</script>\0";
    String result = CodeGenerator.strEscape(input, '"', "\\\"", "\\'", "\\\\", encoder);
}

}
package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Token;
import java.util.List;
import com.google.javascript.rhino.Node;
import java.util.Set;
import java.util.HashMap;
import com.google.common.base.Predicate;
import com.google.javascript.jscomp.GlobalNamespace.Ref;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import java.util.ArrayList;
import java.util.LinkedList;
import com.google.javascript.jscomp.GlobalNamespace.Name.Type;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.GlobalNamespace.Name;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.TokenStream;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GlobalNamespace_LLMTest extends GlobalNamespace_LLMTest_scaffolding {
    
@Test
public void test_115_01() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.FUNCTION;
    name.aliasingGets = 1;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);

    // Assuming canCollapseUnannotatedChildNames should return false based on the given setup
    assertFalse(name.canCollapseUnannotatedChildNames());
}

@Test
public void test_115_11() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.OTHER;
    name.aliasingGets = 1;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);

    // Assert statement to verify the behavior of canCollapseUnannotatedChildNames
    assertFalse(name.canCollapseUnannotatedChildNames());
}

@Test
public void test_115_21() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.FUNCTION;
    name.aliasingGets = 0;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    
    // Assuming that the canCollapseUnannotatedChildNames method returns false
    // when there are no aliasing gets and there is a global set.
    assertFalse(name.canCollapseUnannotatedChildNames());
}

@Test
public void test_115_31() throws Exception {
    Name name = new Name("test", null, false);
    name.type = Type.FUNCTION;
    name.aliasingGets = 1;
    name.globalSets = 1;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    name.setIsClassOrEnum();
    
    // Assert statement based on the canCollapseUnannotatedChildNames method
    assertFalse(name.canCollapseUnannotatedChildNames());
}

}
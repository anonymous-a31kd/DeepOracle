package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.collect.ImmutableSet;
import java.util.Arrays;
import com.google.javascript.rhino.JSDocInfo;
import com.google.common.base.Preconditions;
import java.util.HashSet;
import java.util.List;
import com.google.javascript.rhino.TokenStream;
import com.google.common.base.Predicate;
import com.google.javascript.rhino.Token;
import javax.annotation.Nullable;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.common.base.Predicates;
import java.util.Set;
import java.util.Collections;
import com.google.common.collect.Maps;
import java.util.Collection;
import com.google.javascript.rhino.Node;
import java.util.Map;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.FunctionType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NodeUtil_LLMTest extends NodeUtil_LLMTest_scaffolding {
    
@Test
public void test_81_01() throws Exception {

    Node mathName = Node.newString(Token.NAME, "Math");
    Node randomProp = Node.newString(Token.STRING, "random");
    Node getProp = new Node(Token.GETPROP, mathName, randomProp);
    Node callNode = new Node(Token.CALL, getProp);

    boolean result = NodeUtil.functionCallHasSideEffects(callNode, null);
    assertTrue(result);
}

@Test
public void test_81_11() throws Exception {

    Node fooName = Node.newString(Token.NAME, "foo");
    Node barProp = Node.newString(Token.STRING, "bar");
    Node getProp = new Node(Token.GETPROP, fooName, barProp);
    Node callNode = new Node(Token.CALL, getProp);

    boolean result = NodeUtil.functionCallHasSideEffects(callNode, null);
    assertFalse(result);
}

@Test
public void test_81_21() throws Exception {

    Node mathName = Node.newString(Token.NAME, "Math");
    Node absProp = Node.newString(Token.STRING, "abs");
    Node getProp = new Node(Token.GETPROP, mathName, absProp);
    Node callNode = new Node(Token.CALL, getProp);

    AbstractCompiler compiler = null;

    boolean result = NodeUtil.functionCallHasSideEffects(callNode, compiler);

    // Assert statement to verify the expected behavior
    assertFalse(result);
}

@Test
public void test_81_31() throws Exception {

    Node fooName = Node.newString(Token.NAME, "foo");
    Node mathProp = Node.newString(Token.STRING, "Math");
    Node getProp1 = new Node(Token.GETPROP, fooName, mathProp);
    Node randomProp = Node.newString(Token.STRING, "random");
    Node getProp2 = new Node(Token.GETPROP, getProp1, randomProp);
    Node callNode = new Node(Token.CALL, getProp2);

    boolean result = NodeUtil.functionCallHasSideEffects(callNode, null);
    
    // Since Math.random() is a pure function without side effects, we expect the result to be false
    Assert.assertFalse(result);
}

}
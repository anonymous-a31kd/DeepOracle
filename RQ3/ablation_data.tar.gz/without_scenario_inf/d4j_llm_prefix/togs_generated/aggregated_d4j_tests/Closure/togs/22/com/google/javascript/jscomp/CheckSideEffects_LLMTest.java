package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Token;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.JSDocInfoBuilder;
import com.google.common.collect.Lists;
import com.google.javascript.jscomp.NodeTraversal;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.rhino.IR;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CheckSideEffects_LLMTest extends CheckSideEffects_LLMTest_scaffolding {
    
@Test
public void test_24_11() throws Exception {
    Node block = IR.block();
    NodeTraversal t = null;
    CheckSideEffects callback = new CheckSideEffects(null, CheckLevel.WARNING, false);
    callback.visit(t, block, IR.script());
}

@Test
public void test_24_41() throws Exception {
    Node eval = IR.name("eval");
    Node comma = IR.comma(IR.number(1), eval);
    Node call = IR.call(comma);
    NodeTraversal t = null;
    CheckSideEffects callback = new CheckSideEffects(null, CheckLevel.WARNING, false);
    callback.visit(t, comma.getFirstChild(), comma);
}

}
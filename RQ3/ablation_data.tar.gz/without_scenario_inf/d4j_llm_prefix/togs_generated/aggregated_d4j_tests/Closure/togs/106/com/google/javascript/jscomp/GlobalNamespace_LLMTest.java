package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.LinkedList;
import java.util.HashMap;
import com.google.javascript.rhino.Token;
import java.util.Set;
import com.google.common.base.Preconditions;
import com.google.javascript.jscomp.GlobalNamespace.Name;
import java.util.ArrayList;
import com.google.common.base.Predicate;
import com.google.javascript.jscomp.GlobalNamespace.Ref;
import java.util.Map;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import com.google.javascript.rhino.TokenStream;
import com.google.javascript.rhino.Node;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GlobalNamespace_LLMTest extends GlobalNamespace_LLMTest_scaffolding {
    
@Test
public void test_134_01() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 1;
    name.localSets = 0;
    name.declaration = null;
    boolean result = name.canCollapseUnannotatedChildNames();
    assertFalse(result);
}

@Test
public void test_134_21() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 1;
    name.localSets = 0;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    boolean result = name.canCollapseUnannotatedChildNames();
    // Assuming that a Name with globalSets > 0 and localSets == 0 can collapse unannotated child names
    assertTrue(result);
}

@Test
public void test_134_31() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 1;
    name.localSets = 0;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    name.setIsClassOrEnum();
    boolean result = name.canCollapseUnannotatedChildNames();
    
    assertTrue("Name should be able to collapse unannotated child names", result);
}

@Test
public void test_134_41() throws Exception {
    Name name = new Name("test", null, false);
    name.globalSets = 2;
    name.localSets = 0;
    name.declaration = Ref.createRefForTesting(Ref.Type.SET_FROM_GLOBAL);
    assertTrue(name.canCollapseUnannotatedChildNames());
}

}
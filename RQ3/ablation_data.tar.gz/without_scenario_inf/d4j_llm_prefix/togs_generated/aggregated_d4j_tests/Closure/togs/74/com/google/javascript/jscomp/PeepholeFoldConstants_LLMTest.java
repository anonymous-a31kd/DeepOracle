package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.collect.Lists;
import com.google.javascript.jscomp.mozilla.rhino.ScriptRuntime;
import com.google.javascript.rhino.jstype.TernaryValue;
import com.google.javascript.rhino.Node;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Token;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class PeepholeFoldConstants_LLMTest extends PeepholeFoldConstants_LLMTest_scaffolding {
    
@Test
public void test_96_01() throws Exception {
    Node voidNode = new Node(Token.VOID);
    voidNode.addChildToBack(Node.newNumber(1));
    Node right = Node.newString("test");
    Node comparison = new Node(Token.EQ, voidNode, right);

    PeepholeFoldConstants optimizer = new PeepholeFoldConstants();
    Node foldedNode = optimizer.tryFoldComparison(comparison, voidNode, right);

    // Assert that the comparison node is unchanged as VOID and STRING can't be folded into a constant
    assertEquals(comparison, foldedNode);
}

@Test
public void test_96_11() throws Exception {
    Node nullNode = new Node(Token.NULL);
    Node right = new Node(Token.NULL);
    Node comparison = new Node(Token.SHEQ, nullNode, right);

}

@Test
public void test_96_21() throws Exception {
    Node numNode = Node.newNumber(42);
    Node right = Node.newNumber(42);
    Node comparison = new Node(Token.EQ, numNode, right);

    PeepholeFoldConstants optimizer = new PeepholeFoldConstants();
    Node result = optimizer.tryFoldComparison(comparison, numNode, right);

    // Assert that the comparison is folded to a boolean true node
    assertTrue(result.isTrue());
}

@Test
public void test_96_31() throws Exception {
    Node strNode = Node.newString("hello");
    Node right = Node.newString("hello");
    Node comparison = new Node(Token.SHEQ, strNode, right);
    
    PeepholeFoldConstants foldConstants = new PeepholeFoldConstants();
    Node result = foldConstants.tryFoldComparison(comparison, strNode, right);

    assertEquals(Token.TRUE, result.getType());
}

@Test
public void test_96_51() throws Exception {
    Node left = Node.newNumber(42);
    Node voidNode = new Node(Token.VOID);
    voidNode.addChildToBack(Node.newNumber(1));
    Node comparison = new Node(Token.EQ, left, voidNode);
    
    // Focal method invocation
    PeepholeFoldConstants optimizer = new PeepholeFoldConstants();
    Node foldedComparison = optimizer.tryFoldComparison(comparison, left, voidNode);
    
    // Assert statement
    assertEquals(Token.FALSE, foldedComparison.getType());
}

@Test
public void test_96_61() throws Exception {
    Node numNode = Node.newNumber(42);
    Node strNode = Node.newString("42");
    Node comparison = new Node(Token.EQ, numNode, strNode);
    
    PeepholeFoldConstants peephole = new PeepholeFoldConstants();
    Node resultNode = peephole.tryFoldComparison(comparison, numNode, strNode);
    
    // Since a number and a string are being compared, we expect no folding to occur
    // and the original comparison node to be returned.
    assertEquals(comparison, resultNode);
}

}
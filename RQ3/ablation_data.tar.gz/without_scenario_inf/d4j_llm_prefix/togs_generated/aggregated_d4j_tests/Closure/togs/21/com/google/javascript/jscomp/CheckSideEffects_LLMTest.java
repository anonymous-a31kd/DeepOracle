package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.IR;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.rhino.JSDocInfoBuilder;
import com.google.javascript.jscomp.NodeTraversal.AbstractPostOrderCallback;
import com.google.javascript.rhino.Token;
import java.util.List;
import com.google.javascript.jscomp.NodeTraversal;
import com.google.javascript.jscomp.AbstractCompiler;
import com.google.common.collect.Lists;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CheckSideEffects_LLMTest extends CheckSideEffects_LLMTest_scaffolding {
    
@Test
public void test_23_01() throws Exception {
    Node blockNode = new Node(Token.BLOCK);
    Node parentNode = new Node(Token.SCRIPT);
    parentNode.addChildToBack(blockNode);

    CheckSideEffects checker = new CheckSideEffects(null, null, false);
    checker.visit(null, blockNode, parentNode);
}

@Test
public void test_23_11() throws Exception {
    Node exprNode = new Node(Token.EXPR_RESULT);
    Node parentNode = new Node(Token.SCRIPT);
    parentNode.addChildToBack(exprNode);

    CheckSideEffects checker = new CheckSideEffects(null, null, false);
    checker.visit(null, exprNode, parentNode);
}

}
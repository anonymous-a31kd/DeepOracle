package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Util_LLMTest extends Util_LLMTest_scaffolding {
    
@Test
public void test_13_01() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("");
    assertEquals("", result);
}

@Test
public void test_13_11() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("\"");
    assertEquals("", result);
}

@Test
public void test_13_21() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("\"quoted\"");
    assertEquals("quoted", result);
}

@Test
public void test_13_31() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("\"notquoted");
    assertEquals("notquoted", result);
}

@Test
public void test_13_41() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("notquoted\"");
    assertEquals("notquoted\"", result);
}

@Test
public void test_13_51() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("\"quo\"ted\"");
    assertEquals("quo\"ted", result);
}

@Test
public void test_13_61() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("normal");
    assertEquals("normal", result);
}

@Test
public void test_13_71() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("\"\"doublequoted\"\"");
    assertEquals("doublequoted", result);
}

@Test
public void test_13_81() throws Exception {
    String result = org.apache.commons.cli.Util.stripLeadingAndTrailingQuotes("\"a\"");
    assertEquals("a", result);
}

}
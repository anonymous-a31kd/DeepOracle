package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Comparator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Collection;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class HelpFormatter_LLMTest extends HelpFormatter_LLMTest_scaffolding {
    
@Test
public void test_10_01() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "short text";
    StringBuffer result = formatter.renderWrappedText(sb, 20, 4, text);
    assertEquals("short text", result.toString());
}

@Test
public void test_10_11() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "This is a long text that should be wrapped when it exceeds the specified width";
    StringBuffer result = formatter.renderWrappedText(sb, 20, 4, text);
}

@Test
public void test_10_21() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "Exactly20CharsLong";
    StringBuffer result = formatter.renderWrappedText(sb, 20, 4, text);
    
    // Assert that the result contains the original text since the text length matches the width
    assertEquals("Exactly20CharsLong", result.toString().trim());
}

@Test
public void test_10_31() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "This text is designed to trigger the pos == nextLineTabStop-1 condition";
    StringBuffer result = formatter.renderWrappedText(sb, 10, 5, text);
    assertEquals("This\ntext\nis\ndesigned\nto\ntrigger\nthe\npos\n==\nnextLineT\nabStop-1\ncondition", result.toString());
}

@Test
public void test_10_51() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringBuffer sb = new StringBuffer();
    String text = "First line\nSecond line with more text\nThird line";
    StringBuffer result = formatter.renderWrappedText(sb, 15, 4, text);
}

}
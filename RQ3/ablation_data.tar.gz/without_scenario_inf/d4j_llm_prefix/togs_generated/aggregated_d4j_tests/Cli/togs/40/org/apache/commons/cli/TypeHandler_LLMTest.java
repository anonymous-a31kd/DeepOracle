package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.commons.cli.ParseException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.Date;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypeHandler_LLMTest extends TypeHandler_LLMTest_scaffolding {
    
@Test
public void test_18_01()  throws Exception {
	try {
    TypeHandler.createValue("test", Integer.class);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_18_11() throws Exception {
    String result = TypeHandler.createValue("test", PatternOptionBuilder.STRING_VALUE);
    assertEquals("test", result);
}

@Test
public void test_18_21() throws Exception {
    String result = TypeHandler.createValue("java.lang.String", PatternOptionBuilder.OBJECT_VALUE);
    assertEquals("java.lang.String", result);
}

@Test
public void test_18_31() throws Exception {
    Number result = TypeHandler.createValue("123", PatternOptionBuilder.NUMBER_VALUE);
    assertEquals(123, result.intValue());
}

@Test
public void test_18_51()  throws Exception {
	try {
    TypeHandler.createValue("java.lang.String", PatternOptionBuilder.CLASS_VALUE);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_18_61() throws Exception {
    File result = TypeHandler.createValue("test.txt", PatternOptionBuilder.FILE_VALUE);
    assertEquals(new File("test.txt"), result);
}

@Test
public void test_18_91() throws Exception {
    URL url = TypeHandler.createValue("http://example.com", PatternOptionBuilder.URL_VALUE);
    assertEquals(new URL("http://example.com"), url);
}

}
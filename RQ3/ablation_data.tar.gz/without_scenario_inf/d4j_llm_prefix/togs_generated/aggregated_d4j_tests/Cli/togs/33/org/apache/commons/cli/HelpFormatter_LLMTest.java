package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Arrays;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.BufferedReader;
import java.util.Collection;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class HelpFormatter_LLMTest extends HelpFormatter_LLMTest_scaffolding {
    
@Test
public void test_25_01() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 2, "");
    pw.flush();
    assertEquals("", sw.toString());
}

@Test
public void test_25_11() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 20, 2, "Short text");
    pw.flush();
    
    // Complete test case
    assertEquals("Short text", sw.toString().trim());
}

@Test
public void test_25_21() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 2, "This is a long text that needs wrapping");
    pw.flush();
}

@Test
public void test_25_31() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 2, "Line1\nLine2\nLine3");
    pw.flush();
}

@Test
public void test_25_41() throws Exception {
    HelpFormatter formatter = new HelpFormatter();
    StringWriter sw = new StringWriter();
    PrintWriter pw = new PrintWriter(sw);
    formatter.printWrapped(pw, 10, 15, "Text with large tab stop");
    pw.flush();
    // The expected output should be wrapped text according to the specified width and nextLineTabStop
    String expectedOutput = "Text with\n     large\n     tab\n     stop\n";
    assertEquals(expectedOutput, sw.toString());
}

}
package org.apache.commons.cli;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Util_LLMTest extends Util_LLMTest_scaffolding {
    
@Test
public void test_0_01() throws Exception {
    String result = Util.stripLeadingHyphens(null);
    assertNull(result);
}

@Test
public void test_0_11() throws Exception {
    String result = Util.stripLeadingHyphens("--option");
    assertEquals("option", result);
}

@Test
public void test_0_21() throws Exception {
    String result = Util.stripLeadingHyphens("-option");
    assertEquals("option", result);
}

@Test
public void test_0_31() throws Exception {
    String result = Util.stripLeadingHyphens("option");
    assertEquals("option", result);
}

@Test
public void test_0_41() throws Exception {
    String result = Util.stripLeadingHyphens("");
    assertEquals("", result);
}

@Test
public void test_0_51() throws Exception {
    String result = Util.stripLeadingHyphens("---");
    assertEquals("", result);
}

}
package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.zip.ZipException;
import java.io.File;
import java.util.Date;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveEntry_LLMTest extends ZipArchiveEntry_LLMTest_scaffolding {
    
@Test
public void test_32_01() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    entry1.setName(null);
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");
    entry2.setName(null);

    // Assert that two ZipArchiveEntry objects with the same name set to null are equal
    assertTrue(entry1.equals(entry2));
}

@Test
public void test_32_11() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    entry1.setName(null);
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");

    // Assert that the two entries are not equal because entry1's name is set to null
    assertFalse(entry1.equals(entry2));
}

@Test
public void test_32_21() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test1");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test2");

    // Test if two different ZipArchiveEntry objects are not equal
    assertFalse(entry1.equals(entry2));
}

@Test
public void test_32_31() throws Exception {
    ZipArchiveEntry entry1 = new ZipArchiveEntry("test");
    ZipArchiveEntry entry2 = new ZipArchiveEntry("test");

    // Assert that two ZipArchiveEntry objects with the same name are equal
    assertTrue(entry1.equals(entry2));
}

@Test
public void test_32_41() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");

    // Create another ZipArchiveEntry with the same name to test equality
    ZipArchiveEntry anotherEntry = new ZipArchiveEntry("test");

    // Assert that the two entries are equal
    assertTrue(entry.equals(anotherEntry));
}

@Test
public void test_32_51() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    ZipArchiveEntry identicalEntry = new ZipArchiveEntry("test");
    
    assertTrue(entry.equals(identicalEntry));
}

@Test
public void test_32_61() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry("test");
    ZipArchiveEntry sameEntry = new ZipArchiveEntry("test");

    assertTrue(entry.equals(sameEntry));
}

}
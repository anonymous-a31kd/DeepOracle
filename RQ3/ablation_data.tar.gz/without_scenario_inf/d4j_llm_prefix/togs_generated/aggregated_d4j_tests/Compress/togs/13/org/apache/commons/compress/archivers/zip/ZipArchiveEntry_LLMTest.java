package org.apache.commons.compress.archivers.zip;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.io.File;
import java.util.zip.ZipException;
import java.util.ArrayList;
import java.util.Date;
import org.apache.commons.compress.archivers.ArchiveEntry;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZipArchiveEntry_LLMTest extends ZipArchiveEntry_LLMTest_scaffolding {
    
@Test
public void test_7_01() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry();
    entry.setPlatform(ZipArchiveEntry.PLATFORM_FAT);
    entry.setName("folder\\file.txt");
    
    // Assert that the name is set correctly
    assertEquals("folder\\file.txt", entry.getName());
}

@Test
public void test_7_11() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry();
    entry.setPlatform(ZipArchiveEntry.PLATFORM_FAT);
    entry.setName("folder/file.txt");

    // Assert that the name was set correctly
    assertEquals("folder/file.txt", entry.getName());
}

@Test
public void test_7_21() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry();
    entry.setPlatform(ZipArchiveEntry.PLATFORM_UNIX);
    entry.setName("folder\\file.txt");
    
    assertEquals("folder/file.txt", entry.getName());
}

@Test
public void test_7_31() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry();
    entry.setPlatform(ZipArchiveEntry.PLATFORM_FAT);
    entry.setName(null);

    assertNull("The name of the entry should be null after setting it to null.", entry.getName());
}

@Test
public void test_7_41() throws Exception {
    ZipArchiveEntry entry = new ZipArchiveEntry();
    entry.setPlatform(ZipArchiveEntry.PLATFORM_FAT);
    entry.setName("filename");
    
    // Validate that the name is set correctly
    assertEquals("filename", entry.getName());
}

}
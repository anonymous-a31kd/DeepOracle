package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarUtils_LLMTest extends TarUtils_LLMTest_scaffolding {
    
@Test
public void test_33_01() throws Exception {
	try {
    byte[] buffer = new byte[]{'1'};

    TarUtils.parseOctal(buffer, 0, 1);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_33_11() throws Exception {
    byte[] buffer = new byte[]{0, 0, 0, 0};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(0L, result);
}

@Test
public void test_33_21() throws Exception {
    byte[] buffer = new byte[]{' ', ' ', '1', '2', '3', ' '};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(83L, result);
}

@Test
public void test_33_31() throws Exception {
    byte[] buffer = new byte[]{'1', '2', '3', ' '};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(83L, result);
}

@Test
public void test_33_41() throws Exception {
    byte[] buffer = new byte[]{'1', '2', '3', 0};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(83L, result);
}

@Test
public void test_33_51() throws Exception {
	try {
    byte[] buffer = new byte[]{'1', '2', '3', '4'};

    TarUtils.parseOctal(buffer, 0, buffer.length);



		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_33_61() throws Exception {
    byte[] buffer = new byte[]{'1', '2', ' ', ' '};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(10L, result);
}

@Test
public void test_33_71() throws Exception {
    byte[] buffer = new byte[]{'1', '2', 0, 0};
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    assertEquals(10L, result);
}

@Test
public void test_33_81() throws Exception {
    byte[] buffer = new byte[]{'1', '2', '3', '4', '5', '6', '7', ' '}; // Added a trailing space as per the method requirement
    long result = TarUtils.parseOctal(buffer, 0, buffer.length);
    
    assertEquals(342391, result); // 1234567 in octal is 342391 in decimal
}

}
package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.StringWriter;
import org.apache.commons.compress.utils.CharsetNames;
import java.io.OutputStream;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import org.apache.commons.compress.utils.CountingOutputStream;
import java.util.HashMap;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
import java.util.Map;
import java.io.File;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveOutputStream_LLMTest extends TarArchiveOutputStream_LLMTest_scaffolding {
    
@Test
public void test_11_01() throws Exception {
    Map<String, String> headers = new HashMap<>();
    headers.put("key", "value");
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new java.io.ByteArrayOutputStream());
    long before = tarOut.getBytesWritten();
    tarOut.writePaxHeaders("testEntry/", headers);
    assertTrue(tarOut.getBytesWritten() > before);
}

@Test
public void test_11_11() throws Exception {
    Map<String, String> headers = new HashMap<>();
    headers.put("key", "value");
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new java.io.ByteArrayOutputStream());
    long bytesBefore = tarOut.getBytesWritten();
    tarOut.writePaxHeaders("testEntry///", headers);
    assertTrue("Should have written some bytes", tarOut.getBytesWritten() > bytesBefore);
}

@Test
public void test_11_21() throws Exception {
    Map<String, String> headers = new HashMap<>();
    headers.put("key", "value");
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new java.io.ByteArrayOutputStream());
    tarOut.writePaxHeaders("testEntry", headers);
    
    // Asserting that the PAX headers have been written by checking the bytes written
    assertTrue(tarOut.getBytesWritten() > 0);
}

@Test
public void test_11_31() throws Exception {
    Map<String, String> headers = new HashMap<>();
    headers.put("key", "value");
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new java.io.ByteArrayOutputStream());
    long bytesBefore = tarOut.getBytesWritten();
    tarOut.writePaxHeaders("", headers);
    assertTrue("Should have written some bytes", tarOut.getBytesWritten() > bytesBefore);
}

@Test
public void test_11_41()  throws Exception {
    Map<String, String> headers = new HashMap<>();
    headers.put("key", "value");
    StringBuilder longName = new StringBuilder();
    for (int i = 0; i < 200; i++) {
        longName.append("a");
    }
    longName.append("/");
    TarArchiveOutputStream tarOut = new TarArchiveOutputStream(new java.io.ByteArrayOutputStream());
    tarOut.writePaxHeaders(longName.toString(), headers);
}

}
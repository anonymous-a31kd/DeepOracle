package org.apache.commons.compress.archivers.tar;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.utils.ArchiveUtils;
import java.util.Map;
import java.util.Locale;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import java.io.File;
import java.util.Date;
import org.apache.commons.compress.archivers.zip.ZipEncoding;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TarArchiveEntry_LLMTest extends TarArchiveEntry_LLMTest_scaffolding {
    
@Test
public void test_30_01() throws Exception {
    TarArchiveEntry entry = new TarArchiveEntry("testdir/");
    assertTrue(entry.isDirectory());
}

@Test
public void test_30_11() throws Exception {
    TarArchiveEntry entry = new TarArchiveEntry("testdir/", TarArchiveEntry.LF_PAX_EXTENDED_HEADER_LC);
    assertTrue(entry.isDirectory());
}

@Test
public void test_30_21() throws Exception {
    TarArchiveEntry entry = new TarArchiveEntry("testdir/", TarArchiveEntry.LF_PAX_GLOBAL_EXTENDED_HEADER);
    assertTrue(entry.isDirectory());
}

@Test
public void test_30_31() throws Exception {
    TarArchiveEntry entry = new TarArchiveEntry("testfile");
    assertFalse(entry.isDirectory());
}

@Test
public void test_30_41() throws Exception {
    TarArchiveEntry entry = new TarArchiveEntry("testdir", TarArchiveEntry.LF_DIR);
    assertTrue(entry.isDirectory());
}

@Test
public void test_30_51() throws Exception {
    File tempDir = File.createTempFile("test", "");
    tempDir.delete();
    tempDir.mkdir();

    TarArchiveEntry entry = new TarArchiveEntry(tempDir);
    
    // Assert that the entry represents a directory
    assertTrue(entry.isDirectory());
}

}
package org.apache.commons.compress.compressors;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import org.apache.commons.compress.compressors.snappy.FramedSnappyCompressorInputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorOutputStream;
import java.io.ByteArrayInputStream;
import org.apache.commons.compress.compressors.CompressorException;
import org.apache.commons.compress.compressors.lzma.LZMAUtils;
import java.io.InputStream;
import org.apache.commons.compress.compressors.snappy.SnappyCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZUtils;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.z.ZCompressorInputStream;
import java.io.OutputStream;
import org.apache.commons.compress.compressors.pack200.Pack200CompressorOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.compressors.pack200.Pack200CompressorInputStream;
import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CompressorStreamFactory_LLMTest extends CompressorStreamFactory_LLMTest_scaffolding {
    
@Test
public void test_26_01() throws Exception {
    byte[] deflateSignature = new byte[12];

    deflateSignature[0] = 0x78;
    InputStream in = new ByteArrayInputStream(deflateSignature);

    CompressorStreamFactory factory = new CompressorStreamFactory();
    CompressorInputStream compressorInputStream = factory.createCompressorInputStream(in);

    assertNotNull(compressorInputStream);
}

@Test
public void test_26_11()  throws Exception {
	try {

    byte[] invalidSignature = new byte[12];
    InputStream in = new ByteArrayInputStream(invalidSignature);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_26_21()  throws Exception {
	try {

    byte[] partialSignature = new byte[1];
    partialSignature[0] = 0x78;
    InputStream in = new ByteArrayInputStream(partialSignature);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_26_31() throws Exception {
	try {
    InputStream in = null;


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_26_41() throws Exception {
	try {
    InputStream in = new InputStream() {
        @Override
        public int read() throws IOException {
            return -1;
        }

        @Override
        public boolean markSupported() {
            return false;
        }
    };


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
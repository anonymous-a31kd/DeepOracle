package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigDecimal;
import org.apache.commons.lang3.StringUtils;
import java.math.BigInteger;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_138_01() throws Exception {
    assertNull(NumberUtils.createBigDecimal(null));
}

@Test
public void test_138_51() throws Exception {
    BigDecimal result = NumberUtils.createBigDecimal("123.45");
    assertEquals(new BigDecimal("123.45"), result);
}

@Test
public void test_138_61() throws Exception {
    BigDecimal result = NumberUtils.createBigDecimal("-123.45");
    assertEquals(new BigDecimal("-123.45"), result);
}

@Test
public void test_138_71() throws Exception {
    BigDecimal expected = new BigDecimal("123.45");
    BigDecimal actual = NumberUtils.createBigDecimal("+123.45");
    assertEquals(expected, actual);
}

@Test
public void test_138_81() throws Exception {
    BigDecimal expected = new BigDecimal("12345678901234567890.1234567890");
    BigDecimal actual = NumberUtils.createBigDecimal("12345678901234567890.1234567890");
    assertEquals(expected, actual);
}

@Test
public void test_139_01() throws Exception {
	try {

    NumberUtils.createNumber("--123");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_139_11() throws Exception {
    Number result = NumberUtils.createNumber("-123");
    assertEquals(Integer.valueOf(-123), result);
}

@Test
public void test_139_21() throws Exception {
    Number result = NumberUtils.createNumber("0x1A");
    assertEquals(26, result.intValue());
}

@Test
public void test_139_31() throws Exception {
    Number result = NumberUtils.createNumber("-0x1A");
    assertEquals(Long.valueOf(-26L), result);
}

@Test
public void test_139_51() throws Exception {
    assertNull(NumberUtils.createNumber(null));
}

}
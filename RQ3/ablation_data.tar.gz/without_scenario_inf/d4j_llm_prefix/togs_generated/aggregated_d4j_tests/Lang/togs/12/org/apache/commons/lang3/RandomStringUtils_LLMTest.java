package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;

import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class RandomStringUtils_LLMTest extends RandomStringUtils_LLMTest_scaffolding {
    
@Test
public void test_161_11() throws Exception {
    char[] chars = {'a', 'b', 'c'};
    String result = RandomStringUtils.random(3, 0, 0, true, true, chars, new Random());
    assertTrue(result.matches("[abc]{3}"));
}

@Test
public void test_161_21() throws Exception {
    String result = RandomStringUtils.random(5, 0, 0, true, true, null, new Random());
    assertEquals(5, result.length());
}

@Test
public void test_161_31() throws Exception {
    char[] chars = {'a', 'b', 'c', 'd', 'e'};
    String result = RandomStringUtils.random(3, 0, 0, false, false, chars, new Random());
    assertEquals(3, result.length());
    for (char c : result.toCharArray()) {
        assertTrue(new String(chars).indexOf(c) >= 0);
    }
}

@Test
public void test_161_41() throws Exception {
    String result = RandomStringUtils.random(5, 0, 0, false, false, null, new Random());
    assertEquals(5, result.length());
}

@Test
public void test_161_61() throws Exception {
	try {
    RandomStringUtils.random(0, 0, 0, true, true, null, new Random());


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
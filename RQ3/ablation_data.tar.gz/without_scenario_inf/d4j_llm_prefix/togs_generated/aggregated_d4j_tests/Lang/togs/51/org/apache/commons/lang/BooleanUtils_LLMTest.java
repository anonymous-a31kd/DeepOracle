package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.BooleanUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class BooleanUtils_LLMTest extends BooleanUtils_LLMTest_scaffolding {
    
@Test
public void test_193_01() throws Exception {
    assertTrue(BooleanUtils.toBoolean("yes"));
    assertTrue(BooleanUtils.toBoolean("Yes"));
    assertTrue(BooleanUtils.toBoolean("yEs"));
    assertTrue(BooleanUtils.toBoolean("yeS"));
    assertTrue(BooleanUtils.toBoolean("YEs"));
    assertTrue(BooleanUtils.toBoolean("YeS"));
    assertTrue(BooleanUtils.toBoolean("yES"));
    assertTrue(BooleanUtils.toBoolean("YES"));
}

@Test
public void test_193_11() throws Exception {
    assertFalse(BooleanUtils.toBoolean("yex"));
    assertFalse(BooleanUtils.toBoolean("yep"));
    assertFalse(BooleanUtils.toBoolean("yss"));
    assertFalse(BooleanUtils.toBoolean("yee"));
    assertFalse(BooleanUtils.toBoolean("YEX"));
    assertFalse(BooleanUtils.toBoolean("YEP"));
    assertFalse(BooleanUtils.toBoolean("YSS"));
    assertFalse(BooleanUtils.toBoolean("YEE"));
}

@Test
public void test_193_21() throws Exception {
    // Testing various strings with BooleanUtils.toBoolean method
    assertFalse(BooleanUtils.toBoolean("abc"));
    assertFalse(BooleanUtils.toBoolean("123"));
    assertFalse(BooleanUtils.toBoolean("no"));
    assertFalse(BooleanUtils.toBoolean("off"));
    assertFalse(BooleanUtils.toBoolean("xyz"));
    assertFalse(BooleanUtils.toBoolean("   "));
    assertFalse(BooleanUtils.toBoolean("tru"));
}

@Test
public void test_193_31() throws Exception {
    assertTrue(BooleanUtils.toBoolean("yEs"));
    assertTrue(BooleanUtils.toBoolean("YeS"));
    assertTrue(BooleanUtils.toBoolean("YEs"));
    assertTrue(BooleanUtils.toBoolean("yES"));
    assertFalse(BooleanUtils.toBoolean("yEx"));
    assertFalse(BooleanUtils.toBoolean("YeP"));
    assertFalse(BooleanUtils.toBoolean("Yss"));
    assertFalse(BooleanUtils.toBoolean("yEe"));
}

@Test
public void test_193_41() throws Exception {

    assertFalse(BooleanUtils.toBoolean(""));
    assertFalse(BooleanUtils.toBoolean("y"));
    assertFalse(BooleanUtils.toBoolean("ye"));
    assertTrue(BooleanUtils.toBoolean("yes"));
    assertFalse(BooleanUtils.toBoolean("yess"));
}

}
package org.apache.commons.lang3.builder;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Set;
import org.apache.commons.lang3.builder.ToStringStyle;
import java.util.Collections;
import java.util.WeakHashMap;
import java.util.Map;
import org.apache.commons.lang3.ClassUtils;
import java.util.Collection;
import java.io.Serializable;
import org.apache.commons.lang3.SystemUtils;
import org.apache.commons.lang3.ObjectUtils;
import java.lang.reflect.Array;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ToStringStyle_LLMTest extends ToStringStyle_LLMTest_scaffolding {
    
@Test
public void test_181_01() throws Exception {
    Map<Object, Object> result = ToStringStyle.getRegistry();
    assertNotNull("The registry map should not be null", result);
}

@Test
public void test_181_11() throws Exception {

    ToStringStyle.register(new Object());
    ToStringStyle.unregister(new Object());
    Map<Object, Object> result = ToStringStyle.getRegistry();
    
    // Assert that the registry is empty after unregistering the object
    assertTrue(result.isEmpty());
}

@Test
public void test_181_21() throws Exception {

    Object obj1 = new Object();
    Object obj2 = new Object();
    ToStringStyle.register(obj1);
    ToStringStyle.register(obj2);
    Map<Object, Object> result = ToStringStyle.getRegistry();
    ToStringStyle.unregister(obj1);
    ToStringStyle.unregister(obj2);
}

@Test
public void test_182_01() throws Exception {

    Object testObj = new Object();
    boolean result = ToStringStyle.isRegistered(testObj);

    // The registry should not contain the testObj initially
    assertFalse(result);
}

@Test
public void test_182_11() throws Exception {

    Object testObj = new Object();
    Map<Object, Object> registry = new WeakHashMap<Object, Object>();

    // Register the object in the registry
    registry.put(testObj, testObj);

    // Check if the object is registered
    boolean result = ToStringStyle.isRegistered(testObj);

    // Assert that the object is indeed registered
    assertTrue(result);
}

@Test
public void test_182_21() throws Exception {

    Object testObj = new Object();
    Map<Object, Object> registry = new WeakHashMap<Object, Object>();
    registry.put(testObj, testObj);

    boolean result = ToStringStyle.isRegistered(testObj);

    // Assert that the object is registered in the registry
    assertTrue(result);
}

}
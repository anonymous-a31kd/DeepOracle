package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.exception.NestableRuntimeException;
import java.io.Writer;
import java.io.StringWriter;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringEscapeUtils_LLMTest extends StringEscapeUtils_LLMTest_scaffolding {
    
@Test
public void test_153_01() throws Exception {
    String result = StringEscapeUtils.escapeJava(null);
    assertNull(result);
}

@Test
public void test_153_11() throws Exception {
    String result = StringEscapeUtils.escapeJava("");
    assertEquals("", result);
}

@Test
public void test_153_21() throws Exception {
    String result = StringEscapeUtils.escapeJava("plain text");
    assertEquals("plain text", result);
}

@Test
public void test_153_31() throws Exception {
    String result = StringEscapeUtils.escapeJava("text\nwith\nnewlines");
    assertEquals("text\\nwith\\nnewlines", result);
}

@Test
public void test_153_41() throws Exception {
    String result = StringEscapeUtils.escapeJava("\"quoted\" text");
    assertEquals("\\\"quoted\\\" text", result);
}

@Test
public void test_153_51() throws Exception {
    String result = StringEscapeUtils.escapeJava("text\\with\\backslashes");
    assertEquals("text\\\\with\\\\backslashes", result);
}

@Test
public void test_153_61() throws Exception {
    String result = StringEscapeUtils.escapeJava("text with \u1234 unicode");
    assertEquals("text with \\u1234 unicode", result);
}

@Test
public void test_153_71() throws Exception {
    String result = StringEscapeUtils.escapeJava("text with \t tab and \b backspace");
    assertEquals("text with \\t tab and \\b backspace", result);
}

@Test
public void test_154_01() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript(null);
    assertNull("The result should be null when the input is null", result);
}

@Test
public void test_154_11() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("");
    assertEquals("", result);
}

@Test
public void test_154_21() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("abc123");
    assertEquals("abc123", result);
}

@Test
public void test_154_31() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("a\nb\tc");
    assertEquals("a\\nb\\tc", result);
}

@Test
public void test_154_41() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("don't");
    assertEquals("don\\'t", result);
}

@Test
public void test_154_51() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("\"quote\"");
    assertEquals("\\\"quote\\\"", result);
}

@Test
public void test_154_61() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("path\\to\\file");
    assertEquals("path\\\\to\\\\file", result);
}

@Test
public void test_154_71() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("日本語");
    assertEquals("日本語", result);
}

@Test
public void test_154_81() throws Exception {
    String result = StringEscapeUtils.escapeJavaScript("Line1\nLine2\tDon't \"quote\" \\path");
    assertEquals("Line1\\nLine2\\tDon\\'t \\\"quote\\\" \\\\path", result);
}

@Test
public void test_155_01() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, null);
    assertEquals("", writer.toString());
}

@Test
public void test_155_11() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "");
    assertEquals("", writer.toString());
}

@Test
public void test_155_21() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test");
    assertEquals("test", writer.toString());
}

@Test
public void test_155_31() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test\n\r\t\b\f\"\\");
    assertEquals("test\\n\\r\\t\\b\\f\\\"\\\\", writer.toString());
}

@Test
public void test_155_41() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test\u1234");
    assertEquals("test\\u1234", writer.toString());
}

@Test
public void test_155_51() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJava(writer, "test'");
    assertEquals("test\\'", writer.toString());
}

@Test
public void test_156_01() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, null);
    assertEquals("", writer.toString());
}

@Test
public void test_156_11() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "");
    assertEquals("", writer.toString());
}

@Test
public void test_156_21() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "test");
    assertEquals("test", writer.toString());
}

@Test
public void test_156_31() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "line\nbreak");
    assertEquals("line\\nbreak", writer.toString());
}

@Test
public void test_156_41()  throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "don't");
    assertEquals("don\\'t", writer.toString());
}

@Test
public void test_156_51() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "日本語");
    assertEquals("日本語", writer.toString());
}

@Test
public void test_156_61() throws Exception {
    Writer writer = new StringWriter();
    StringEscapeUtils.escapeJavaScript(writer, "\b\t\n\f\r");
    assertEquals("\\b\\t\\n\\f\\r", writer.toString());
}

@Test
public void test_156_71()  throws Exception {
	try {
    Writer writer = new StringWriter();
    writer.close();
    StringEscapeUtils.escapeJavaScript(writer, "test");


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
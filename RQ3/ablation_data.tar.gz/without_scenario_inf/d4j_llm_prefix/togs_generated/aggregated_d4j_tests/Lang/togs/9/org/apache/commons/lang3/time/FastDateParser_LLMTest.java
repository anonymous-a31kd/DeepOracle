package org.apache.commons.lang3.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.text.ParsePosition;
import java.util.SortedMap;
import java.io.ObjectInputStream;
import java.util.Locale;
import java.text.ParseException;
import java.util.TimeZone;
import java.util.Comparator;
import java.util.Calendar;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentMap;
import java.util.List;
import java.io.Serializable;
import java.util.Date;
import java.util.TreeMap;
import java.util.Arrays;
import java.text.DateFormatSymbols;
import java.util.regex.Matcher;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FastDateParser_LLMTest extends FastDateParser_LLMTest_scaffolding {
    
@Test
public void test_140_01() throws Exception {
    FastDateParser parser = new FastDateParser("yyyy-MM-dd extra", TimeZone.getDefault(), Locale.getDefault());

    // Verify that the parser has been initialized with the correct pattern
    assertEquals("yyyy-MM-dd extra", parser.getPattern());
}

@Test
public void test_140_11() throws Exception {
    FastDateParser parser = new FastDateParser("yyyy-MM-dd", TimeZone.getDefault(), Locale.getDefault());
    
    // Verify that the FastDateParser is correctly initialized with the provided pattern, timezone, and locale
    assertEquals("yyyy-MM-dd", parser.getPattern());
    assertEquals(TimeZone.getDefault(), parser.getTimeZone());
    assertEquals(Locale.getDefault(), parser.getLocale());
}

@Test
public void test_140_31() throws Exception {
    FastDateParser parser = new FastDateParser("yyyy-MM-", TimeZone.getDefault(), Locale.getDefault());
    assertEquals("yyyy-MM-", parser.getPattern());
}

@Test
public void test_140_41() throws Exception {
    FastDateParser parser = new FastDateParser("yyyy-MM-dd HH:mm:ss", TimeZone.getDefault(), Locale.getDefault());

    assertEquals("yyyy-MM-dd HH:mm:ss", parser.getPattern());
    assertEquals(TimeZone.getDefault(), parser.getTimeZone());
    assertEquals(Locale.getDefault(), parser.getLocale());
}

}
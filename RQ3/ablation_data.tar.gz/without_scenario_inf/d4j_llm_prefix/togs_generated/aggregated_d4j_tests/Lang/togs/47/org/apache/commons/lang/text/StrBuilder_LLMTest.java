package org.apache.commons.lang.text;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.io.Writer;
import org.apache.commons.lang.SystemUtils;
import java.util.List;
import org.apache.commons.lang.ArrayUtils;
import java.util.Collection;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StrBuilder_LLMTest extends StrBuilder_LLMTest_scaffolding {
    
@Test
public void test_157_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadLeft(null, 5, ' ');
    assertEquals("     ", sb.toString());
}

@Test
public void test_157_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadLeft("test", 5, ' ');
    assertEquals(" test", sb.toString());
}

@Test
public void test_157_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadLeft(new Object() {
        @Override
        public String toString() {
            return null;
        }
    }, 5, ' ');
    assertEquals("     ", sb.toString());
}

@Test
public void test_157_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadLeft("test", 0, ' ');
    // Since the width is zero, the original StrBuilder should remain unchanged.
    assertEquals("", sb.toString());
}

@Test
public void test_157_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadLeft("longstring", 5, ' ');
}

@Test
public void test_157_51() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadLeft("short", 10, ' ');
    assertEquals("     short", sb.toString());
}

@Test
public void test_158_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight(null, 5, '-');
    assertEquals("-----", sb.toString());
}

@Test
public void test_158_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    Object obj = new Object() {
        @Override
        public String toString() {
            return null;
        }
    };
    sb.appendFixedWidthPadRight(obj, 5, '-');
    assertEquals("-----", sb.toString());
}

@Test
public void test_158_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("test", 5, '-');
    assertEquals("test-", sb.toString());
}

@Test
public void test_158_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("", 5, '-');
    assertEquals("-----", sb.toString());
}

@Test
public void test_158_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("test", 0, '-');
    assertEquals("", sb.toString());
}

}
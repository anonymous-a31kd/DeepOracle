package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Locale;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.nio.CharBuffer;
import java.util.regex.Pattern;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.commons.lang3.StringUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_162_01() throws Exception {
    // Test scenario: Compare two identical strings
    CharSequence cs1 = "abc";
    CharSequence cs2 = "abc";
    
    // Assert that the equals method returns true for identical strings
    assertTrue(StringUtils.equals(cs1, cs2));
}

@Test
public void test_162_11() throws Exception {
    String str = "test";
    // Focal method usage
    boolean result = StringUtils.equals(str, "test");
    // Assert statement for the expected output
    assertTrue(result);
}

@Test
public void test_162_21() throws Exception {
    // Test scenario: Compare two CharSequences for equality, case-sensitive
    CharSequence cs1 = "hello";
    CharSequence cs2 = "hello";
    
    // Using the focal method equals to perform the comparison
    boolean result = StringUtils.equals(cs1, cs2);
    
    // Assert statement to verify the expected outcome of the comparison
    assertTrue(result);
}

@Test
public void test_162_31() throws Exception {
    CharBuffer buffer1 = CharBuffer.wrap("test");
    CharBuffer buffer2 = CharBuffer.wrap("test");
    CharBuffer buffer3 = CharBuffer.wrap("different");

    // Assert that buffer1 and buffer2 are considered equal
    assertTrue(StringUtils.equals(buffer1, buffer2));

    // Assert that buffer1 and buffer3 are not considered equal
    assertFalse(StringUtils.equals(buffer1, buffer3));
}

@Test
public void test_162_41() throws Exception {
    StringBuilder builder = new StringBuilder("test");
    String str = "test";
    String differentStr = "different";
    
    // Check if StringBuilder and String with the same content are considered equal
    assertTrue(StringUtils.equals(builder, str));
    
    // Check if different strings are not considered equal
    assertFalse(StringUtils.equals(builder, differentStr));
}

@Test
public void test_162_51() throws Exception {
    CharBuffer shortBuffer = CharBuffer.wrap("short");
    CharBuffer longBuffer = CharBuffer.wrap("longer");
    
    // Use the equals method to compare the two CharBuffers
    boolean result = StringUtils.equals(shortBuffer, longBuffer);
    
    // Assert that the two buffers are not equal
    assertFalse(result);
}

}
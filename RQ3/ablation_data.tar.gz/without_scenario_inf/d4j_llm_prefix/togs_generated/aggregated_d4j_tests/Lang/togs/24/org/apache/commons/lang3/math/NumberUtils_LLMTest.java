package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_171_01() throws Exception {
    boolean result = NumberUtils.isNumber("123L");
    assertTrue(result);
}

@Test
public void test_171_11() throws Exception {
    boolean result = NumberUtils.isNumber("123.0L");
    assertTrue(result);
}

@Test
public void test_171_21() throws Exception {
    assertFalse(NumberUtils.isNumber("123E1L"));
}

@Test
public void test_171_31() throws Exception {
    assertFalse(NumberUtils.isNumber("123.0E1L"));
}

@Test
public void test_171_41() throws Exception {
    assertTrue(NumberUtils.isNumber("123.0"));
}

@Test
public void test_171_51() throws Exception {
    assertTrue(NumberUtils.isNumber("123E1"));
}

@Test
public void test_171_61() throws Exception {
    assertTrue(NumberUtils.isNumber("123.0E1"));
}

@Test
public void test_171_71() throws Exception {
    assertTrue(NumberUtils.isNumber("123l"));
}

@Test
public void test_171_81() throws Exception {
    assertFalse(NumberUtils.isNumber("123.0l"));
}

}
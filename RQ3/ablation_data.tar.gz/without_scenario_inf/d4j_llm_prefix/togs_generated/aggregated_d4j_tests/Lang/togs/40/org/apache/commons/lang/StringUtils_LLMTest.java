package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang.StringUtils;
import java.util.ArrayList;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_186_01() throws Exception {
    assertFalse(StringUtils.containsIgnoreCase(null, "abc"));
    assertFalse(StringUtils.containsIgnoreCase("abc", null));
    assertFalse(StringUtils.containsIgnoreCase(null, null));
}

@Test
public void test_186_11() throws Exception {
    assertTrue(StringUtils.containsIgnoreCase("", ""));
    assertTrue(StringUtils.containsIgnoreCase("abc", ""));
    assertFalse(StringUtils.containsIgnoreCase("", "abc"));
}

@Test
public void test_186_21() throws Exception {
    // Testing containsIgnoreCase method for various case scenarios
    assertTrue(StringUtils.containsIgnoreCase("abc", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("ABC", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("abc", "ABC"));
    assertTrue(StringUtils.containsIgnoreCase("aBc", "AbC"));
}

@Test
public void test_186_31() throws Exception {
    assertTrue(StringUtils.containsIgnoreCase("xyzabc", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("xyzABC", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("abcxyz", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("ABCxyz", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("xabcy", "abc"));
    assertTrue(StringUtils.containsIgnoreCase("xABCy", "abc"));
}

@Test
public void test_186_41() throws Exception {
    // Test case for StringUtils.containsIgnoreCase method with different case scenarios
    assertFalse(StringUtils.containsIgnoreCase("abc", "xyz"));
    assertFalse(StringUtils.containsIgnoreCase("ABC", "xyz"));
    assertFalse(StringUtils.containsIgnoreCase("abc", "XYZ"));
}

@Test
public void test_186_51() throws Exception {
    // Test case for containsIgnoreCase method
    assertTrue(StringUtils.containsIgnoreCase("a$b#c", "A$B#C"));
    assertTrue(StringUtils.containsIgnoreCase("123aBc456", "AbC"));
    assertTrue(StringUtils.containsIgnoreCase("äöü", "ÄÖÜ"));
}

@Test
public void test_186_61() throws Exception {
    assertTrue(StringUtils.containsIgnoreCase("abc", "abcdef"));
    assertTrue(StringUtils.containsIgnoreCase("ABC", "abcdef"));
}

}
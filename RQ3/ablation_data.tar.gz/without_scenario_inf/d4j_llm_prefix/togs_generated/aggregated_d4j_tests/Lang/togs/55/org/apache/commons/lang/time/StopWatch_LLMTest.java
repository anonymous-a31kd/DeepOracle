package org.apache.commons.lang.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.time.StopWatch;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StopWatch_LLMTest extends StopWatch_LLMTest_scaffolding {
    
@Test
public void test_196_01() throws Exception {
    StopWatch stopWatch = new StopWatch();
    stopWatch.start();
    stopWatch.stop();
    assertEquals(0, stopWatch.getTime());
}

@Test
public void test_196_11() throws Exception {
    StopWatch stopWatch = new StopWatch();
    stopWatch.start();
    stopWatch.suspend();
    stopWatch.stop();
    assertEquals(0, stopWatch.getTime()); // The stopwatch was suspended before stopping, so the time should be 0
}

}
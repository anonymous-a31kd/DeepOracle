package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;
import java.math.BigInteger;
import java.math.BigDecimal;
import org.apache.commons.lang3.math.NumberUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_173_01() throws Exception {
	try {
    NumberUtils.createNumber("123.45e6789");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_173_11() throws Exception {
    NumberUtils.createNumber("123e4567");
}

@Test
public void test_173_31() throws Exception {
    Number result = NumberUtils.createNumber("123.45e67");
    assertTrue(result instanceof Double);
    assertEquals(123.45e67, result.doubleValue(), 0.0);
}

@Test
public void test_173_41() throws Exception {
    NumberUtils.createNumber("123e45");
}

@Test
public void test_173_51() throws Exception {
    Number result = NumberUtils.createNumber("123.45");
    assertEquals(123.45, result.doubleValue(), 0.0001);
}

@Test
public void test_173_61() throws Exception {
    Number result = NumberUtils.createNumber("123");
    assertEquals(123, result.intValue());
}

}
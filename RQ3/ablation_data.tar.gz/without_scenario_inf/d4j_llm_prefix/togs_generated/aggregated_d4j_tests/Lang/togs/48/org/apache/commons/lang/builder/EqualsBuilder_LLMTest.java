package org.apache.commons.lang.builder;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import java.util.Arrays;
import java.util.Collection;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.math.BigDecimal;
import java.lang.reflect.Field;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class EqualsBuilder_LLMTest extends EqualsBuilder_LLMTest_scaffolding {
    
@Test
public void test_190_01() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    BigDecimal bd1 = new BigDecimal("123.456");
    BigDecimal bd2 = new BigDecimal("123.456");
    builder.append(bd1, bd2);
    assertTrue(builder.isEquals());
}

@Test
public void test_190_11() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    BigDecimal bd1 = new BigDecimal("123.456");
    BigDecimal bd2 = new BigDecimal("789.012");
    builder.append(bd1, bd2);
    assertFalse(builder.isEquals());
}

@Test
public void test_190_21() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    BigDecimal bd1 = new BigDecimal("123.456");
    BigDecimal bd2 = new BigDecimal("123.45600");
    builder.append(bd1, bd2);
    assertTrue(builder.isEquals());
}

@Test
public void test_190_31() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    String str1 = "test";
    String str2 = "test";
    builder.append(str1, str2);
    assertTrue(builder.isEquals());
}

@Test
public void test_190_41() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    BigDecimal bd = new BigDecimal("123.456");
    String str = "123.456";
    builder.append(bd, str);
    assertFalse(builder.isEquals());
}

@Test
public void test_190_51() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    BigDecimal bd = new BigDecimal("123.456");
    builder.append(bd, null);
    assertFalse(builder.isEquals());
}

@Test
public void test_190_61() throws Exception {
    EqualsBuilder builder = new EqualsBuilder();
    BigDecimal bd = new BigDecimal("123.456");
    builder.append(null, bd);
    assertFalse(builder.isEquals());
}

}
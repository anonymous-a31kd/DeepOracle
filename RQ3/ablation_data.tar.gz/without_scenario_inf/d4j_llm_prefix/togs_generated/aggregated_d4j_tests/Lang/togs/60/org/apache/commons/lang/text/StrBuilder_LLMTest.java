package org.apache.commons.lang.text;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.text.StrBuilder;
import java.util.Collection;
import java.util.List;
import java.util.Iterator;
import java.io.Writer;
import java.io.Reader;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StrBuilder_LLMTest extends StrBuilder_LLMTest_scaffolding {
    
@Test
public void test_198_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    
    // Check if the StrBuilder contains the character 'a'
    assertTrue(sb.contains('a'));
}

@Test
public void test_198_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");

    // Assert that the StrBuilder contains the character 'a'
    assertTrue(sb.contains('a'));
}

@Test
public void test_198_21() throws Exception {
    StrBuilder sb = new StrBuilder(10);
    sb.append("abc");
    sb.buffer[5] = 'x';
    
    assertTrue(sb.contains('x'));
}

@Test
public void test_198_31() throws Exception {
    StrBuilder sb = new StrBuilder();

}

@Test
public void test_198_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    // Verify that the StrBuilder contains the character 'b'
    assertTrue(sb.contains('b'));
}

@Test
public void test_198_51() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    assertTrue(sb.contains('a'));
}

@Test
public void test_199_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    sb.setLength(2);

}

@Test
public void test_199_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    sb.setLength(2);
    // Assert that the character 'c' is not found and returns -1
    assertEquals(-1, sb.indexOf('c', 0));
}

@Test
public void test_199_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    int index = sb.indexOf('b', 0);
    assertEquals(1, index);
}

@Test
public void test_199_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    
    // The focal method is indexOf(char ch, int startIndex)
    int index = sb.indexOf('b', 0);
    
    // Assert that 'b' is found at index 1
    assertEquals(1, index);
}

@Test
public void test_199_41() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    int index = sb.indexOf('b', 0);
    assertEquals(1, index);
}

@Test
public void test_199_51() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    int index = sb.indexOf('b', 0);
    assertEquals(1, index);
}

@Test
public void test_199_61() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.append("abc");
    sb.setLength(3);

}

}
package org.apache.commons.lang3.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.TimeZone;
import java.util.NoSuchElementException;
import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateUtils_LLMTest extends DateUtils_LLMTest_scaffolding {
    
@Test
public void test_169_01() throws Exception {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 10);
    cal2.set(Calendar.HOUR_OF_DAY, 10);
    boolean result = DateUtils.isSameLocalTime(cal1, cal2);
    assertTrue("The calendars should represent the same local time", result);
}

@Test
public void test_169_11() throws Exception {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 22);
    cal2.set(Calendar.HOUR_OF_DAY, 22);
    boolean result = DateUtils.isSameLocalTime(cal1, cal2);
    assertTrue("The calendars should represent the same local time", result);
}

@Test
public void test_169_21() throws Exception {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 0);
    cal2.set(Calendar.HOUR_OF_DAY, 12);
    boolean result = DateUtils.isSameLocalTime(cal1, cal2);
    assertFalse(result);
}

@Test
public void test_169_31() throws Exception {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();
    cal1.set(Calendar.HOUR_OF_DAY, 1);
    cal2.set(Calendar.HOUR_OF_DAY, 13);
    boolean result = DateUtils.isSameLocalTime(cal1, cal2);
    assertFalse(result);
}

@Test
public void test_169_51() throws Exception {
    Calendar cal1 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    Calendar cal2 = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"));
    cal1.set(Calendar.HOUR_OF_DAY, 10);
    cal2.set(Calendar.HOUR_OF_DAY, 10);
    boolean result = DateUtils.isSameLocalTime(cal1, cal2);
    assertFalse(result);
}

}
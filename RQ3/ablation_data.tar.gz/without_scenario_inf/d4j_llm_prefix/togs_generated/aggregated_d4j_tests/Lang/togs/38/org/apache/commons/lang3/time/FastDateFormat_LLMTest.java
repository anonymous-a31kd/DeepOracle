package org.apache.commons.lang3.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashMap;
import java.text.Format;
import org.apache.commons.lang3.Validate;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;
import java.text.FieldPosition;
import java.util.Map;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FastDateFormat_LLMTest extends FastDateFormat_LLMTest_scaffolding {
    
@Test
public void test_184_01() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance();
    Calendar calendar = Calendar.getInstance();
    StringBuffer buffer = new StringBuffer();
    
    format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT"), Locale.US);
    format.format(calendar, buffer);

    // The expected format is "yyyy-MM-dd" in GMT timezone for the current date
    SimpleDateFormat expectedFormat = new SimpleDateFormat("yyyy-MM-dd");
    expectedFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    String expectedDate = expectedFormat.format(calendar.getTime());

    assertEquals(expectedDate, buffer.toString());
}

@Test
public void test_184_11() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("GMT"), Locale.US);
    Calendar calendar = Calendar.getInstance();
    calendar.clear();
    StringBuffer buffer = new StringBuffer();

    format.format(calendar, buffer);
    
    assertEquals("1970-01-01", buffer.toString());
}

@Test
public void test_184_21() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("GMT"), Locale.US);
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("PST"));
    StringBuffer buffer = new StringBuffer();

    format.format(calendar, buffer);
}

@Test
public void test_184_41() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("America/New_York"), Locale.US);
    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
    calendar.set(2023, Calendar.MARCH, 12, 6, 30);

    StringBuffer buffer = new StringBuffer();
    format.format(calendar, buffer);
    
    assertEquals("2023-03-12 01:30:00", buffer.toString());
}

}
package org.apache.commons.lang.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang.StringUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_162_01() throws Exception {
    Number result = NumberUtils.createNumber("123L");
    assertEquals(123L, result.longValue());
}

@Test
public void test_162_11() throws Exception {
    Number result = NumberUtils.createNumber("-123L");
    assertEquals(Long.valueOf(-123L), result);
}

@Test
public void test_162_21() throws Exception {
    Number result = NumberUtils.createNumber("123");
    assertEquals(123, result.intValue());
}

@Test
public void test_162_31() throws Exception {
    Number result = NumberUtils.createNumber("-123");
    assertEquals(Integer.valueOf(-123), result);
}

@Test
public void test_162_71() throws Exception {
    assertNull(NumberUtils.createNumber(null));
}

}
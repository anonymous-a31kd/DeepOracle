package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Locale;
import java.util.ArrayList;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_176_01() throws Exception {
    char[] searchChars = {'a', 'b'};
    boolean result = StringUtils.containsAny(null, searchChars);
    assertFalse(result);
}

@Test
public void test_176_11() throws Exception {
    char[] searchChars = {'a', 'b'};
    boolean result = StringUtils.containsAny("", searchChars);
    assertFalse(result);
}

@Test
public void test_176_31() throws Exception {
    // The focal method is StringUtils.containsAny
    // According to the javadoc, if the search array is null or zero length, it should return false.
    boolean result = StringUtils.containsAny("abc", new char[0]);
    assertFalse(result);
}

@Test
public void test_176_41() throws Exception {
    char[] searchChars = {'x', 'y', 'z'};
    boolean result = StringUtils.containsAny("abcxyz", searchChars);
    assertTrue(result);
}

@Test
public void test_176_51() throws Exception {
    char[] searchChars = {'\uD800', 'b'};
    boolean result = StringUtils.containsAny("a\uD800", searchChars);
    assertTrue(result);
}

@Test
public void test_176_61() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00', 'b'};
    boolean result = StringUtils.containsAny("a\uD800\uDC00", searchChars);
    assertTrue(result);
}

@Test
public void test_176_71() throws Exception {
    char[] searchChars = {'\uD800', 'b'};
    boolean result = StringUtils.containsAny("a\uD800c", searchChars);
    assertTrue(result);
}

@Test
public void test_176_81() throws Exception {
    char[] searchChars = {'\uD800', 'b'};
    boolean result = StringUtils.containsAny("abc\uD800", searchChars);
    assertTrue(result);
}

@Test
public void test_176_91() throws Exception {
    char[] searchChars = {'a', '\uD800'};
    boolean result = StringUtils.containsAny("\uD800", searchChars);
    assertTrue(result);
}

@Test
public void test_177_01() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC00'};
    int result = StringUtils.indexOfAny("\uD800\uDC00", searchChars);
    assertEquals(0, result);
}

@Test
public void test_177_11() throws Exception {
    char[] searchChars = new char[]{'\uD800'};
    int result = StringUtils.indexOfAny("\uD800", searchChars);
    assertEquals(0, result);
}

@Test
public void test_177_21() throws Exception {
    char[] searchChars = new char[]{'\uDC00'};
    int result = StringUtils.indexOfAny("\uDC00", searchChars);
    assertEquals(0, result);
}

@Test
public void test_177_31() throws Exception {

    char[] searchChars = new char[]{'a', '\uD800', '\uDC00', 'b'};
    int result = StringUtils.indexOfAny("x\uD800\uDC00y", searchChars);
    assertEquals(1, result);
}

@Test
public void test_177_41() throws Exception {
    char[] searchChars = new char[]{'a', 'b', 'c'};
    int result = StringUtils.indexOfAny("xyzabc", searchChars);
    assertEquals(3, result);
}

@Test
public void test_177_51() throws Exception {

    char[] searchChars = new char[]{'a', 'b'};
    int result = StringUtils.indexOfAny("", searchChars);
    
    // Assert that the result is -1 since the input string is empty
    assertEquals(-1, result);
}

@Test
public void test_177_61() throws Exception {

    char[] searchChars = new char[]{};
    int result = StringUtils.indexOfAny("abc", searchChars);
    
    // According to the javadoc, a null or zero length search array should return -1.
    assertEquals(-1, result);
}

@Test
public void test_178_01() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC00'};
    int result = StringUtils.indexOfAnyBut("abc", searchChars);
    assertEquals(0, result);
}

@Test
public void test_178_11() throws Exception {
    char[] searchChars = new char[]{'\uD800', '\uDC00'};
    int result = StringUtils.indexOfAnyBut("\uD800\uDC00abc", searchChars);
    assertEquals(2, result); // The first character not in the surrogate pair is 'a' at index 2
}

@Test
public void test_178_21() throws Exception {

    char[] searchChars = new char[]{'\uD800', '\uDC01'};
    int result = StringUtils.indexOfAnyBut("\uD800\uDC00abc", searchChars);
    
    assertEquals(2, result);
}

@Test
public void test_178_31() throws Exception {

    char[] searchChars = new char[]{'\uD800'};
    int result = StringUtils.indexOfAnyBut("\uD800\uDC00abc", searchChars);
    // The first character not matching '\uD800' is 'a' at index 2
    assertEquals(2, result);
}

@Test
public void test_178_41() throws Exception {

    char[] searchChars = new char[]{'a', 'b', 'c'};
    int result = StringUtils.indexOfAnyBut("def", searchChars);
    
    // Assert that the result is 0, since 'd' is not in the searchChars array
    assertEquals(0, result);
}

@Test
public void test_178_51() throws Exception {

    char[] searchChars = new char[]{'a', 'b'};
    int result = StringUtils.indexOfAnyBut("", searchChars);

    // Assert statement based on the javadoc comment which states that an empty CharSequence should return -1
    assertEquals(-1, result);
}

@Test
public void test_178_61() throws Exception {
    char[] searchChars = new char[]{};
    int result = StringUtils.indexOfAnyBut("abc", searchChars);
    assertEquals(-1, result);
}

}
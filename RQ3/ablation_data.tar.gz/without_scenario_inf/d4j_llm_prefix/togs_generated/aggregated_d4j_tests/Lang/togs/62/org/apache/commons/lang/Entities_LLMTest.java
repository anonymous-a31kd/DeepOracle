package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.TreeMap;
import java.io.StringWriter;
import java.util.HashMap;
import java.io.Writer;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Entities_LLMTest extends Entities_LLMTest_scaffolding {
    
@Test
public void test_201_01() throws Exception {
    Entities entities = new Entities();
    String input = "&#1234;";
    String result = entities.unescape(input);
    assertEquals("\u04D2", result);  // Unicode for decimal 1234
}

@Test
public void test_201_11() throws Exception {
    Entities entities = new Entities();
    String input = "&#x1A2B;";
    String result = entities.unescape(input);
    assertEquals("\u1A2B", result);
}

@Test
public void test_201_21() throws Exception {
    Entities entities = new Entities();
    String input = "&#65536;";
    entities.unescape(input);
}

@Test
public void test_201_31() throws Exception {
    Entities entities = new Entities();
    String input = "&#x10000;";
    String expectedOutput = "\uD800\uDC00"; // Unicode representation for the character corresponding to 0x10000

    String result = entities.unescape(input);

    assertEquals(expectedOutput, result);
}

@Test
public void test_201_41() throws Exception {
    Entities entities = new Entities();
    String input = "&#65535;";
    String result = entities.unescape(input);
    assertEquals("\uFFFF", result);
}

@Test
public void test_201_51() throws Exception {
    Entities entities = new Entities();
    String input = "&#xFFFF;";
    String result = entities.unescape(input);
    assertEquals("\uFFFF", result);
}

@Test
public void test_201_61() throws Exception {
    Entities entities = new Entities();
    String input = "&#invalid;";
    String result = entities.unescape(input);
    assertEquals("&#invalid;", result);
}

@Test
public void test_201_71() throws Exception {
    Entities entities = new Entities();
    String input = "&#xinvalid;";
    String result = entities.unescape(input);
    assertEquals("&#xinvalid;", result);
}

@Test
public void test_202_01() throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#x1F600;");
    assertEquals("\uD83D\uDE00", writer.toString());
}

@Test
public void test_202_11() throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#x1FFFF;");
    assertEquals("", writer.toString());
}

@Test
public void test_202_21()  throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#131071;");
}

@Test
public void test_202_31() throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#xZZZ;");
    assertEquals("", writer.toString());
}

@Test
public void test_202_41() throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#ABC;");

    // Since "&#ABC;" is not a valid numeric character reference, the expected behavior
    // would be that it writes the input as-is to the writer. Thus, we expect the output
    // to still be "&#ABC;".
    assertEquals("&#ABC;", writer.toString());
}

@Test
public void test_202_51() throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#xA9;");
    assertEquals("©", writer.toString());
}

@Test
public void test_202_61() throws Exception {
    Entities entities = new Entities();
    StringWriter writer = new StringWriter();
    entities.unescape(writer, "&#169;");
    assertEquals("©", writer.toString());
}

}
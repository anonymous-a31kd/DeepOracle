package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.math.NumberUtils;
import java.math.BigInteger;
import java.lang.reflect.Array;
import org.apache.commons.lang3.StringUtils;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_153_01() throws Exception {
    assertEquals(new BigDecimal("123.4567890"), NumberUtils.createNumber("123.4567890"));
    assertEquals(new BigDecimal("0.1234567"), NumberUtils.createNumber("0.1234567"));
    assertEquals(new BigDecimal("-1.0000000"), NumberUtils.createNumber("-1.0000000"));
}

@Test
public void test_153_11() throws Exception {
    assertEquals(new BigDecimal("123.45"), NumberUtils.createNumber("123.45"));
    assertEquals(new BigDecimal("0.1"), NumberUtils.createNumber("0.1"));
    assertEquals(new BigDecimal("-999.999999"), NumberUtils.createNumber("-999.999999"));
}

@Test
public void test_153_21() throws Exception {
    Number number1 = NumberUtils.createNumber("123.45678901");
    Number number2 = NumberUtils.createNumber("0.12345678");
    Number number3 = NumberUtils.createNumber("-1.00000000");

    assertEquals(new BigDecimal("123.45678901"), number1);
    assertEquals(new BigDecimal("0.12345678"), number2);
    assertEquals(new BigDecimal("-1.00000000"), number3);
}

@Test
public void test_153_31() throws Exception {
    assertEquals(new BigDecimal("123.456789012345"), NumberUtils.createNumber("123.456789012345"));
    assertEquals(new BigDecimal("0.1234567890123456"), NumberUtils.createNumber("0.1234567890123456"));
    assertEquals(new BigDecimal("-999.9999999999999"), NumberUtils.createNumber("-999.9999999999999"));
}

@Test
public void test_153_41() throws Exception {
    assertEquals(new BigDecimal("123.45678901234567890"), NumberUtils.createNumber("123.45678901234567890"));
    assertEquals(new BigDecimal("0.123456789012345678"), NumberUtils.createNumber("0.123456789012345678"));
    assertEquals(new BigDecimal("-999.999999999999999"), NumberUtils.createNumber("-999.999999999999999"));
}

@Test
public void test_153_61() throws Exception {
    assertEquals(1.2345678e10, NumberUtils.createNumber("1.2345678e10").doubleValue(), 0);
    assertEquals(1.23456789e10, NumberUtils.createNumber("1.23456789e10").doubleValue(), 0);
    assertEquals(1.2345678901234567e10, NumberUtils.createNumber("1.2345678901234567e10").doubleValue(), 0);
}

}
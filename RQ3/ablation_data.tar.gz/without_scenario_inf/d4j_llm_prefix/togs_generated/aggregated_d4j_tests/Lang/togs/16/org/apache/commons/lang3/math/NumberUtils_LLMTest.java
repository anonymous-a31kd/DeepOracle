package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_141_01() throws Exception {
    assertEquals(26, NumberUtils.createNumber("0x1A").intValue());
    assertEquals(-26, NumberUtils.createNumber("-0x1A").intValue());
}

@Test
public void test_141_11() throws Exception {
    assertEquals(Long.valueOf(26L), NumberUtils.createNumber("0X1A"));
    assertEquals(Long.valueOf(-26L), NumberUtils.createNumber("-0X1A"));
}

@Test
public void test_141_21() throws Exception {
    assertEquals(26, NumberUtils.createNumber("0x1A").intValue());
    assertEquals(26, NumberUtils.createNumber("0X1A").intValue());
    assertEquals(-26, NumberUtils.createNumber("-0x1A").intValue());
    assertEquals(-26, NumberUtils.createNumber("-0X1A").intValue());
}

}
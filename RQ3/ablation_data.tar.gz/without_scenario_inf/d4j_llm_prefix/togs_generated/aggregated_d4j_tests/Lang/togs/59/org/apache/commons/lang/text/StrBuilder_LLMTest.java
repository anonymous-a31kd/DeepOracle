package org.apache.commons.lang.text;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.text.StrBuilder;
import java.util.Collection;
import java.util.List;
import java.util.Iterator;
import java.io.Writer;
import java.io.Reader;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StrBuilder_LLMTest extends StrBuilder_LLMTest_scaffolding {
    
@Test
public void test_197_01() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("abcdef", 4, '-');
    assertEquals("abcd", sb.toString());
}

@Test
public void test_197_11() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("abcd", 4, '-');
    
    // Verify that the appended string is "abcd", as it fits exactly into the width of 4
    assertEquals("abcd", sb.toString());
}

@Test
public void test_197_21() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.setNullText("NULL");
    sb.appendFixedWidthPadRight(null, 4, '-');
    assertEquals("NULL-", sb.toString());
}

@Test
public void test_197_31() throws Exception {
    StrBuilder sb = new StrBuilder();
    sb.appendFixedWidthPadRight("ab", 4, '-');
    assertEquals("ab--", sb.toString());
}

@Test
public void test_197_41() throws Exception {
    StrBuilder sb = new StrBuilder("initial");
    sb.appendFixedWidthPadRight("abc", 0, '-');
    assertEquals("initial", sb.toString());
}

}
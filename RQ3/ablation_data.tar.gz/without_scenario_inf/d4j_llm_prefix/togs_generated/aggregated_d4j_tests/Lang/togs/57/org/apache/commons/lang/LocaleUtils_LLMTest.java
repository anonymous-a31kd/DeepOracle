package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.List;
import java.util.Collections;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocaleUtils_LLMTest extends LocaleUtils_LLMTest_scaffolding {
    
@Test
public void test_161_01() throws Exception {
    assertFalse(LocaleUtils.isAvailableLocale(null));
}

@Test
public void test_161_11() throws Exception {
    boolean result = LocaleUtils.isAvailableLocale(Locale.getDefault());
    assertTrue("The default locale should be available", result);
}

@Test
public void test_161_21() throws Exception {
    assertTrue(LocaleUtils.isAvailableLocale(Locale.US));
}

@Test
public void test_161_31() throws Exception {
    boolean result = LocaleUtils.isAvailableLocale(new Locale("xx", "XX"));
    assertFalse(result);
}

@Test
public void test_161_41() throws Exception {
    boolean result = LocaleUtils.isAvailableLocale(Locale.ENGLISH);
    assertTrue(result);
}

@Test
public void test_161_51() throws Exception {
    boolean result = LocaleUtils.isAvailableLocale(new Locale("zz", "ZZ"));
    assertFalse(result);
}

}
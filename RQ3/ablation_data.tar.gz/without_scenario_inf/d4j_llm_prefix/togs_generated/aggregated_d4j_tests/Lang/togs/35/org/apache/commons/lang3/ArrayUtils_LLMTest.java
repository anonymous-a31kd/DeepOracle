package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.builder.EqualsBuilder;
import java.util.HashMap;
import org.apache.commons.lang3.builder.ToStringStyle;
import java.lang.reflect.Array;
import org.apache.commons.lang3.builder.ToStringBuilder;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArrayUtils_LLMTest extends ArrayUtils_LLMTest_scaffolding {
    
@Test
public void test_144_01() throws Exception {
    String[] array = {"a", "b"};
    String[] result = ArrayUtils.add(array, "c");
    assertArrayEquals(new String[]{"a", "b", "c"}, result);
}

@Test
public void test_144_11() throws Exception {
    String[] array = null;
    String[] result = ArrayUtils.add(array, "a");
    assertArrayEquals(new String[]{"a"}, result);
}

@Test
public void test_144_31() throws Exception {
    String[] array = new String[0];
    String[] result = ArrayUtils.add(array, "a");
    assertArrayEquals(new String[] {"a"}, result);
}

@Test
public void test_144_41() throws Exception {
    String[] array = {"a", "b"};
    String[] result = ArrayUtils.add(array, null);

    // Assert that the result is as expected: {"a", "b", null}
    assertArrayEquals(new String[]{"a", "b", null}, result);
}

@Test
public void test_145_01() throws Exception {
    Object[] result = ArrayUtils.add((Object[]) null, 0, null);
    assertArrayEquals(new Object[]{null}, result);
}

@Test
public void test_145_11() throws Exception {
    String element = "test";
    String[] result = ArrayUtils.add(null, 0, element);
    assertArrayEquals(new String[]{"test"}, result);
}

@Test
public void test_145_21() throws Exception {
    String[] array = new String[] {"existing"};
    String[] result = ArrayUtils.add(array, 1, null);
    assertArrayEquals(new String[] {"existing", null}, result);
}

@Test
public void test_145_31() throws Exception {
    String[] array = new String[] {"existing"};
    String element = "new";
    String[] result = ArrayUtils.add(array, 1, element);
    assertArrayEquals(new String[] {"existing", "new"}, result);
}

@Test
public void test_145_41() throws Exception {
    String[] array = new String[0];
    String element = "new";
    String[] result = ArrayUtils.add(array, 0, element);

    // Assert that the result array has a length of 1 and contains the new element at index 0
    assertArrayEquals(new String[]{"new"}, result);
}

}
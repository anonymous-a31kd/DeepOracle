package org.apache.commons.lang.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.TimeZone;
import org.apache.commons.lang.Validate;
import java.text.DateFormatSymbols;
import java.util.List;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.io.ObjectInputStream;
import java.text.FieldPosition;
import java.util.HashMap;
import java.util.Locale;
import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.util.Map;
import java.text.Format;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FastDateFormat_LLMTest extends FastDateFormat_LLMTest_scaffolding {
    
@Test
public void test_191_01() throws Exception {
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, null);
    assertNotNull(format);
}

@Test
public void test_191_11() throws Exception {
    Locale testLocale = Locale.FRANCE;
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.MEDIUM, null, testLocale);

    // Assert that the locale of the FastDateFormat object is as expected.
    assertEquals(testLocale, format.getLocale());
}

@Test
public void test_191_21() throws Exception {
    TimeZone testZone = TimeZone.getTimeZone("GMT");
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.LONG, testZone, null);
    
    assertEquals("Expected time zone to be GMT", testZone, format.getTimeZone());
}

@Test
public void test_191_31() throws Exception {
    TimeZone testZone = TimeZone.getTimeZone("PST");
    Locale testLocale = Locale.JAPAN;
    FastDateFormat format = FastDateFormat.getDateInstance(FastDateFormat.FULL, testZone, testLocale);
    
    assertNotNull("FastDateFormat instance should not be null", format);
    assertEquals("Locale should be JAPAN", Locale.JAPAN, format.getLocale());
    assertEquals("TimeZone should be PST", testZone, format.getTimeZone());
}

@Test
public void test_191_41() throws Exception {
    FastDateFormat format1 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, null);
    FastDateFormat format2 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, null);

    assertEquals(format1, format2);
}

@Test
public void test_191_51() throws Exception {
    FastDateFormat format1 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, Locale.US);
    FastDateFormat format2 = FastDateFormat.getDateInstance(FastDateFormat.SHORT, null, Locale.UK);

    // Assert that the patterns for the US and UK locales are not the same
    assertNotEquals(format1.getPattern(), format2.getPattern());
}

@Test
public void test_192_01() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.SHORT,
    FastDateFormat.SHORT,
    TimeZone.getDefault(),
    null
    );
    
    // Verify that the format object is not null
    assertNotNull(format);
}

@Test
public void test_192_11() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
        FastDateFormat.MEDIUM,
        FastDateFormat.MEDIUM,
        TimeZone.getTimeZone("GMT"),
        Locale.FRANCE
    );
    
    // Assert that the format is not null and has the correct locale and timezone
    assertNotNull(format);
    assertEquals(Locale.FRANCE, format.getLocale());
    assertEquals(TimeZone.getTimeZone("GMT"), format.getTimeZone());
}

@Test
public void test_192_21() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
        FastDateFormat.LONG,
        FastDateFormat.LONG,
        null,
        Locale.JAPAN
    );
    
    assertNotNull("The FastDateFormat instance should not be null", format);
    assertEquals("The locale should be JAPAN", Locale.JAPAN, format.getLocale());
}

@Test
public void test_192_31() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.FULL,
    FastDateFormat.FULL,
    null,
    null
    );
}

@Test
public void test_192_41() throws Exception {
    FastDateFormat format = FastDateFormat.getDateTimeInstance(
    FastDateFormat.SHORT,
    FastDateFormat.FULL,
    TimeZone.getDefault(),
    Locale.getDefault()
    );

    // Assert that the format is correctly initialized with the default time zone and locale
    assertEquals(TimeZone.getDefault(), format.getTimeZone());
    assertEquals(Locale.getDefault(), format.getLocale());
}

}
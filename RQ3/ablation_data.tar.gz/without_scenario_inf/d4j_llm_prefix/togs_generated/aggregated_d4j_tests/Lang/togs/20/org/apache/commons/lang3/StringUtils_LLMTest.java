package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.Iterator;
import java.util.List;
import java.util.Arrays;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_167_01() throws Exception {
    String result = StringUtils.join(null, ",", 0, 1);
    assertNull(result);
}

@Test
public void test_167_11() throws Exception {
    String result = StringUtils.join(new Object[]{"a", "b"}, ",", 1, 1);
    assertEquals("", result);
}

@Test
public void test_167_21() throws Exception {
    String result = StringUtils.join(new Object[]{"test"}, ",", 0, 1);
    assertEquals("test", result);
}

@Test
public void test_167_31() throws Exception {
    String result = StringUtils.join(new Object[]{"a", "bb", "ccc"}, "-", 0, 3);
    assertEquals("a-bb-ccc", result);
}

@Test
public void test_167_41() throws Exception {
    String result = StringUtils.join(new Object[]{null, "b", null}, "|", 0, 3);
    assertEquals("|b|", result);
}

@Test
public void test_167_51() throws Exception {
    String result = StringUtils.join(new Object[]{"verylongstring1", "verylongstring2"}, ",", 0, 2);
    assertEquals("verylongstring1,verylongstring2", result);
}

@Test
public void test_167_61() throws Exception {
    String result = StringUtils.join(new Object[]{"a", "b", "c", "d"}, ":", 1, 3);
    assertEquals("b:c", result);
}

@Test
public void test_167_71() throws Exception {
    String result = StringUtils.join(new Object[]{"x", "y", "z"}, "", 0, 3);
    assertEquals("xyz", result);
}

@Test
public void test_167_81() throws Exception {
    String result = StringUtils.join(new Object[]{1, 2, 3}, null, 0, 3);
    assertEquals("123", result);
}

@Test
public void test_168_01() throws Exception {
    String result = StringUtils.join(null, ',', 0, 0);
    assertNull(result);
}

@Test
public void test_168_11() throws Exception {
    String result = StringUtils.join(new Object[]{"a", "b"}, ',', 1, 1);
    assertEquals("", result);
}

@Test
public void test_168_21() throws Exception {
    String result = StringUtils.join(new Object[]{"test"}, ',', 0, 1);
    assertEquals("test", result);
}

@Test
public void test_168_31() throws Exception {
    String result = StringUtils.join(new Object[]{"a", "b", "c"}, ',', 0, 3);
    assertEquals("a,b,c", result);
}

@Test
public void test_168_41() throws Exception {
    String result = StringUtils.join(new Object[]{null, "b", null}, ',', 0, 3);
    assertEquals(",b,", result);
}

@Test
public void test_168_51() throws Exception {
    String result = StringUtils.join(new Object[]{"longstring1", "longstring2"}, ',', 0, 2);
    assertEquals("longstring1,longstring2", result);
}

@Test
public void test_168_61() throws Exception {
    String result = StringUtils.join(new Object[]{"a", "b", "c", "d"}, ',', 1, 3);
    assertEquals("b,c", result);
}

}
package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_189_51() throws Exception {
    Number result = NumberUtils.createNumber("5");
    assertEquals(5, result.intValue());
}

@Test
public void test_189_61() throws Exception {
    Number result = NumberUtils.createNumber("123");
    assertEquals(123, result.intValue());
}

@Test
public void test_189_81() throws Exception {
	try {
    NumberUtils.createNumber(null);


		fail("Expecting exception"); } catch (Exception e) { }
	}

}
package org.apache.commons.lang3.text.translate;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class CharSequenceTranslator_LLMTest extends CharSequenceTranslator_LLMTest_scaffolding {
    
@Test
public void test_156_01() throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        @Override
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            out.write(input.charAt(index));
            return 1;
        }
    };
    StringWriter writer = new StringWriter();
    translator.translate("abc", writer);
    assertEquals("abc", writer.toString());
}

@Test
public void test_156_11() throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        @Override
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            out.write(input.charAt(index));
            out.write(input.charAt(index + 1));
            return 2;
        }
    };
    StringWriter writer = new StringWriter();
    translator.translate("abcd", writer);
    assertEquals("ab", writer.toString());
}

@Test
public void test_156_21() throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        @Override
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            out.write(input.charAt(index));
            out.write(input.charAt(index + 1));
            return 2;
        }
    };
    StringWriter writer = new StringWriter();
    translator.translate("\uD800\uDC00", writer);
    
    // Assert that the surrogate pair was correctly written to the writer
    assertEquals("\uD800\uDC00", writer.toString());
}

@Test
public void test_156_31()  throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        @Override
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            if (index % 2 == 0) {
                out.write(input.charAt(index));
                return 1;
            } else {
                out.write(input.charAt(index));
                out.write(input.charAt(index + 1));
                return 2;
            }
        }
    };
    StringWriter writer = new StringWriter();
    translator.translate("a\uD800\uDC00b\uD800\uDC00", writer);
    assertEquals("a\uD800\uDC00b\uD800\uDC00", writer.toString());
}

@Test
public void test_156_41() throws Exception {
    CharSequenceTranslator translator = new CharSequenceTranslator() {
        @Override
        public int translate(CharSequence input, int index, Writer out) throws IOException {
            return 0;
        }
    };
    StringWriter writer = new StringWriter();
    translator.translate("abc", writer);
    assertEquals("abc", writer.toString());
}

}
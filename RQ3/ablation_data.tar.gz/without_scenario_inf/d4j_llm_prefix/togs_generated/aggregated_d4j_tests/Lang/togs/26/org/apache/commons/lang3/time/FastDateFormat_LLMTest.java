package org.apache.commons.lang3.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.TimeZone;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.FieldPosition;
import org.apache.commons.lang3.Validate;
import java.util.List;
import java.util.HashMap;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.text.Format;
import java.text.ParsePosition;
import java.util.Map;
import java.util.ArrayList;
import java.text.DateFormatSymbols;
import java.util.Date;
import java.io.ObjectInputStream;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class FastDateFormat_LLMTest extends FastDateFormat_LLMTest_scaffolding {
    
@Test
public void test_172_01() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance();
    Date date = new Date();
    String result = format.format(date);

    // Assert that the formatted date string is not null or empty
    assertNotNull("The formatted date should not be null", result);
    assertFalse("The formatted date should not be empty", result.isEmpty());
}

@Test
public void test_172_11() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getDefault(), Locale.US);
    Date date = new Date();
    String result = format.format(date);
    
    // Assert that the result matches the expected pattern
    assertTrue(result.matches("\\d{4}-\\d{2}-\\d{2}"));
}

@Test
public void test_172_21() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getDefault(), Locale.JAPANESE);
    Date date = new Date();
    String result = format.format(date);
    
    // Assert the result matches the expected format "yyyy-MM-dd"
    assertTrue(result.matches("\\d{4}-\\d{2}-\\d{2}"));
}

@Test
public void test_172_31() throws Exception {
    TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", tz, Locale.FRENCH);
    Date date = new Date();
    String result = format.format(date);

    // Verify that the formatted date string is not null or empty
    assertNotNull("The formatted date string should not be null", result);
    assertFalse("The formatted date string should not be empty", result.isEmpty());
}

@Test
public void test_172_51() throws Exception {
    FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getDefault(), Locale.GERMAN);
    Calendar cal = new GregorianCalendar(2023, Calendar.JANUARY, 1);
    Date date = cal.getTime();
    String result = format.format(date);
    
    // Assert that the formatted date string is as expected
    assertEquals("2023-01-01", result);
}

}
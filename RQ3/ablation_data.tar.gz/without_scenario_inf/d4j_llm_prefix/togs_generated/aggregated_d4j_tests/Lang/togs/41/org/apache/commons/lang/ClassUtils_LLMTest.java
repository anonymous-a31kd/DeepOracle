package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashMap;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import org.apache.commons.lang.ClassUtils;
import java.util.Map;
import java.util.List;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ClassUtils_LLMTest extends ClassUtils_LLMTest_scaffolding {
    
@Test
public void test_148_01() throws Exception {
    String result = ClassUtils.getPackageName(null, "default");
    assertEquals("default", result);
}

@Test
public void test_148_11() throws Exception {
    String result = ClassUtils.getPackageName(String.class, "default");
    assertEquals("java.lang", result);
}

@Test
public void test_148_21() throws Exception {
    class Inner {}
    String result = ClassUtils.getPackageName(Inner.class, "default");

    assertEquals("default", result);
}

@Test
public void test_148_31() throws Exception {
    String[] array = new String[0];
    String result = ClassUtils.getPackageName(array.getClass(), "default");
    assertEquals("java.lang", result);
}

@Test
public void test_148_41() throws Exception {
    String[][] array = new String[0][0];
    String result = ClassUtils.getPackageName(array.getClass(), "default");
    assertEquals("default", result);
}

@Test
public void test_148_51() throws Exception {
    int[] array = new int[0];
    String result = ClassUtils.getPackageName(array.getClass(), "default");
    assertEquals("default", result);
}

@Test
public void test_149_11() throws Exception {
    String result = ClassUtils.getShortClassName("");
    assertEquals("", result);
}

@Test
public void test_149_21() throws Exception {
    String result = ClassUtils.getShortClassName("java.lang.String");
    assertEquals("String", result);
}

@Test
public void test_149_31() throws Exception {
    String result = ClassUtils.getShortClassName("[Ljava.lang.String;");
    assertEquals("String[]", result);
}

@Test
public void test_149_41() throws Exception {
    String result = ClassUtils.getShortClassName("[[[Ljava.lang.String;");
    assertEquals("String", result);
}

@Test
public void test_149_51() throws Exception {
    String result = ClassUtils.getShortClassName("[I");
    assertEquals("I", result);
}

@Test
public void test_149_61() throws Exception {
    String result = ClassUtils.getShortClassName("[[[D");
    assertEquals("D", result);
}

@Test
public void test_149_71() throws Exception {
    String result = ClassUtils.getShortClassName("java.util.Map$Entry");
    assertEquals("Map$Entry", result);
}

@Test
public void test_149_81() throws Exception {
    String result = ClassUtils.getShortClassName("[Ljava.util.Map$Entry;");
    assertEquals("Map$Entry", result);
}

@Test
public void test_149_91() throws Exception {
    String result = ClassUtils.getShortClassName("int");
    assertEquals("int", result);
}

@Test
public void test_149_101() throws Exception {
    String shortClassName = ClassUtils.getShortClassName("I");
    assertEquals("I", shortClassName);
}

}
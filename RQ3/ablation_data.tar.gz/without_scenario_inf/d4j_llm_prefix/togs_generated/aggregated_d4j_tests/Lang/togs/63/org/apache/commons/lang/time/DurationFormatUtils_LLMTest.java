package org.apache.commons.lang.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.Date;
import java.util.Calendar;
import org.apache.commons.lang.time.DurationFormatUtils.Token;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.apache.commons.lang.StringUtils;
import java.util.TimeZone;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DurationFormatUtils_LLMTest extends DurationFormatUtils_LLMTest_scaffolding {
    
@Test
public void test_203_01() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.set(2023, Calendar.FEBRUARY, 1);
    long startMillis = cal.getTimeInMillis();
    cal.set(Calendar.DAY_OF_MONTH, 28);
    long endMillis = cal.getTimeInMillis();
    String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, "M'd'D'H'm's'S'", true, TimeZone.getDefault());
    assertEquals("0d27H0m0s0S", result);
}

@Test
public void test_203_11() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.set(2023, Calendar.JANUARY, 1);
    long startMillis = cal.getTimeInMillis();
    cal.set(Calendar.MONTH, Calendar.FEBRUARY);
    cal.set(Calendar.DAY_OF_MONTH, 1);
    long endMillis = cal.getTimeInMillis();
    String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, "M'd'D'H'm's'S'", true, TimeZone.getDefault());
    assertEquals("1d0H0m0s0S", result);
}

@Test
public void test_203_21() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.set(2023, Calendar.APRIL, 1);
    long startMillis = cal.getTimeInMillis();
    cal.set(Calendar.MONTH, Calendar.MAY);
    cal.set(Calendar.DAY_OF_MONTH, 1);
    long endMillis = cal.getTimeInMillis();
    String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, "M'd'D'H'm's'S'", true, TimeZone.getDefault());
    assertEquals("1d0H0m0s0S", result);
}

@Test
public void test_203_31() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.set(2023, Calendar.JANUARY, 15);
    long startMillis = cal.getTimeInMillis();
    cal.set(Calendar.MONTH, Calendar.MARCH);
    cal.set(Calendar.DAY_OF_MONTH, 10);
    long endMillis = cal.getTimeInMillis();
    String formattedPeriod = DurationFormatUtils.formatPeriod(startMillis, endMillis, "M'd'D'H'm's'S'", true, TimeZone.getDefault());
    assertEquals("1d23H59m59s999S", formattedPeriod);
}

@Test
public void test_203_41() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.set(2020, Calendar.FEBRUARY, 1);
    long startMillis = cal.getTimeInMillis();
    cal.set(Calendar.DAY_OF_MONTH, 29);
    long endMillis = cal.getTimeInMillis();
    String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, "M'd'D'H'm's'S'", true, TimeZone.getDefault());
    assertEquals("0d28H0m0s0S", result);
}

@Test
public void test_203_51() throws Exception {
    Calendar cal = Calendar.getInstance();
    cal.set(2023, Calendar.MARCH, 10);
    long startMillis = cal.getTimeInMillis();
    cal.set(Calendar.MONTH, Calendar.JANUARY);
    cal.set(Calendar.DAY_OF_MONTH, 15);
    long endMillis = cal.getTimeInMillis();
    String result = DurationFormatUtils.formatPeriod(startMillis, endMillis, "M'd'D'H'm's'S'", true, TimeZone.getDefault());
    assertEquals("2'd'5'H'0'm'0's'0'S'", result);
}

@Test
public void test_204_01() throws Exception {
    Token[] tokens = new Token[]{
        new Token(DurationFormatUtils.y, 2),
        new Token(new StringBuffer("Y")),
        new Token(DurationFormatUtils.M, 2)
    };
    String result = DurationFormatUtils.format(tokens, 5, 11, 0, 0, 0, 0, 0, true);
    assertEquals("05YY11", result);
}

@Test
public void test_204_11() throws Exception {
    Token[] tokens = new Token[]{
        new Token(DurationFormatUtils.d, 1),
        new Token(new StringBuffer("D")),
        new Token(DurationFormatUtils.H, 2),
        new Token(DurationFormatUtils.m, 2)
    };
    String result = DurationFormatUtils.format(tokens, 0, 0, 3, 12, 30, 0, 0, false);
    assertEquals("3D12H30M", result);
}

@Test
public void test_204_21() throws Exception {
    Token[] tokens = new Token[]{
        new Token(DurationFormatUtils.s, 2),
        new Token(new StringBuffer(".")),
        new Token(DurationFormatUtils.S, 3)
    };
    String result = DurationFormatUtils.format(tokens, 0, 0, 0, 0, 0, 45, 500, true);
    assertEquals("45.500", result);
}

@Test
public void test_204_31() throws Exception {
    Token[] tokens = new Token[]{
        new Token(DurationFormatUtils.s, 1),
        new Token(DurationFormatUtils.S, 2)
    };
    String result = DurationFormatUtils.format(tokens, 0, 0, 0, 0, 0, 59, 999, false);
    assertEquals("59.999", result);
}

@Test
public void test_204_41() throws Exception {
    Token[] tokens = new Token[]{
        new Token(new StringBuffer("P")),
        new Token(DurationFormatUtils.y, 4),
        new Token(new StringBuffer("Y")),
        new Token(DurationFormatUtils.M, 2),
        new Token(new StringBuffer("M")),
        new Token(DurationFormatUtils.d, 2),
        new Token(new StringBuffer("DT")),
        new Token(DurationFormatUtils.H, 2),
        new Token(new StringBuffer("H")),
        new Token(DurationFormatUtils.m, 2),
        new Token(new StringBuffer("M")),
        new Token(DurationFormatUtils.s, 2),
        new Token(new StringBuffer(".")),
        new Token(DurationFormatUtils.S, 3),
        new Token(new StringBuffer("S"))
    };
    String result = DurationFormatUtils.format(tokens, 2023, 6, 15, 14, 30, 45, 500, true);
    assertEquals("P2023Y06M15DT14H30M45.500S", result);
}

@Test
public void test_204_51() throws Exception {
    Token[] tokens = new Token[]{
        new Token(DurationFormatUtils.H, 1),
        new Token(new StringBuffer(":")),
        new Token(DurationFormatUtils.m, 1),
        new Token(new StringBuffer(":")),
        new Token(DurationFormatUtils.s, 1)
    };
    String result = DurationFormatUtils.format(tokens, 0, 0, 0, 5, 3, 7, 0, false);
    assertEquals("5:3:7", result);
}

}
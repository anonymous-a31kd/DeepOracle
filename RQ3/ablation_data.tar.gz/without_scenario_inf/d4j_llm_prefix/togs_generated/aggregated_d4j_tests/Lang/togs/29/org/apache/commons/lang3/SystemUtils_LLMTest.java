package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.regex.Pattern;
import org.apache.commons.lang3.SystemUtils;
import java.io.File;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class SystemUtils_LLMTest extends SystemUtils_LLMTest_scaffolding {
    
@Test
public void test_175_01() throws Exception {
    float versionInt = SystemUtils.toJavaVersionInt("1");
    assertEquals(100, versionInt, 0.0);
}

@Test
public void test_175_11() throws Exception {
    assertEquals(180, SystemUtils.toJavaVersionInt("1.8"));
}

@Test
public void test_175_21() throws Exception {
    float result = SystemUtils.toJavaVersionInt("1.8.0");
    assertEquals(180, result, 0.0);
}

@Test
public void test_175_31() throws Exception {
    SystemUtils.toJavaVersionInt("1.8.0_231");
}

@Test
public void test_175_41() throws Exception {
    float result = SystemUtils.toJavaVersionInt("");
    assertEquals(0.0f, result, 0.0f);
}

@Test
public void test_175_51() throws Exception {
    SystemUtils.toJavaVersionInt(null);
}

@Test
public void test_175_61() throws Exception {
    float javaVersionInt = SystemUtils.toJavaVersionInt("1.x.y");
    assertEquals(0.0f, javaVersionInt, 0.0f);
}

@Test
public void test_175_71() throws Exception {
    float versionInt = SystemUtils.toJavaVersionInt("11.0.2");
    assertEquals(110, versionInt, 0.0);
}

@Test
public void test_175_81() throws Exception {
    float versionInt = SystemUtils.toJavaVersionInt("01.08.00");
    assertEquals(108, versionInt, 0.0f);
}

@Test
public void test_175_91() throws Exception {
    float versionInt = SystemUtils.toJavaVersionInt("1.8.0_231-b11");
    assertEquals(180, versionInt, 0.0);
}

}
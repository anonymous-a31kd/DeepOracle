package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.math.BigInteger;
import org.apache.commons.lang3.StringUtils;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class NumberUtils_LLMTest extends NumberUtils_LLMTest_scaffolding {
    
@Test
public void test_146_01() throws Exception {
    Number result = NumberUtils.createNumber("123.");
    assertEquals(new Double(123.0), result);
}

@Test
public void test_146_21() throws Exception {
    Number number = NumberUtils.createNumber("1234");
    assertEquals(1234, number.intValue());
}

@Test
public void test_146_51() throws Exception {
    Number result = NumberUtils.createNumber("1.23e45");
    assertTrue(result instanceof Double);
    assertEquals(1.23e45, result.doubleValue(), 0);
}

@Test
public void test_146_71() throws Exception {
	try {
    NumberUtils.createNumber("123.f");


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_147_01() throws Exception {
    assertFalse(NumberUtils.isNumber("123."));
}

@Test
public void test_147_11() throws Exception {
    boolean result = NumberUtils.isNumber("1.23E4.");
    assertFalse(result);
}

@Test
public void test_147_21() throws Exception {
    assertFalse(NumberUtils.isNumber("1.2.3"));
}

@Test
public void test_147_31() throws Exception {
    assertTrue(NumberUtils.isNumber(".123E4"));
}

@Test
public void test_147_41() throws Exception {
    assertTrue(NumberUtils.isNumber(".123"));
}

@Test
public void test_147_51() throws Exception {
    assertFalse(NumberUtils.isNumber("."));
}

@Test
public void test_147_61() throws Exception {
    boolean result = NumberUtils.isNumber("123.456");
    assertTrue(result);
}

@Test
public void test_147_71() throws Exception {
    assertFalse(NumberUtils.isNumber("1E2.3"));
}

@Test
public void test_147_81() throws Exception {
    assertTrue(NumberUtils.isNumber("-.123"));
}

}
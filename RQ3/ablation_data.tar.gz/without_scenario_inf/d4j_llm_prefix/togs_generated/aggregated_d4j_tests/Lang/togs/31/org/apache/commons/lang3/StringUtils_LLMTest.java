package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.Locale;
import java.util.Iterator;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class StringUtils_LLMTest extends StringUtils_LLMTest_scaffolding {
    
@Test
public void test_179_01() throws Exception {
    char[] searchChars = {'a', 'b', 'c'};
    boolean result = StringUtils.containsAny("hello", searchChars);
    assertFalse("Expected 'hello' to not contain any of the characters 'a', 'b', 'c'", result);
}

@Test
public void test_179_11() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00'};
    boolean result = StringUtils.containsAny("hello\uD800\uDC00world", searchChars);
    assertTrue(result);
}

@Test
public void test_179_21() throws Exception {
    char[] searchChars = {'\uD800', 'x'};
    boolean result = StringUtils.containsAny("hello\uD800xworld", searchChars);
    assertTrue(result);
}

@Test
public void test_179_31() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00'};
    boolean result = StringUtils.containsAny("hello\uD800\uDC00", searchChars);
    assertTrue(result);
}

@Test
public void test_179_41() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00', 'a'};
    boolean result = StringUtils.containsAny("hello", searchChars);
    assertFalse(result); // "hello" does not contain any of the characters in searchChars
}

@Test
public void test_179_51() throws Exception {
    char[] searchChars = {'a', 'b', 'c'};
    boolean result = StringUtils.containsAny("", searchChars);
    assertFalse(result);
}

@Test
public void test_179_61() throws Exception {
    char[] searchChars = {};
    boolean result = StringUtils.containsAny("hello", searchChars);
    assertFalse(result);
}

@Test
public void test_179_71() throws Exception {
    char[] searchChars = {'\uD800', '\uDC00', 'l'};
    boolean result = StringUtils.containsAny("he\uD800\uDC00llo", searchChars);
    assertTrue(result);
}

}
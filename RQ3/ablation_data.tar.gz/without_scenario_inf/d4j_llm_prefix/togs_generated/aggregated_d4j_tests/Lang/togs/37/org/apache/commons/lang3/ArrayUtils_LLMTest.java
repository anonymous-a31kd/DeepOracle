package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.lang3.builder.ToStringBuilder;
import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.Array;
import org.apache.commons.lang3.ArrayUtils;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ArrayUtils_LLMTest extends ArrayUtils_LLMTest_scaffolding {
    
@Test
public void test_183_01() throws Exception {
    String[] array1 = new String[]{"a", "b"};
    String[] array2 = new String[]{"c", "d"};
    String[] result = ArrayUtils.addAll(array1, array2);
    assertArrayEquals(new String[]{"a", "b", "c", "d"}, result);
}

@Test
public void test_183_11() throws Exception {
    String[] array1 = null;
    String[] array2 = new String[]{"a", "b"};
    String[] result = ArrayUtils.addAll(array1, array2);
    assertArrayEquals(new String[]{"a", "b"}, result);
}

@Test
public void test_183_21() throws Exception {
    String[] array1 = new String[]{"a", "b"};
    String[] array2 = null;
    String[] result = ArrayUtils.addAll(array1, array2);
    assertArrayEquals(new String[]{"a", "b"}, result);
}

@Test
public void test_183_41() throws Exception {
    String[] array1 = new String[0];
    String[] array2 = new String[0];
    String[] result = ArrayUtils.addAll(array1, array2);
    assertArrayEquals(new String[0], result);
}

@Test
public void test_183_51() throws Exception {
    Object[] array1 = new Object[]{"a", "b"};
    String[] array2 = new String[]{"c", "d"};
    Object[] result = ArrayUtils.addAll(array1, array2);
    
    // Assert that the resulting array contains all elements of array1 followed by all elements of array2
    assertArrayEquals(new Object[]{"a", "b", "c", "d"}, result);
}

}
package org.apache.commons.lang;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.TreeMap;
import java.io.StringWriter;
import java.util.Map;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Entities_LLMTest extends Entities_LLMTest_scaffolding {
    
@Test
public void test_187_01() throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "abc");
    assertEquals("abc", writer.toString());
}

@Test
public void test_187_11() throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "é");
    assertEquals("&eacute;", writer.toString());
}

@Test
public void test_187_21() throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "𐀀");
    assertEquals("𐀀", writer.toString());
}

@Test
public void test_187_31() throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "a𐀀bé");
    assertEquals("a𐀀bé", writer.toString());
}

@Test
public void test_187_41()  throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "\uD800");
}

@Test
public void test_187_51()  throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "\uDC00");
}

@Test
public void test_187_61()  throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "\uD800x");
}

@Test
public void test_187_71() throws Exception {
    StringWriter writer = new StringWriter();
    Entities entities = new Entities();
    entities.escape(writer, "abc𐀀");
    // Assert that the writer contains the correctly escaped string
    assertEquals("abc𐀀", writer.toString());
}

}
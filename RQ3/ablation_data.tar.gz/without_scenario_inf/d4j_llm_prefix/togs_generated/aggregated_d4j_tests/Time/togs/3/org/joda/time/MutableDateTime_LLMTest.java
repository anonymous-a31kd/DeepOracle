package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.chrono.ISOChronology;
import java.util.Locale;
import org.joda.convert.FromString;
import org.joda.time.field.FieldUtils;
import java.io.Serializable;
import org.joda.time.base.BaseDateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.field.AbstractReadableInstantFieldProperty;
import org.joda.time.format.DateTimeFormatter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.joda.convert.ToString;
import org.joda.time.MutableDateTime;
import org.joda.time.DurationFieldType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class MutableDateTime_LLMTest extends MutableDateTime_LLMTest_scaffolding {
    
@Test
public void test_185_01() throws Exception {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.days(), 0);
    assertEquals(originalMillis, dateTime.getMillis());
}

@Test
public void test_185_11() throws Exception {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.days(), 1);
    
    // Assert that the milliseconds have increased by exactly one day's worth of milliseconds
    assertEquals(originalMillis + 24 * 60 * 60 * 1000, dateTime.getMillis());
}

@Test
public void test_185_21() throws Exception {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.days(), -1);
    assertEquals(originalMillis - 24 * 60 * 60 * 1000, dateTime.getMillis());
}

@Test
public void test_185_41() throws Exception {
    MutableDateTime dateTime = new MutableDateTime();
    long originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.hours(), 2);

    originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.minutes(), 30);

    originalMillis = dateTime.getMillis();
    dateTime.add(DurationFieldType.seconds(), -45);

    // Assert that the final milliseconds is equal to the original plus the added time
    long expectedMillis = originalMillis + (2 * 60 * 60 * 1000) + (30 * 60 * 1000) - (45 * 1000);
    assertEquals(expectedMillis, dateTime.getMillis());
}

@Test
public void test_186_01() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    long originalMillis = dt.getMillis();
    dt.addDays(0);
    // Assert that the milliseconds have not changed after adding zero days
    assertEquals(originalMillis, dt.getMillis());
}

@Test
public void test_186_11() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.addDays(1);
    dt.setHourOfDay(12);  // Set hour to a valid value to check if the method works as expected
    
    // Assert that the hour is correctly set to 12
    assertEquals(12, dt.getHourOfDay());
}

@Test
public void test_186_21() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.addDays(-1);

}

@Test
public void test_186_31() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(12);
    assertEquals(12, dt.getHourOfDay());
}

@Test
public void test_186_41() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(0);
    assertEquals(0, dt.getHourOfDay());
}

@Test
public void test_186_51() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(23);
    assertEquals(23, dt.getHourOfDay());
}

@Test
public void test_186_61() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.addDays(2);
    dt.setHourOfDay(15);

    // Assert that the hour of the day has been set correctly
    assertEquals(15, dt.getHourOfDay());
}

@Test
public void test_186_71() throws Exception {
    MutableDateTime dt = new MutableDateTime();
    dt.setHourOfDay(8);
    dt.addDays(3);

}

}
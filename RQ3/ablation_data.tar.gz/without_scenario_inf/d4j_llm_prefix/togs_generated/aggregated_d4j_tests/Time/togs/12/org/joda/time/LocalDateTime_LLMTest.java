package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.convert.ToString;
import org.joda.time.chrono.ISOChronology;
import java.io.ObjectOutputStream;
import org.joda.time.format.DateTimeFormat;
import org.joda.convert.FromString;
import org.joda.time.field.AbstractReadableInstantFieldProperty;
import org.joda.time.base.BaseLocal;
import java.util.Date;
import java.io.ObjectInputStream;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.Calendar;
import org.joda.time.convert.PartialConverter;
import java.util.TimeZone;
import org.joda.time.LocalDateTime;
import org.joda.time.convert.ConverterManager;
import java.io.Serializable;
import java.util.Locale;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocalDateTime_LLMTest extends LocalDateTime_LLMTest_scaffolding {
    
@Test
public void test_198_01() throws Exception {

    Date date = new Date(122, 5, 15, 10, 30, 45);
    LocalDateTime localDateTime = LocalDateTime.fromDateFields(date);
    
    assertEquals(2022, localDateTime.getYear());
    assertEquals(6, localDateTime.getMonthOfYear());
    assertEquals(15, localDateTime.getDayOfMonth());
    assertEquals(10, localDateTime.getHourOfDay());
    assertEquals(30, localDateTime.getMinuteOfHour());
    assertEquals(45, localDateTime.getSecondOfMinute());
}

@Test
public void test_198_11() throws Exception {

    Date date = new Date(-62135773200000L);
    LocalDateTime.fromDateFields(date);
}

@Test
public void test_198_21() throws Exception {
    Date date = new Date(0);
    LocalDateTime localDateTime = LocalDateTime.fromDateFields(date);

    assertEquals(1970, localDateTime.getYear());
    assertEquals(1, localDateTime.getMonthOfYear());
    assertEquals(1, localDateTime.getDayOfMonth());
    assertEquals(0, localDateTime.getHourOfDay());
    assertEquals(0, localDateTime.getMinuteOfHour());
    assertEquals(0, localDateTime.getSecondOfMinute());
    assertEquals(0, localDateTime.getMillisOfSecond());
}

@Test
public void test_198_41() throws Exception {

    Date date = new Date(Long.MIN_VALUE);
    LocalDateTime.fromDateFields(date);
}

@Test
public void test_199_01() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.ERA, GregorianCalendar.AD);
    calendar.set(Calendar.YEAR, 2023);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);
    assertEquals(new LocalDateTime(2023, 1, 1, 0, 0, 0, 0), result);
}

@Test
public void test_199_11() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    calendar.set(Calendar.YEAR, 1);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.HOUR_OF_DAY, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);
    
    // Assert that the LocalDateTime reflects the same date and time fields
    assertEquals(-1, result.getYear()); // Year 1 BC is represented as -1
    assertEquals(1, result.getMonthOfYear());
    assertEquals(1, result.getDayOfMonth());
    assertEquals(0, result.getHourOfDay());
    assertEquals(0, result.getMinuteOfHour());
    assertEquals(0, result.getSecondOfMinute());
    assertEquals(0, result.getMillisOfSecond());
}

@Test
public void test_199_31() throws Exception {
    Calendar calendar = Calendar.getInstance();
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);
    
    assertEquals(calendar.get(Calendar.YEAR), result.getYear());
    assertEquals(calendar.get(Calendar.MONTH) + 1, result.getMonthOfYear()); // Calendar.MONTH is zero-based
    assertEquals(calendar.get(Calendar.DAY_OF_MONTH), result.getDayOfMonth());
    assertEquals(calendar.get(Calendar.HOUR_OF_DAY), result.getHourOfDay());
    assertEquals(calendar.get(Calendar.MINUTE), result.getMinuteOfHour());
    assertEquals(calendar.get(Calendar.SECOND), result.getSecondOfMinute());
    assertEquals(calendar.get(Calendar.MILLISECOND), result.getMillisOfSecond());
}

@Test
public void test_199_41() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    calendar.set(Calendar.YEAR, Integer.MAX_VALUE);
    calendar.set(Calendar.MONTH, Calendar.DECEMBER);
    calendar.set(Calendar.DAY_OF_MONTH, 31);
    calendar.set(Calendar.HOUR_OF_DAY, 23);
    calendar.set(Calendar.MINUTE, 59);
    calendar.set(Calendar.SECOND, 59);
    calendar.set(Calendar.MILLISECOND, 999);
    LocalDateTime result = LocalDateTime.fromCalendarFields(calendar);
}

}
package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.util.Locale;
import org.joda.time.chrono.BaseChronology;
import org.joda.time.format.FormatUtils;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.HashMap;
import org.joda.time.field.FieldUtils;
import org.joda.time.tz.FixedDateTimeZone;
import java.util.Set;
import org.joda.time.tz.DefaultNameProvider;
import org.joda.time.tz.Provider;
import org.joda.convert.ToString;
import java.io.ObjectOutputStream;
import org.joda.time.format.DateTimeFormatterBuilder;
import org.joda.time.tz.NameProvider;
import java.lang.ref.Reference;
import java.io.ObjectInputStream;
import java.util.Map;
import org.joda.time.format.DateTimeFormatter;
import org.joda.convert.FromString;
import org.joda.time.DateTimeConstants;
import org.joda.time.DateTimeZone;
import org.joda.time.tz.ZoneInfoProvider;
import org.joda.time.tz.UTCProvider;
import java.util.TimeZone;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateTimeZone_LLMTest extends DateTimeZone_LLMTest_scaffolding {
    
@Test
public void test_194_01() throws Exception {

    DateTimeZone zone1 = DateTimeZone.forOffsetHoursMinutes(0, 0);
    DateTimeZone zone2 = DateTimeZone.forOffsetHoursMinutes(5, 30);
    DateTimeZone zone3 = DateTimeZone.forOffsetHoursMinutes(-5, 30);
    DateTimeZone zone4 = DateTimeZone.forOffsetHoursMinutes(23, 59);
    DateTimeZone zone5 = DateTimeZone.forOffsetHoursMinutes(-23, 59);

    assertEquals("UTC", zone1.getID());
    assertEquals("+05:30", zone2.getID());
    assertEquals("-05:30", zone3.getID());
    assertEquals("+23:59", zone4.getID());
    assertEquals("-23:59", zone5.getID());
}

@Test
public void test_194_11() throws Exception {
	try {
    DateTimeZone.forOffsetHoursMinutes(24, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_194_21() throws Exception {
	try {
    DateTimeZone.forOffsetHoursMinutes(-24, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_194_51() throws Exception {
    DateTimeZone zone1 = DateTimeZone.forOffsetHoursMinutes(5, 30);
    DateTimeZone zone2 = DateTimeZone.forOffsetHoursMinutes(10, 15);

    // Assert that the time zones have the correct offsets
    assertEquals("+05:30", zone1.getID());
    assertEquals("+10:15", zone2.getID());
}

@Test
public void test_194_61() throws Exception {

    DateTimeZone zone1 = DateTimeZone.forOffsetHoursMinutes(-5, 30);
    DateTimeZone zone2 = DateTimeZone.forOffsetHoursMinutes(-10, 15);

    assertEquals("-05:30", zone1.getID());
    assertEquals("-10:15", zone2.getID());
}

@Test
public void test_194_91() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHoursMinutes(23, 59);
    assertEquals("+23:59", zone.getID());
}

}
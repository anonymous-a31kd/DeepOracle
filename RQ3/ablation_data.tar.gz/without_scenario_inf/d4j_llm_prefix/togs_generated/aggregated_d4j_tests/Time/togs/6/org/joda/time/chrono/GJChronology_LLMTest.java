package org.joda.time.chrono;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.chrono.GregorianChronology;
import java.util.Locale;
import org.joda.time.Chronology;
import org.joda.time.field.BaseDateTimeField;
import org.joda.time.ReadableInstant;
import org.joda.time.chrono.GJChronology;
import java.util.HashMap;
import java.util.ArrayList;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.DateTimeUtils;
import org.joda.time.chrono.JulianChronology;
import org.joda.time.DurationField;
import org.joda.time.ReadablePartial;
import org.joda.time.DateTimeField;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.field.DecoratedDurationField;
import org.joda.time.LocalDate;
import java.util.Map;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.DateTimeZone;
import org.joda.time.Instant;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GJChronology_LLMTest extends GJChronology_LLMTest_scaffolding {
    
@Test
public void test_191_01() throws Exception {
    ReadableInstant validCutover = new Instant(new LocalDate(2000, 1, 1).toDateTimeAtStartOfDay().getMillis());
    GJChronology gjChronology = GJChronology.getInstance(DateTimeZone.UTC, validCutover, 4);
    
    // Assert the Gregorian cutover date is as specified
    assertEquals(validCutover, gjChronology.getGregorianCutover());
}

@Test
public void test_191_11() throws Exception {

    ReadableInstant invalidCutover = new Instant(new LocalDate(0, 1, 1).toDateTimeAtStartOfDay().getMillis());
    GJChronology.getInstance(DateTimeZone.UTC, invalidCutover, 4);
}

@Test
public void test_191_21() throws Exception {
	try {

    ReadableInstant invalidCutover = new Instant(new LocalDate(0, 12, 31).toDateTimeAtStartOfDay().getMillis());
    GJChronology.getInstance(DateTimeZone.UTC, invalidCutover, 4);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_191_31() throws Exception {

    GJChronology.getInstance(DateTimeZone.UTC, null, 4);
}

@Test
public void test_191_41() throws Exception {
    ReadableInstant edgeCutover = new Instant(new LocalDate(1, 1, 1).toDateTimeAtStartOfDay().getMillis());
    GJChronology gjChronology = GJChronology.getInstance(DateTimeZone.UTC, edgeCutover, 4);
    
    assertEquals(edgeCutover, gjChronology.getGregorianCutover());
}

}
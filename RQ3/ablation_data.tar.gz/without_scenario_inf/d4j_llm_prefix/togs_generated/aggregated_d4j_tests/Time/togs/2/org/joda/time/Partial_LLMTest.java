package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.Partial;
import java.util.List;
import java.util.Arrays;
import org.joda.time.Chronology;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.field.AbstractPartialFieldProperty;
import java.util.ArrayList;
import org.joda.time.DateTimeFieldType;
import org.joda.time.format.DateTimeFormatter;
import java.io.Serializable;
import org.joda.time.base.AbstractPartial;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.field.FieldUtils;
import org.joda.time.DurationFieldType;
import java.util.Locale;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Partial_LLMTest extends Partial_LLMTest_scaffolding {
    
@Test
public void test_182_01() throws Exception {
    DateTimeFieldType fieldType = DateTimeFieldType.secondOfMinute();
    Partial partial = new Partial();
    Partial updatedPartial = partial.with(fieldType, 30);
    assertEquals(30, updatedPartial.getValue(updatedPartial.indexOf(fieldType)));
}

@Test
public void test_182_11() throws Exception {
    DateTimeFieldType fieldType = DateTimeFieldType.dayOfMonth();
    Partial partial = new Partial();
    Partial result = partial.with(fieldType, 15);
    assertEquals(15, result.getValue(result.indexOf(fieldType)));
}

@Test
public void test_182_21() throws Exception {
    DateTimeFieldType type1 = DateTimeFieldType.secondOfMinute();
    DateTimeFieldType type2 = DateTimeFieldType.dayOfMonth();
    Partial partial = new Partial(new DateTimeFieldType[]{type1}, new int[]{30});
    Partial newPartial = partial.with(type2, 15);
    
    assertEquals(30, newPartial.getValue(0)); // Checking if the original field value is retained
    assertEquals(15, newPartial.getValue(1)); // Checking if the new field is added with correct value
    assertEquals(type1, newPartial.getFieldType(0)); // Verifying the type of the first field
    assertEquals(type2, newPartial.getFieldType(1)); // Verifying the type of the newly added field
}

@Test
public void test_182_31() throws Exception {
    DateTimeFieldType type1 = DateTimeFieldType.secondOfMinute();
    DateTimeFieldType type2 = DateTimeFieldType.millisOfSecond();
    DateTimeFieldType newType = DateTimeFieldType.minuteOfHour();
    Partial partial = new Partial(new DateTimeFieldType[]{type1, type2}, new int[]{30, 500});
    Partial updatedPartial = partial.with(newType, 15);
    
    // Assert that the updated partial now has three fields and the new field is set correctly
    assertEquals(3, updatedPartial.size());
    assertEquals(15, updatedPartial.getValue(updatedPartial.size() - 1));
    assertEquals(newType, updatedPartial.getFieldType(updatedPartial.size() - 1));
}

@Test
public void test_183_01() throws Exception {
    DateTimeFieldType[] types = new DateTimeFieldType[] {
        DateTimeFieldType.year(),
        DateTimeFieldType.monthOfYear(),
        DateTimeFieldType.dayOfMonth()
    };
    int[] values = new int[] {2023, 6, 15};
    Partial partial = new Partial(types, values, ISOChronology.getInstanceUTC());
    assertArrayEquals(values, partial.getValues());
    assertEquals(ISOChronology.getInstanceUTC(), partial.getChronology());
}

}
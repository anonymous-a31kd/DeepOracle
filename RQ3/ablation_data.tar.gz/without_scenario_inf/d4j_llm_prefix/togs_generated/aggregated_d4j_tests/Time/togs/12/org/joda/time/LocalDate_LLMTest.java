package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.convert.ToString;
import java.util.HashSet;
import org.joda.time.chrono.ISOChronology;
import java.io.ObjectOutputStream;
import org.joda.time.format.DateTimeFormat;
import org.joda.convert.FromString;
import org.joda.time.field.AbstractReadableInstantFieldProperty;
import org.joda.time.base.BaseLocal;
import org.joda.time.field.FieldUtils;
import java.util.Date;
import java.io.ObjectInputStream;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.Calendar;
import org.joda.time.convert.PartialConverter;
import java.util.TimeZone;
import org.joda.time.convert.ConverterManager;
import java.util.Set;
import java.io.Serializable;
import java.util.Locale;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LocalDate_LLMTest extends LocalDate_LLMTest_scaffolding {
    
@Test
public void test_196_11() throws Exception {
    Date date = new Date(121, 5, 15);
    LocalDate result = LocalDate.fromDateFields(date);

    assertEquals(new LocalDate(2021, 6, 15), result);
}

@Test
public void test_196_21() throws Exception {
    GregorianCalendar cal = new GregorianCalendar();
    cal.set(Calendar.ERA, GregorianCalendar.BC);
    cal.set(Calendar.YEAR, 100);
    cal.set(Calendar.MONTH, Calendar.JANUARY);
    cal.set(Calendar.DAY_OF_MONTH, 1);
    Date bcDate = cal.getTime();
    LocalDate result = LocalDate.fromDateFields(bcDate);

    assertEquals(-99, result.getYear());
    assertEquals(1, result.getMonthOfYear());
    assertEquals(1, result.getDayOfMonth());
}

@Test
public void test_196_31() throws Exception {
    Date date = new Date(0);
    LocalDate result = LocalDate.fromDateFields(date);

    // Assert that the LocalDate created from Date(0) matches the expected LocalDate values.
    // Date(0) corresponds to the epoch date, which is 1970-01-01.
    assertEquals(1970, result.getYear());
    assertEquals(1, result.getMonthOfYear());
    assertEquals(1, result.getDayOfMonth());
}

@Test
public void test_196_41() throws Exception {
    Date date = new Date(-1000L * 60 * 60 * 24 * 365);
    LocalDate result = LocalDate.fromDateFields(date);
    
    // The date represents 1969-01-01 as it is one year (365 days) before the epoch (1970-01-01).
    assertEquals(1969, result.getYear());
    assertEquals(1, result.getMonthOfYear());
    assertEquals(1, result.getDayOfMonth());
}

@Test
public void test_197_01() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 2023);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.AD);
    LocalDate date = LocalDate.fromCalendarFields(calendar);
    
    // Assert that the created LocalDate matches the expected values from the calendar
    assertEquals(2023, date.getYear());
    assertEquals(1, date.getMonthOfYear());
    assertEquals(1, date.getDayOfMonth());
}

@Test
public void test_197_11() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 100);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    LocalDate date = LocalDate.fromCalendarFields(calendar);
    assertEquals(new LocalDate(-99, 1, 1), date);
}

@Test
public void test_197_21() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 1);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.AD);
    LocalDate date = LocalDate.fromCalendarFields(calendar);
    
    // The expected LocalDate should correspond to the set calendar fields: Year 1, January 1st.
    assertEquals(new LocalDate(1, 1, 1), date);
}

@Test
public void test_197_31() throws Exception {
    Calendar calendar = new GregorianCalendar();
    calendar.set(Calendar.YEAR, 1);
    calendar.set(Calendar.MONTH, Calendar.JANUARY);
    calendar.set(Calendar.DAY_OF_MONTH, 1);
    calendar.set(Calendar.ERA, GregorianCalendar.BC);
    LocalDate date = LocalDate.fromCalendarFields(calendar);
    assertEquals(new LocalDate(-1, 1, 1), date);
}

}
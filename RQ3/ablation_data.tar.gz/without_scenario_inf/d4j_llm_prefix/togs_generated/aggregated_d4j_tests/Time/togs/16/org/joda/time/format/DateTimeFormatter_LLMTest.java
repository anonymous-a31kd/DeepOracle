package org.joda.time.format;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.format.DateTimeFormatterBuilder;
import org.joda.time.Chronology;
import org.joda.time.LocalDateTime;
import org.joda.time.ReadableInstant;
import org.joda.time.ReadWritableInstant;
import org.joda.time.LocalDate;
import org.joda.time.ReadablePartial;
import org.joda.time.DateTimeUtils;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalTime;
import java.io.Writer;
import org.joda.time.DateTime;
import org.joda.time.DateTimeFieldType;
import org.joda.time.*;
import java.util.Locale;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.MutableDateTime;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class DateTimeFormatter_LLMTest extends DateTimeFormatter_LLMTest_scaffolding {
    
@Test
public void test_204_01() throws Exception {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(0L);
    int pos = formatter.parseInto(instant, "2023", 0);

    // Assert that the parse was successful and the new position is after parsing the year.
    assertEquals(4, pos);
    
    // Additionally, verify that the year of the instant was correctly set to 2023.
    assertEquals(2023, instant.getYear());
}

@Test
public void test_204_11() throws Exception {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(0L);
    int pos = formatter.parseInto(instant, "2000", 0);

    // Assert that the position returned is 4, indicating successful parsing of the entire string "2000".
    assertEquals(4, pos);

    // Assert that the year has been set correctly in the instant.
    assertEquals(2000, instant.getYear());
}

@Test
public void test_204_21() throws Exception {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(0L);
    int pos = formatter.parseInto(instant, "-1000", 0);

    assertEquals(4, pos);
    assertEquals(-1000, instant.getYear());
}

@Test
public void test_204_41() throws Exception {
    DateTimeFormatter formatter = new DateTimeFormatterBuilder()
    .appendYear(4, 4)
    .toFormatter();
    MutableDateTime instant = new MutableDateTime(System.currentTimeMillis());
    int pos = formatter.parseInto(instant, "1999", 0);

    // Assert that the parse position is the length of the string, indicating successful parsing
    assertEquals(4, pos);

    // Assert that the year of the instant has been set to 1999
    assertEquals(1999, instant.getYear());
}

}
package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.HashMap;
import org.joda.time.DurationField;
import java.io.Serializable;
import org.joda.time.field.UnsupportedDurationField;
import org.joda.time.DurationFieldType;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class UnsupportedDurationField_LLMTest extends UnsupportedDurationField_LLMTest_scaffolding {
    
@Test
public void test_184_01() throws Exception {
    DurationField unsupported1 = UnsupportedDurationField.getInstance(DurationFieldType.eras());
    DurationField unsupported2 = UnsupportedDurationField.getInstance(DurationFieldType.centuries());
    int result = unsupported1.compareTo(unsupported2);
    assertEquals(0, result);
}

@Test
public void test_184_21() throws Exception {
    DurationField unsupported = UnsupportedDurationField.getInstance(DurationFieldType.eras());

    int result = unsupported.compareTo(null);

    assertEquals(0, result);
}

}
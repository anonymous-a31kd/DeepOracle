package org.joda.time.chrono;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.chrono.ZonedChronology;
import org.joda.time.field.BaseDateTimeField;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.DateTimeConstants;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.Instant;
import org.joda.time.ReadablePartial;
import org.joda.time.field.MillisDurationField;
import java.util.HashMap;
import org.joda.time.chrono.GregorianChronology;
import org.joda.time.field.StrictDateTimeField;
import java.util.Locale;
import org.joda.time.DateTimeZone;
import org.joda.time.Chronology;
import org.joda.time.DateTimeField;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.field.BaseDurationField;
import org.joda.time.DurationField;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ZonedChronology_LLMTest extends ZonedChronology_LLMTest_scaffolding {
    
@Test
public void test_215_01() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/London");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.dayOfMonth();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, 1);
}

@Test
public void test_215_11() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("America/New_York");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.monthOfYear();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, 1);
}

@Test
public void test_215_21() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/London");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.hourOfDay();

    long instant = 1616900400000L;
    long result = field.addWrapField(instant, 1);

    // Assert that the result is the addition of one hour, wrapping correctly within the day
    // Since the input instant is at 01:00 am (BST starts), adding 1 hour should wrap it to 02:00 am.
    assertEquals(1616904000000L, result);
}

@Test
public void test_215_31() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Asia/Tokyo");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.dayOfMonth();
    long instant = System.currentTimeMillis();
    long result = field.addWrapField(instant, -5);

    // Assert that the result is correctly wrapped based on the operation
    // Here, we assume the result should still be a valid instant, just wrapped around the month
    // Considering the nature of wrapping, we can check if the date part has changed correctly
    int originalDay = field.get(instant);
    int newDay = field.get(result);
    assertTrue(newDay >= 1 && newDay <= field.getMaximumValue(instant));
    // This check confirms that the day has wrapped correctly within the valid range
}

@Test
public void test_215_41() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("UTC");
    ZonedChronology chrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) chrono.monthOfYear();
    long instant = System.currentTimeMillis();
    field.addWrapField(instant, 100);
}

@Test
public void test_216_01() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/London");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.dayOfMonth();
    long instant = System.currentTimeMillis();
    field.roundCeiling(instant);
}

@Test
public void test_216_11() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("America/New_York");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.monthOfYear();
    long instant = System.currentTimeMillis();
    long roundedInstant = field.roundCeiling(instant);
    
    // Assert that the rounded instant is greater than or equal to the original instant
    assertTrue(roundedInstant >= instant);
}

@Test
public void test_216_21() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Europe/Paris");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.hourOfDay();

    long instant = 1616893200000L;
    long roundedInstant = field.roundCeiling(instant);

    // Assert that the result is the expected rounded ceiling value
    assertEquals(1616896800000L, roundedInstant);
}

@Test
public void test_216_31() throws Exception {
    DateTimeZone zone = DateTimeZone.UTC;
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.secondOfMinute();
    long instant = System.currentTimeMillis();
    long roundedInstant = field.roundCeiling(instant);
    
    // Assert that the rounded instant is greater than or equal to the original instant, indicating it has been rounded up.
    assertTrue(roundedInstant >= instant);
}

@Test
public void test_216_41() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("Asia/Tokyo");
    Chronology base = ISOChronology.getInstance();
    ZonedChronology zonedChrono = ZonedChronology.getInstance(base, zone);
    DateTimeField field = zonedChrono.year();
    long instant = -100000000000L;
    long result = field.roundCeiling(instant);
    assertEquals(-946771200000L, result); // Expected result based on the rounding logic for the given instant
}

@Test
public void test_218_01() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(2);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 1000000000L;
    field.set(instant, "5", Locale.ENGLISH);
}

@Test
public void test_218_11() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(-5);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = -1000000000L;
    long updatedInstant = field.set(instant, "12", Locale.ENGLISH);
    // Assert that the updated instant corresponds to December of the same year
    assertEquals(12, field.get(updatedInstant));
}

@Test
public void test_218_21() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(0);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 0L;
    long updatedInstant = field.set(instant, "1", Locale.ENGLISH);
    
    // Assert that the updated instant now represents the first month of the year
    assertEquals(0L, updatedInstant);
}

@Test
public void test_218_31() throws Exception {
    DateTimeZone zone = DateTimeZone.forOffsetHours(3);
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 500000000L;
    field.set(instant, "June", Locale.ENGLISH);
    field.set(instant, "juin", Locale.FRENCH);
}

@Test
public void test_218_41() throws Exception {
    DateTimeZone zone = DateTimeZone.forID("America/New_York");
    ZonedChronology zonedChrono = ZonedChronology.getInstance(ISOChronology.getInstance(), zone);
    ZonedChronology.ZonedDateTimeField field =
    (ZonedChronology.ZonedDateTimeField) zonedChrono.monthOfYear();
    long instant = 1593568800000L;
    long updatedInstant = field.set(instant, "11", Locale.ENGLISH);
    
    // Assert that the month is set to November
    assertEquals(10, field.get(updatedInstant));  // November is month 11, zero-based index is 10
}

}
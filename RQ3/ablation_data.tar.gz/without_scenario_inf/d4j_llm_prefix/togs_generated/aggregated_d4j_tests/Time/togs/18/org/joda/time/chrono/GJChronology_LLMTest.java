package org.joda.time.chrono;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.Chronology;
import java.util.HashMap;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.DateTimeZone;
import org.joda.time.chrono.JulianChronology;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.field.DecoratedDurationField;
import java.util.Locale;
import org.joda.time.DateTimeField;
import org.joda.time.format.ISODateTimeFormat;
import org.joda.time.chrono.GJChronology;
import java.util.Map;
import org.joda.time.chrono.GregorianChronology;
import java.util.ArrayList;
import org.joda.time.ReadableInstant;
import org.joda.time.ReadablePartial;
import org.joda.time.DurationField;
import org.joda.time.DateTimeUtils;
import org.joda.time.Instant;
import org.joda.time.field.BaseDateTimeField;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class GJChronology_LLMTest extends GJChronology_LLMTest_scaffolding {
    
@Test
public void test_206_01() throws Exception {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    chronology.getDateTimeMillis(1582, 10, 1, 0, 0, 0, 0);
}

@Test
public void test_206_11() throws Exception {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    long millis = chronology.getDateTimeMillis(1583, 1, 1, 0, 0, 0, 0);
    assertEquals(-12219292800000L, millis);
}

@Test
public void test_206_31() throws Exception {
	try {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    chronology.getDateTimeMillis(1500, 2, 29, 0, 0, 0, 0);


		fail("Expecting exception"); } catch (Exception e) { }
	}

@Test
public void test_206_51() throws Exception {
    GJChronology chronology = GJChronology.getInstance(DateTimeZone.UTC);
    long dateTimeMillis = chronology.getDateTimeMillis(2000, 2, 29, 0, 0, 0, 0);
    // Assert that the computed milliseconds correspond to the expected date and time
    assertEquals(new DateTime(2000, 2, 29, 0, 0, 0, 0, DateTimeZone.UTC).getMillis(), dateTimeMillis);
}

}
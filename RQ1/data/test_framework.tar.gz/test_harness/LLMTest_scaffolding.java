package {TEST_PACKAGE};

{TEST_IMPORTS}
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;

public class {TEST_CLASS}_LLMTest_scaffolding {
    {TEST_RELATIVE}
}
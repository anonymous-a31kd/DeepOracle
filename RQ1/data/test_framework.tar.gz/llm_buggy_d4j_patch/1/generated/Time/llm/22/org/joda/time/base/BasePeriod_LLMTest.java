package org.joda.time.base;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.convert.ConverterManager;
import org.joda.time.PeriodType;
import org.joda.time.ReadableDuration;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.Duration;
import org.joda.time.ReadWritablePeriod;
import org.joda.time.convert.PeriodConverter;
import org.joda.time.ReadablePeriod;
import org.joda.time.Chronology;
import org.joda.time.field.FieldUtils;
import org.joda.time.ReadableInstant;
import java.io.Serializable;
import org.joda.time.DurationFieldType;
import org.joda.time.MutablePeriod;
import org.joda.time.DateTimeUtils;
import org.joda.time.ReadablePartial;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class BasePeriod_LLMTest extends BasePeriod_LLMTest_scaffolding {
     
}

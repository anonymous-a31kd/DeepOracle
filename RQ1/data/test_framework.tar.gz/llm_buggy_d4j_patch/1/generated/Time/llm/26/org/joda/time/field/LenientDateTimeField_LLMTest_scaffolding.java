package org.joda.time.field;

import org.joda.time.field.MillisDurationField;
import org.joda.time.field.LenientDateTimeField;
import org.joda.time.chrono.GregorianChronology;
import org.joda.time.Chronology;
import org.joda.time.DateTimeZone;
import org.joda.time.DateTimeField;
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;

public class LenientDateTimeField_LLMTest_scaffolding {
     
}
package org.joda.time.base;

import org.joda.time.DurationField;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.PeriodType;
import org.joda.time.DateTime;
import org.joda.time.ReadablePeriod;
import org.joda.time.Chronology;
import org.joda.time.DateTimeUtils;
import org.joda.time.field.FieldUtils;
import org.joda.time.Period;
import java.io.Serializable;
import org.joda.time.DurationFieldType;
import org.joda.time.MutablePeriod;
import org.joda.time.ReadableInstant;
import org.joda.time.ReadablePartial;
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;

public class BaseSingleFieldPeriod_LLMTest_scaffolding {
     
}
package org.joda.time.field;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import org.joda.time.field.MillisDurationField;
import org.joda.time.field.LenientDateTimeField;
import org.joda.time.chrono.GregorianChronology;
import org.joda.time.Chronology;
import org.joda.time.DateTimeZone;
import org.joda.time.DateTimeField;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class LenientDateTimeField_LLMTest extends LenientDateTimeField_LLMTest_scaffolding {
     
}

package com.google.javascript.jscomp;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformation;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler;
import com.google.javascript.rhino.Node;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.javascript.rhino.SourcePosition;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.jscomp.NodeTraversal;
import com.google.javascript.rhino.Token;
import java.util.Collection;
import javax.annotation.Nullable;
import java.util.Map;
import com.google.javascript.jscomp.Scope.Var;
import java.util.List;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class ScopedAliases_LLMTest extends ScopedAliases_LLMTest_scaffolding {
     
}

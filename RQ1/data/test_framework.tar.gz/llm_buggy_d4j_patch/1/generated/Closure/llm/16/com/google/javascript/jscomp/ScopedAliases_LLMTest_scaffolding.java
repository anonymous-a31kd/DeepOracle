package com.google.javascript.jscomp;

import com.google.javascript.jscomp.CompilerOptions.AliasTransformation;
import com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler;
import com.google.javascript.rhino.Node;
import com.google.common.collect.Lists;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.SourcePosition;
import com.google.common.collect.Maps;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Token;
import java.util.Collection;
import javax.annotation.Nullable;
import java.util.Map;
import com.google.common.collect.Sets;
import java.util.Set;
import com.google.javascript.jscomp.Scope.Var;
import java.util.List;
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;

public class ScopedAliases_LLMTest_scaffolding {
     
}
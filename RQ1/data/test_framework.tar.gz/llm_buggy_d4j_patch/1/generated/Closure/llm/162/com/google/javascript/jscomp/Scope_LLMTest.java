package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.common.base.Preconditions;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.StaticScope;
import com.google.javascript.rhino.jstype.StaticSymbolTable;
import com.google.common.base.Predicate;
import com.google.javascript.rhino.jstype.StaticReference;
import com.google.javascript.rhino.Node;
import java.util.Collections;
import com.google.javascript.rhino.jstype.ObjectType;
import com.google.common.collect.ImmutableList;
import com.google.javascript.rhino.jstype.StaticSlot;
import com.google.javascript.rhino.ErrorReporter;
import com.google.javascript.rhino.jstype.StaticSourceFile;
import java.util.Map;
import com.google.common.collect.Iterators;
import static com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
import java.util.LinkedHashMap;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Token;
import java.util.Iterator;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class Scope_LLMTest extends Scope_LLMTest_scaffolding {
     
}

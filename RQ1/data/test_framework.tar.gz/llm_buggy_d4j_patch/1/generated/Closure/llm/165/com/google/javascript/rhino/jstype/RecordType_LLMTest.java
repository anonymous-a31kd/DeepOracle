package com.google.javascript.rhino.jstype;


import com.google.javascript.rhino.jstype.ObjectType;
import com.google.javascript.rhino.jstype.RecordTypeBuilder;
import com.google.javascript.rhino.jstype.RecordType;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import com.google.javascript.rhino.Node;
import com.google.common.collect.Maps;
import java.util.SortedMap;
import com.google.javascript.rhino.jstype.RecordTypeBuilder.RecordProperty;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.ErrorReporter;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class RecordType_LLMTest extends RecordType_LLMTest_scaffolding {
     
}

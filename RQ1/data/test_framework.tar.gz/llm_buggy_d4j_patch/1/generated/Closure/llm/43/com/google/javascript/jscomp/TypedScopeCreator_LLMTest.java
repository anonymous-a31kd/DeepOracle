package com.google.javascript.jscomp;


import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import static com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
import com.google.javascript.rhino.InputId;
import com.google.javascript.rhino.jstype.FunctionType;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import static com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
import com.google.javascript.rhino.jstype.JSType;
import static com.google.javascript.jscomp.TypeCheck.MULTIPLE_VAR_DEF;
import static com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
import java.util.List;
import com.google.javascript.jscomp.CodingConvention.SubclassRelationship;
import com.google.javascript.rhino.Node;
import static com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
import static com.google.javascript.jscomp.TypeCheck.ENUM_NOT_CONSTANT;
import static com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE;
import com.google.javascript.rhino.jstype.ObjectType;
import static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
import com.google.common.collect.ImmutableList;
import com.google.javascript.jscomp.NodeTraversal.AbstractShallowStatementCallback;
import static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
import com.google.javascript.jscomp.CodingConvention.DelegateRelationship;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.javascript.rhino.jstype.EnumType;
import static com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
import com.google.javascript.jscomp.CodingConvention.SubclassType;
import static com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE;
import com.google.javascript.jscomp.NodeTraversal;
import com.google.javascript.rhino.jstype.FunctionParamBuilder;
import static com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
import com.google.javascript.rhino.ErrorReporter;
import static com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
import java.util.Map;
import com.google.javascript.jscomp.NodeTraversal.AbstractScopedCallback;
import static com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
import static com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
import com.google.javascript.rhino.jstype.JSTypeRegistry;
import com.google.common.collect.Lists;
import com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast;
import com.google.common.annotations.VisibleForTesting;
import static com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
import com.google.javascript.rhino.JSDocInfo;
import static com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
import com.google.javascript.rhino.Token;
import javax.annotation.Nullable;
import static com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
import static com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
import java.util.Iterator;
import static com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.jscomp.FunctionTypeBuilder.AstFunctionContents;
import java.util.Random;
import java.util.*;
import org.junit.Assert;


public class TypedScopeCreator_LLMTest extends TypedScopeCreator_LLMTest_scaffolding {
     
}
